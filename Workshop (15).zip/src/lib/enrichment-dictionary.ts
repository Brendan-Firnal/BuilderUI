/**
 * ENRICHMENT DICTIONARY
 * 
 * Canonical enrichment definitions and lens mappings for Moonbrush Behavioral Workspace.
 * This file contains all 113 enrichments across 7 behavioral lenses.
 * 
 * For each enrichment:
 * - NAME: Exact canonical name (case + spacing must match)
 * - SHORT_DESCRIPTION: Brief explanation of what the enrichment measures
 * - SCORING_DIRECTIONALITY: How to interpret high vs low scores
 * 
 * TODO: All descriptions marked with "TODO" must be backfilled from the 
 * official Enrichment Dictionary in Google Drive.
 */

export interface EnrichmentDefinition {
  key: string;
  name: string;
  shortDescription: string;
  scoringDirectionality: string;
}

// ============================================================================
// CANONICAL ENRICHMENT DICTIONARY (113 enrichments)
// ============================================================================

export const enrichmentDictionary: Record<string, EnrichmentDefinition> = {
  // CHANNEL ENGAGEMENT & REACHABILITY
  emailEngagement: {
    key: "emailEngagement",
    name: "Email Engagement Score",
    shortDescription: "TODO: Measures responsiveness to email outreach and engagement patterns",
    scoringDirectionality: "High = strong email responsiveness; Low = low email receptivity"
  },
  smsEngagement: {
    key: "smsEngagement",
    name: "Sms Engagement Score",
    shortDescription: "TODO: Measures responsiveness to SMS/text message outreach",
    scoringDirectionality: "High = strong SMS responsiveness; Low = low SMS receptivity"
  },
  digitalAdResponsiveness: {
    key: "digitalAdResponsiveness",
    name: "Digital Ad Responsiveness Score",
    shortDescription: "TODO: Measures likelihood to engage with digital advertising",
    scoringDirectionality: "High = ad-responsive; Low = ad-resistant"
  },
  influencerResponsiveness: {
    key: "influencerResponsiveness",
    name: "Influencer Responsiveness Score",
    shortDescription: "TODO: Measures susceptibility to influencer recommendations",
    scoringDirectionality: "High = influencer-responsive; Low = influencer-resistant"
  },
  mobileEngagement: {
    key: "mobileEngagement",
    name: "Mobile Engagement Score",
    shortDescription: "TODO: Measures preference for mobile device interactions",
    scoringDirectionality: "High = mobile-first user; Low = desktop preference"
  },
  desktopEngagement: {
    key: "desktopEngagement",
    name: "Desktop Engagement Score",
    shortDescription: "TODO: Measures preference for desktop device interactions",
    scoringDirectionality: "High = desktop-first user; Low = mobile preference"
  },
  mediaLayerSaturation: {
    key: "mediaLayerSaturation",
    name: "Media Layer Saturation Score",
    shortDescription: "TODO: Measures exposure to multiple media layers and channels",
    scoringDirectionality: "High = highly saturated media environment; Low = limited media exposure"
  },
  daypartResponsiveness: {
    key: "daypartResponsiveness",
    name: "Daypart Responsiveness Score",
    shortDescription: "TODO: Measures sensitivity to time-of-day messaging patterns",
    scoringDirectionality: "High = strong time-of-day patterns; Low = consistent across dayparts"
  },
  weekdayVsWeekendActivity: {
    key: "weekdayVsWeekendActivity",
    name: "Weekday Vs Weekend Activity Score",
    shortDescription: "TODO: Measures activity patterns across weekdays vs weekends",
    scoringDirectionality: "High = weekend-oriented; Low = weekday-oriented"
  },
  recencyFrequencyWindow: {
    key: "recencyFrequencyWindow",
    name: "Recency Frequency Window Rfw Score",
    shortDescription: "TODO: Measures recency and frequency of engagement",
    scoringDirectionality: "High = recent and frequent engagement; Low = dormant or sporadic"
  },
  realWorldVsDigitalBias: {
    key: "realWorldVsDigitalBias",
    name: "Real World Vs Digital Bias Score",
    shortDescription: "TODO: Measures preference for physical vs digital interactions",
    scoringDirectionality: "High = real-world bias; Low = digital-first"
  },
  realWorldVersusDigitalWorldBias: {
    key: "realWorldVersusDigitalWorldBias",
    name: "Real World Versus Digital World Bias Score",
    shortDescription: "TODO: Measures preference for physical vs digital world engagement",
    scoringDirectionality: "High = real-world bias; Low = digital-first"
  },
  trendSensitivity: {
    key: "trendSensitivity",
    name: "Trend Sensitivity Score",
    shortDescription: "TODO: Measures responsiveness to trends and trending content",
    scoringDirectionality: "High = trend-driven; Low = trend-resistant"
  },
  repetitiveReceptivity: {
    key: "repetitiveReceptivity",
    name: "Repetitive Receptivity Score",
    shortDescription: "TODO: Measures tolerance for repeated messaging",
    scoringDirectionality: "High = tolerates repetition well; Low = message fatigue sensitive"
  },
  socialResponsiveness: {
    key: "socialResponsiveness",
    name: "Social Responsiveness Score",
    shortDescription: "TODO: Measures engagement with social media channels",
    scoringDirectionality: "High = highly social media responsive; Low = social media resistant"
  },

  // PURCHASE DRIVERS & FINANCIAL BEHAVIOR
  impulseBuyLikelihood: {
    key: "impulseBuyLikelihood",
    name: "Impulse Buy Likelihood Engagement Score",
    shortDescription: "TODO: Measures tendency toward spontaneous purchases",
    scoringDirectionality: "High = impulse buyer; Low = deliberate purchaser"
  },
  subscriptionPurchaseReadiness: {
    key: "subscriptionPurchaseReadiness",
    name: "Subscription Purchase Readiness Score",
    shortDescription: "TODO: Measures openness to subscription-based purchases",
    scoringDirectionality: "High = subscription-ready; Low = prefers one-time purchases"
  },
  subscriptionPurchase: {
    key: "subscriptionPurchase",
    name: "Subscription Purchase Score",
    shortDescription: "TODO: Measures affinity for subscription models",
    scoringDirectionality: "High = subscription-friendly; Low = prefers one-time purchases"
  },
  subscriptionFatigue: {
    key: "subscriptionFatigue",
    name: "Subscription Fatigue Score",
    shortDescription: "TODO: Measures resistance to additional subscriptions",
    scoringDirectionality: "High = subscription fatigued; Low = open to subscriptions"
  },
  trailWillingness: {
    key: "trailWillingness",
    name: "Trail Willingness Score",
    shortDescription: "TODO: Measures willingness to try new products/services",
    scoringDirectionality: "High = willing to try new things; Low = stick to known options"
  },
  dealHuntingTendency: {
    key: "dealHuntingTendency",
    name: "Deal Hunting Tendency Score",
    shortDescription: "TODO: Measures active seeking of deals and discounts",
    scoringDirectionality: "High = active deal seeker; Low = deal-indifferent"
  },
  couponResponsiveness: {
    key: "couponResponsiveness",
    name: "Coupon Responsiveness Score",
    shortDescription: "TODO: Measures responsiveness to coupon and promo offers",
    scoringDirectionality: "High = coupon-driven; Low = coupon-indifferent"
  },
  valueSeekingBehavior: {
    key: "valueSeekingBehavior",
    name: "Value Seeking Behavior Score",
    shortDescription: "TODO: Measures prioritization of value in purchase decisions",
    scoringDirectionality: "High = value-first buyer; Low = brand/quality first"
  },
  bargainVsQualityBias: {
    key: "bargainVsQualityBias",
    name: "Bargain Vs Quality Bias Score",
    shortDescription: "TODO: Measures trade-off preference between price and quality",
    scoringDirectionality: "High = bargain-focused; Low = quality-focused"
  },
  loyaltyProgramResponsiveness: {
    key: "loyaltyProgramResponsiveness",
    name: "Loyalty Program Responsiveness Score",
    shortDescription: "TODO: Measures engagement with loyalty programs",
    scoringDirectionality: "High = loyalty program engaged; Low = loyalty program indifferent"
  },
  brandLoyalty: {
    key: "brandLoyalty",
    name: "Brand Loyalty Score",
    shortDescription: "TODO: Measures commitment to preferred brands",
    scoringDirectionality: "High = brand loyal; Low = brand switcher"
  },
  brandSwitchingRisk: {
    key: "brandSwitchingRisk",
    name: "Brand Switching Risk Score",
    shortDescription: "TODO: Measures likelihood to switch between brands",
    scoringDirectionality: "High = brand switcher; Low = brand loyal"
  },
  luxuryPurchaseTendency: {
    key: "luxuryPurchaseTendency",
    name: "Luxury Purchase Tendency Score",
    shortDescription: "TODO: Measures affinity for luxury and premium products",
    scoringDirectionality: "High = luxury buyer; Low = practical buyer"
  },
  exclusivityAffinity: {
    key: "exclusivityAffinity",
    name: "Exclusivity Affinity Score",
    shortDescription: "TODO: Measures attraction to exclusive and limited products",
    scoringDirectionality: "High = exclusivity-seeking; Low = mainstream preference"
  },
  timeToPurchaseSensitivity: {
    key: "timeToPurchaseSensitivity",
    name: "Time To Purchase Sensitivity Score",
    shortDescription: "TODO: Measures speed from consideration to purchase",
    scoringDirectionality: "High = fast decision; Low = long consideration"
  },
  urgencyResponsiveness: {
    key: "urgencyResponsiveness",
    name: "Urgency Responsiveness Score",
    shortDescription: "TODO: Measures responsiveness to urgency and scarcity tactics",
    scoringDirectionality: "High = urgency-responsive; Low = urgency-resistant"
  },
  overExtensionRisk: {
    key: "overExtensionRisk",
    name: "Over Extension Risk Score",
    shortDescription: "TODO: Measures risk of financial overextension",
    scoringDirectionality: "High = financial overextension risk; Low = financially cautious"
  },
  financialCautiousness: {
    key: "financialCautiousness",
    name: "Financial Cautiousness Score",
    shortDescription: "TODO: Measures cautious approach to financial decisions",
    scoringDirectionality: "High = financially cautious; Low = financially risk-tolerant"
  },
  financialOptimization: {
    key: "financialOptimization",
    name: "Financial Optimization Score",
    shortDescription: "TODO: Measures effort to optimize financial outcomes",
    scoringDirectionality: "High = financial optimizer; Low = convenience over optimization"
  },
  riskTolerance: {
    key: "riskTolerance",
    name: "Risk Tolerance Score",
    shortDescription: "TODO: Measures comfort with risk and uncertainty",
    scoringDirectionality: "High = risk-tolerant; Low = risk-averse"
  },
  riskMitigation: {
    key: "riskMitigation",
    name: "Risk Mitigation Score",
    shortDescription: "TODO: Measures active efforts to reduce risk",
    scoringDirectionality: "High = actively mitigates risk; Low = comfortable with uncertainty"
  },
  riskMitigationBehavior: {
    key: "riskMitigationBehavior",
    name: "Risk Mitigation Behavior Score",
    shortDescription: "TODO: Measures behavioral patterns around risk reduction",
    scoringDirectionality: "High = actively mitigates risk; Low = comfortable with uncertainty"
  },
  purchaseRationality: {
    key: "purchaseRationality",
    name: "Purchase Rationality Score",
    shortDescription: "TODO: Measures logical vs emotional purchase approach",
    scoringDirectionality: "High = rational purchaser; Low = emotional purchaser"
  },
  convenienceOverQuality: {
    key: "convenienceOverQuality",
    name: "Convenience Over Quality Score",
    shortDescription: "TODO: Measures prioritization of convenience vs quality",
    scoringDirectionality: "High = convenience-first; Low = quality-first"
  },
  localityAffinity: {
    key: "localityAffinity",
    name: "Locality Affinity Score",
    shortDescription: "TODO: Measures preference for local products and services",
    scoringDirectionality: "High = local preference; Low = indifferent to origin"
  },
  ethicalConsumptionSensitivity: {
    key: "ethicalConsumptionSensitivity",
    name: "Ethical Consumption Sensitivity Score",
    shortDescription: "TODO: Measures consideration of ethical factors in purchases",
    scoringDirectionality: "High = ethical consumer; Low = value-driven consumer"
  },
  noveltySeekingBehavior: {
    key: "noveltySeekingBehavior",
    name: "Novelty Seeking Behavior Score",
    shortDescription: "TODO: Measures attraction to new and novel products",
    scoringDirectionality: "High = novelty seeker; Low = traditional preference"
  },

  // MESSAGING, CONTENT & INFLUENCE PATHWAYS
  // influencerResponsiveness already defined above
  expectResponsiveness: {
    key: "expectResponsiveness",
    name: "Expect Responsiveness Score",
    shortDescription: "TODO: Measures responsiveness to expert opinions",
    scoringDirectionality: "High = expert-responsive; Low = skeptical of experts"
  },
  authorityResponse: {
    key: "authorityResponse",
    name: "Authority Response Score",
    shortDescription: "TODO: Measures responsiveness to authority figures",
    scoringDirectionality: "High = authority-responsive; Low = questions authority"
  },
  authorityDefiance: {
    key: "authorityDefiance",
    name: "Authority Defiance Score",
    shortDescription: "TODO: Measures tendency to resist authority",
    scoringDirectionality: "High = authority defiant; Low = authority accepting"
  },
  relationshipReliance: {
    key: "relationshipReliance",
    name: "Relationship Reliance Score",
    shortDescription: "TODO: Measures importance of relationships in decisions",
    scoringDirectionality: "High = relationship-driven; Low = transaction-driven"
  },
  socialValidationSensitivity: {
    key: "socialValidationSensitivity",
    name: "Social Validation Sensitivity Score",
    shortDescription: "TODO: Measures need for social proof and validation",
    scoringDirectionality: "High = social proof dependent; Low = independent decision maker"
  },
  socialValidationDependence: {
    key: "socialValidationDependence",
    name: "Social Validation Dependence Score",
    shortDescription: "TODO: Measures dependency on social validation",
    scoringDirectionality: "High = needs social validation; Low = self-validated"
  },
  trustSignalSensitivity: {
    key: "trustSignalSensitivity",
    name: "Trust Signal Sensitivity Score",
    shortDescription: "TODO: Measures responsiveness to trust signals",
    scoringDirectionality: "High = trust signal sensitive; Low = trust signal indifferent"
  },
  skepticism: {
    key: "skepticism",
    name: "Skepticism Score",
    shortDescription: "TODO: Measures general skeptical orientation",
    scoringDirectionality: "High = skeptical; Low = trusting"
  },
  narrativePersuasion: {
    key: "narrativePersuasion",
    name: "Narrative Persuasion Score",
    shortDescription: "TODO: Measures responsiveness to narrative storytelling",
    scoringDirectionality: "High = story-responsive; Low = fact-responsive"
  },
  narrativeFramingVictimVsHeroIdentity: {
    key: "narrativeFramingVictimVsHeroIdentity",
    name: "Narrative Framing Victim Vs Hero Identity Score",
    shortDescription: "TODO: Measures narrative identity preference",
    scoringDirectionality: "High = hero narrative; Low = victim narrative"
  },
  identityAnchoring: {
    key: "identityAnchoring",
    name: "Identity Anchoring Score",
    shortDescription: "TODO: Measures strength of identity-based decisions",
    scoringDirectionality: "High = identity-driven; Low = pragmatic"
  },
  emotionallyChargedResponse: {
    key: "emotionallyChargedResponse",
    name: "Emotionally Charged Response Score",
    shortDescription: "TODO: Measures emotional intensity in responses",
    scoringDirectionality: "High = emotionally charged responses; Low = measured responses"
  },
  informationOverloadTolerance: {
    key: "informationOverloadTolerance",
    name: "Information Overload Tolerance Score",
    shortDescription: "TODO: Measures ability to handle complex information",
    scoringDirectionality: "High = handles complexity well; Low = prefers simplicity"
  },
  intellectualEngagement: {
    key: "intellectualEngagement",
    name: "Intellectual Engagement Score",
    shortDescription: "TODO: Measures engagement with intellectual content",
    scoringDirectionality: "High = intellectually engaged; Low = pragmatically focused"
  },
  experientialLearning: {
    key: "experientialLearning",
    name: "Experiential Learning Score",
    shortDescription: "TODO: Measures preference for learning through experience",
    scoringDirectionality: "High = experiential learner; Low = theoretical learner"
  },
  algorithmTrust: {
    key: "algorithmTrust",
    name: "Algorithm Trust Score",
    shortDescription: "TODO: Measures trust in algorithmic recommendations",
    scoringDirectionality: "High = trusts algorithms; Low = skeptical of algorithms"
  },
  brandIdealismAlignment: {
    key: "brandIdealismAlignment",
    name: "Brand Idealism Alignment Score",
    shortDescription: "TODO: Measures alignment with brand values and ideals",
    scoringDirectionality: "High = idealistic about brands; Low = pragmatic about brands"
  },
  ethicalGuidelines: {
    key: "ethicalGuidelines",
    name: "Ethical Guidelines Score",
    shortDescription: "TODO: Measures importance of ethical considerations",
    scoringDirectionality: "High = ethics-driven; Low = pragmatically focused"
  },
  // ethicalConsumptionSensitivity already defined above
  deiAlignment: {
    key: "deiAlignment",
    name: "Dei Alignment Score",
    shortDescription: "TODO: Measures alignment with DEI values",
    scoringDirectionality: "High = DEI-aligned; Low = DEI-indifferent"
  },
  policyFocusedPersuasion: {
    key: "policyFocusedPersuasion",
    name: "Policy Focused Persuasion Score",
    shortDescription: "TODO: Measures responsiveness to policy-focused messaging",
    scoringDirectionality: "High = policy-responsive; Low = policy-indifferent"
  },
  politicalMobilizability: {
    key: "politicalMobilizability",
    name: "Political Mobilizability Score",
    shortDescription: "TODO: Measures likelihood of political engagement",
    scoringDirectionality: "High = politically mobilizable; Low = politically disengaged"
  },
  hopeOrientation: {
    key: "hopeOrientation",
    name: "Hope Orientation Score",
    shortDescription: "TODO: Measures orientation toward hopeful outcomes",
    scoringDirectionality: "High = hope-oriented; Low = pessimistic"
  },
  nostalgiaAffinity: {
    key: "nostalgiaAffinity",
    name: "Nostalgia Affinity Score",
    shortDescription: "TODO: Measures attraction to nostalgic themes",
    scoringDirectionality: "High = nostalgia-driven; Low = future-focused"
  },
  opennessToConspiracyNonMainstreamIdeas: {
    key: "opennessToConspiracyNonMainstreamIdeas",
    name: "Openness To Conspiracy Non Mainstream Ideas Score",
    shortDescription: "TODO: Measures openness to alternative narratives",
    scoringDirectionality: "High = open to alternative narratives; Low = mainstream thinking"
  },
  // trendSensitivity already defined above
  // mediaLayerSaturation already defined above

  // DECISION STYLE & TRUST DYNAMICS
  researchDept: {
    key: "researchDept",
    name: "Research Dept Score",
    shortDescription: "TODO: Measures depth of research before decisions",
    scoringDirectionality: "High = deep researcher; Low = minimal research"
  },
  deliberativeDecisionMaking: {
    key: "deliberativeDecisionMaking",
    name: "Deliberative Decision Making Score",
    shortDescription: "TODO: Measures deliberation in decision-making process",
    scoringDirectionality: "High = deliberative; Low = fast decision maker"
  },
  rationalismVsEmotionalIntuition: {
    key: "rationalismVsEmotionalIntuition",
    name: "Rationalism Vs Emotional Intuition Score",
    shortDescription: "TODO: Measures rational vs intuitive decision style",
    scoringDirectionality: "High = rational; Low = intuitive/emotional"
  },
  temporalOrientation: {
    key: "temporalOrientation",
    name: "Temporal Orientation Score",
    shortDescription: "TODO: Measures future vs present orientation",
    scoringDirectionality: "High = future-oriented; Low = present-oriented"
  },
  controlLocusInternalVsExternal: {
    key: "controlLocusInternalVsExternal",
    name: "Control Locus Internal Vs External Score",
    shortDescription: "TODO: Measures perceived locus of control",
    scoringDirectionality: "High = internal locus; Low = external locus"
  },
  stabilityVsChangePreference: {
    key: "stabilityVsChangePreference",
    name: "Stability Vs Change Preference Score",
    shortDescription: "TODO: Measures preference for stability vs change",
    scoringDirectionality: "High = change-seeking; Low = stability-seeking"
  },
  individualismVsCollectivism: {
    key: "individualismVsCollectivism",
    name: "Individualism Vs Collectivism Score",
    shortDescription: "TODO: Measures individualistic vs collectivistic orientation",
    scoringDirectionality: "High = individualistic; Low = collectivistic"
  },
  civicEngagementAndAgency: {
    key: "civicEngagementAndAgency",
    name: "Civic Engagement And Agency Score",
    shortDescription: "TODO: Measures civic participation and sense of agency",
    scoringDirectionality: "High = civically engaged; Low = civically disengaged"
  },
  institutionalTrustAndSkepticism: {
    key: "institutionalTrustAndSkepticism",
    name: "Institutional Trust And Skepticism Score",
    shortDescription: "TODO: Measures trust in institutions",
    scoringDirectionality: "High = trusts institutions; Low = institutional skeptic"
  },
  freedomVsSecurityTradeOffTendency: {
    key: "freedomVsSecurityTradeOffTendency",
    name: "Freedom Vs Security Trade Off Tendency Score",
    shortDescription: "TODO: Measures preference in freedom-security tradeoff",
    scoringDirectionality: "High = freedom-prioritizing; Low = security-prioritizing"
  },
  moralAbsolutismVsRelativism: {
    key: "moralAbsolutismVsRelativism",
    name: "Moral Absolutism Vs Relativism Score",
    shortDescription: "TODO: Measures moral absolutism vs relativism",
    scoringDirectionality: "High = moral absolutist; Low = moral relativist"
  },
  // riskTolerance already defined above
  // riskMitigation already defined above
  // riskMitigationBehavior already defined above
  // informationOverloadTolerance already defined above
  // intellectualEngagement already defined above
  psychologicalSecurity: {
    key: "psychologicalSecurity",
    name: "Psychological Security Score",
    shortDescription: "TODO: Measures sense of psychological security",
    scoringDirectionality: "High = psychologically secure; Low = insecure"
  },
  psychologicalSecuritySeeking: {
    key: "psychologicalSecuritySeeking",
    name: "Psychological Security Seeking Score",
    shortDescription: "TODO: Measures seeking of psychological security",
    scoringDirectionality: "High = security-seeking; Low = risk-comfortable"
  },
  polarizationTolerance: {
    key: "polarizationTolerance",
    name: "Polarization Tolerance Score",
    shortDescription: "TODO: Measures tolerance for divergent views",
    scoringDirectionality: "High = tolerant of polarization; Low = seeks consensus"
  },
  // experientialLearning already defined above
  zeroSumVsAbundanceMindset: {
    key: "zeroSumVsAbundanceMindset",
    name: "Zero Sum Vs Abundance Mindset Score",
    shortDescription: "TODO: Measures zero-sum vs abundance thinking",
    scoringDirectionality: "High = abundance mindset; Low = zero-sum mindset"
  },
  technologicalOptimismVsTechSkepticism: {
    key: "technologicalOptimismVsTechSkepticism",
    name: "Technological Optimism Vs Tech Skepticism Score",
    shortDescription: "TODO: Measures tech optimism vs skepticism",
    scoringDirectionality: "High = tech optimist; Low = tech skeptic"
  },
  // algorithmTrust already defined above
  tribeConformity: {
    key: "tribeConformity",
    name: "Tribe Conformity Score",
    shortDescription: "TODO: Measures conformity to tribe/group norms",
    scoringDirectionality: "High = tribe conforming; Low = independent"
  },
  conformityVsIndividualExpression: {
    key: "conformityVsIndividualExpression",
    name: "Conformity Vs Individual Expression Score",
    shortDescription: "TODO: Measures conformity vs individual expression",
    scoringDirectionality: "High = individual expression; Low = conformity"
  },

  // VALUES, IDEOLOGY & WORLDVIEW ALIGNMENT
  // ethicalGuidelines already defined above
  environmentalRiskAversion: {
    key: "environmentalRiskAversion",
    name: "Environmental Risk Aversion Score",
    shortDescription: "TODO: Measures environmental consciousness and concern",
    scoringDirectionality: "High = environmentally conscious; Low = environmental indifferent"
  },
  patrioticAlignment: {
    key: "patrioticAlignment",
    name: "Patriotic Alignment Score",
    shortDescription: "TODO: Measures patriotic sentiment and alignment",
    scoringDirectionality: "High = patriotically aligned; Low = globally oriented"
  },
  // deiAlignment already defined above
  religiousAlignment: {
    key: "religiousAlignment",
    name: "Religious Alignment Score",
    shortDescription: "TODO: Measures religious alignment and importance",
    scoringDirectionality: "High = religiously aligned; Low = secular"
  },
  religiousValueAlignment: {
    key: "religiousValueAlignment",
    name: "Religious Value Alignment Score",
    shortDescription: "TODO: Measures alignment with religious values",
    scoringDirectionality: "High = religiously aligned; Low = secular"
  },
  // brandIdealismAlignment already defined above
  // policyFocusedPersuasion already defined above
  // politicalMobilizability already defined above
  authoritarianVsLibertarianTendencies: {
    key: "authoritarianVsLibertarianTendencies",
    name: "Authoritarian Vs Libertarian Tendencies Score",
    shortDescription: "TODO: Measures authoritarian vs libertarian leanings",
    scoringDirectionality: "High = libertarian; Low = authoritarian"
  },
  // freedomVsSecurityTradeOffTendency already defined above
  // zeroSumVsAbundanceMindset already defined above
  materialismVsMeaningOrientation: {
    key: "materialismVsMeaningOrientation",
    name: "Materialism Vs Meaning Orientation Score",
    shortDescription: "TODO: Measures material vs meaning-driven orientation",
    scoringDirectionality: "High = meaning-oriented; Low = materialism-oriented"
  },
  // opennessToConspiracyNonMainstreamIdeas already defined above
  // institutionalTrustAndSkepticism already defined above
  // technologicalOptimismVsTechSkepticism already defined above
  // civicEngagementAndAgency already defined above
  civicEngagementIntensity: {
    key: "civicEngagementIntensity",
    name: "Civic Engagement Intensity Score",
    shortDescription: "TODO: Measures intensity of civic engagement",
    scoringDirectionality: "High = intensely engaged; Low = minimally engaged"
  },
  localIdeologyConsistency: {
    key: "localIdeologyConsistency",
    name: "Local Ideology Consistency Score",
    shortDescription: "TODO: Measures consistency with local ideological norms",
    scoringDirectionality: "High = ideologically consistent with area; Low = ideological outlier"
  },
  // moralAbsolutismVsRelativism already defined above

  // EMOTIONAL & PSYCHOGRAPHIC ORIENTATION
  emotionalSensitivity: {
    key: "emotionalSensitivity",
    name: "Emotional Sensitivity Score",
    shortDescription: "TODO: Measures emotional sensitivity and reactiveness",
    scoringDirectionality: "High = emotionally sensitive; Low = emotionally resilient"
  },
  emotionalReactivity: {
    key: "emotionalReactivity",
    name: "Emotional Reactivity Score",
    shortDescription: "TODO: Measures speed and intensity of emotional reactions",
    scoringDirectionality: "High = emotionally reactive; Low = emotionally stable"
  },
  emotionalVolatilityIndex: {
    key: "emotionalVolatilityIndex",
    name: "Emotional Volatility Index Score",
    shortDescription: "TODO: Measures volatility in emotional states",
    scoringDirectionality: "High = emotionally volatile; Low = emotionally stable"
  },
  anxietySensitivity: {
    key: "anxietySensitivity",
    name: "Anxiety Sensitivity Score",
    shortDescription: "TODO: Measures sensitivity to anxiety-inducing situations",
    scoringDirectionality: "High = anxiety-sensitive; Low = anxiety-resilient"
  },
  optimismBias: {
    key: "optimismBias",
    name: "Optimism Bias Score",
    shortDescription: "TODO: Measures optimistic outlook and bias",
    scoringDirectionality: "High = optimistic; Low = pessimistic"
  },
  // hopeOrientation already defined above
  empathyResponsiveness: {
    key: "empathyResponsiveness",
    name: "Empathy Responsiveness Score",
    shortDescription: "TODO: Measures empathetic responsiveness to others",
    scoringDirectionality: "High = highly empathetic; Low = low empathy"
  },
  frustrationTolerance: {
    key: "frustrationTolerance",
    name: "Frustration Tolerance Score",
    shortDescription: "TODO: Measures tolerance for frustration and setbacks",
    scoringDirectionality: "High = frustration-tolerant; Low = frustration-sensitive"
  },
  // psychologicalSecurity already defined above
  // psychologicalSecuritySeeking already defined above
  shameAversion: {
    key: "shameAversion",
    name: "Shame Aversion Score",
    shortDescription: "TODO: Measures avoidance of shame and embarrassment",
    scoringDirectionality: "High = shame-avoidant; Low = shame-resilient"
  },
  // nostalgiaAffinity already defined above
  // materialismVsMeaningOrientation already defined above
  // conformityVsIndividualExpression already defined above
  // tribeConformity already defined above
  // socialValidationSensitivity already defined above
  // socialValidationDependence already defined above
  anonymityDesire: {
    key: "anonymityDesire",
    name: "Anonymity Desire Score",
    shortDescription: "TODO: Measures desire for anonymity and privacy",
    scoringDirectionality: "High = privacy-seeking; Low = open/public"
  },
  privacySensitivity: {
    key: "privacySensitivity",
    name: "Privacy Sensitivity Score",
    shortDescription: "TODO: Measures sensitivity to privacy concerns",
    scoringDirectionality: "High = privacy-sensitive; Low = privacy-indifferent"
  },
  // noveltySeekingBehavior already defined above
  // emotionallyChargedResponse already defined above
  // identityAnchoring already defined above

  // SOCIAL & CULTURAL CONTEXT (ZIP / COMMUNITY-LEVEL)
  localOutlier: {
    key: "localOutlier",
    name: "Local Outlier Score",
    shortDescription: "TODO: Measures deviation from local behavioral norms",
    scoringDirectionality: "High = local outlier; Low = neighborhood conformer"
  },
  neighborhoodHomogeneity: {
    key: "neighborhoodHomogeneity",
    name: "Neighborhood Homogeneity Score",
    shortDescription: "TODO: Measures homogeneity of neighborhood characteristics",
    scoringDirectionality: "High = homogeneous neighborhood; Low = diverse neighborhood"
  },
  socialExposure: {
    key: "socialExposure",
    name: "Social Exposure Score",
    shortDescription: "TODO: Measures level of social exposure and connectivity",
    scoringDirectionality: "High = high social exposure; Low = isolated"
  },
  culturalAffinityIndex: {
    key: "culturalAffinityIndex",
    name: "Cultural Affinity Index Score",
    shortDescription: "TODO: Measures cultural affinity and alignment",
    scoringDirectionality: "High = strong cultural affinity; Low = weak cultural ties"
  },
  communityVelocity: {
    key: "communityVelocity",
    name: "Community Velocity Score",
    shortDescription: "TODO: Measures rate of community change",
    scoringDirectionality: "High = fast-changing community; Low = stable community"
  },
  conformityPressureIndex: {
    key: "conformityPressureIndex",
    name: "Conformity Pressure Index Score",
    shortDescription: "TODO: Measures conformity pressure in community",
    scoringDirectionality: "High = high conformity pressure; Low = individualistic environment"
  },
  geoSocialInfluenceDensity: {
    key: "geoSocialInfluenceDensity",
    name: "Geo Social Influence Density Score",
    shortDescription: "TODO: Measures density of social influence in area",
    scoringDirectionality: "High = high social influence density; Low = low influence density"
  },
  behavioralDisparity: {
    key: "behavioralDisparity",
    name: "Behavioral Disparity Score",
    shortDescription: "TODO: Measures disparity from local behavioral norms",
    scoringDirectionality: "High = high disparity from local norms; Low = aligned with local norms"
  },
  civicCohesion: {
    key: "civicCohesion",
    name: "Civic Cohesion Score",
    shortDescription: "TODO: Measures civic cohesion in community",
    scoringDirectionality: "High = strong civic engagement; Low = low civic engagement"
  },
  sprawlIntensityIndex: {
    key: "sprawlIntensityIndex",
    name: "Sprawl Intensity Index Score",
    shortDescription: "TODO: Measures urban sprawl intensity",
    scoringDirectionality: "High = high sprawl; Low = dense/urban"
  },
  geoEconomicPressure: {
    key: "geoEconomicPressure",
    name: "Geo Economic Pressure Score",
    shortDescription: "TODO: Measures economic pressure in geographic area",
    scoringDirectionality: "High = high economic pressure; Low = economic security"
  },
  // localIdeologyConsistency already defined above
  // localityAffinity already defined above
  // civicEngagementIntensity already defined above

  // IDENTITY, LIFESTYLE & LIFE STAGE (0-6 SUB-MODELS)
  gender_polarity_scale: {
    key: "gender_polarity_scale",
    name: "Gender Polarity Scale (GPS)",
    shortDescription: "Balance of masculine vs feminine-coded interests and behaviors.",
    scoringDirectionality: "Scale: 0 = strongly feminine-coded, 6 = strongly masculine-coded"
  },
  tradition_vs_progress: {
    key: "tradition_vs_progress",
    name: "Tradition vs Progress Scale",
    shortDescription: "Orientation toward traditional values vs progress-oriented change.",
    scoringDirectionality: "Scale: 0 = tradition-oriented, 6 = progress-oriented"
  },
  localism_vs_globalism: {
    key: "localism_vs_globalism",
    name: "Localism vs Globalism Orientation",
    shortDescription: "Local/community-first vs global/cosmopolitan identity.",
    scoringDirectionality: "Scale: 0 = local/community-first, 6 = global/cosmopolitan"
  },
  health_vitality_spectrum: {
    key: "health_vitality_spectrum",
    name: "Health Vitality Spectrum",
    shortDescription: "Health mindset from fragile/declining to high-vitality optimizer.",
    scoringDirectionality: "Scale: 0 = fragile/declining health, 6 = high-vitality optimizer"
  },
  family_orientation_spectrum: {
    key: "family_orientation_spectrum",
    name: "Family Orientation Spectrum",
    shortDescription: "Individual/child-free vs strongly family-centric priorities.",
    scoringDirectionality: "Scale: 0 = single/child-free, 6 = strongly family-centric"
  },
  economic_anxiety_index: {
    key: "economic_anxiety_index",
    name: "Economic Anxiety Index",
    shortDescription: "Financial mindset from surplus to deficit/budget-strained.",
    scoringDirectionality: "Scale: 0 = surplus mindset, 6 = deficit/budget-strained"
  },
  digital_tribalism_spectrum: {
    key: "digital_tribalism_spectrum",
    name: "Digital Tribalism Spectrum",
    shortDescription: "Strength of tribal identity and in-group solidarity.",
    scoringDirectionality: "Scale: 0 = low tribalism, 6 = strong tribal identity"
  },
  consumption_identity_index: {
    key: "consumption_identity_index",
    name: "Consumption Identity Index",
    shortDescription: "Degree to which consumption defines personal identity.",
    scoringDirectionality: "Scale: 0 = consumption-independent identity, 6 = identity through consumption"
  },
  age_perception_score: {
    key: "age_perception_score",
    name: "Age Perception Index",
    shortDescription: "How youthful vs mature the individual's lifestyle and mindset appear.",
    scoringDirectionality: "Scale: 0 = youthful/early life stage, 6 = mature/later life stage"
  },
  civic_identity_spectrum: {
    key: "civic_identity_spectrum",
    name: "Civic Identity Spectrum",
    shortDescription: "Level of civic participation and community involvement.",
    scoringDirectionality: "Scale: 0 = disengaged, 6 = highly civically engaged"
  },
};

// ============================================================================
// LENS-TO-ENRICHMENT MAPPINGS (Canonical, Ordered)
// ============================================================================

export const lensEnrichmentMapping = {
  channel: [
    "emailEngagement",
    "smsEngagement",
    "digitalAdResponsiveness",
    "influencerResponsiveness",
    "mobileEngagement",
    "desktopEngagement",
    "mediaLayerSaturation",
    "daypartResponsiveness",
    "weekdayVsWeekendActivity",
    "recencyFrequencyWindow",
    "realWorldVsDigitalBias",
    "realWorldVersusDigitalWorldBias",
    "trendSensitivity",
    "repetitiveReceptivity",
    "socialResponsiveness",
  ],
  purchase: [
    "impulseBuyLikelihood",
    "subscriptionPurchaseReadiness",
    "subscriptionPurchase",
    "subscriptionFatigue",
    "trailWillingness",
    "dealHuntingTendency",
    "couponResponsiveness",
    "valueSeekingBehavior",
    "bargainVsQualityBias",
    "loyaltyProgramResponsiveness",
    "brandLoyalty",
    "brandSwitchingRisk",
    "luxuryPurchaseTendency",
    "exclusivityAffinity",
    "timeToPurchaseSensitivity",
    "urgencyResponsiveness",
    "overExtensionRisk",
    "financialCautiousness",
    "financialOptimization",
    "riskTolerance",
    "riskMitigation",
    "riskMitigationBehavior",
    "purchaseRationality",
    "convenienceOverQuality",
    "localityAffinity",
    "ethicalConsumptionSensitivity",
    "noveltySeekingBehavior",
  ],
  messaging: [
    "influencerResponsiveness",
    "expectResponsiveness",
    "authorityResponse",
    "authorityDefiance",
    "relationshipReliance",
    "socialValidationSensitivity",
    "socialValidationDependence",
    "trustSignalSensitivity",
    "skepticism",
    "narrativePersuasion",
    "narrativeFramingVictimVsHeroIdentity",
    "identityAnchoring",
    "emotionallyChargedResponse",
    "informationOverloadTolerance",
    "intellectualEngagement",
    "experientialLearning",
    "algorithmTrust",
    "brandIdealismAlignment",
    "ethicalGuidelines",
    "ethicalConsumptionSensitivity",
    "deiAlignment",
    "policyFocusedPersuasion",
    "politicalMobilizability",
    "hopeOrientation",
    "nostalgiaAffinity",
    "opennessToConspiracyNonMainstreamIdeas",
    "trendSensitivity",
    "mediaLayerSaturation",
  ],
  decision: [
    "researchDept",
    "deliberativeDecisionMaking",
    "rationalismVsEmotionalIntuition",
    "temporalOrientation",
    "controlLocusInternalVsExternal",
    "stabilityVsChangePreference",
    "individualismVsCollectivism",
    "civicEngagementAndAgency",
    "institutionalTrustAndSkepticism",
    "freedomVsSecurityTradeOffTendency",
    "moralAbsolutismVsRelativism",
    "riskTolerance",
    "riskMitigation",
    "riskMitigationBehavior",
    "informationOverloadTolerance",
    "intellectualEngagement",
    "psychologicalSecurity",
    "psychologicalSecuritySeeking",
    "polarizationTolerance",
    "experientialLearning",
    "zeroSumVsAbundanceMindset",
    "technologicalOptimismVsTechSkepticism",
    "algorithmTrust",
    "tribeConformity",
    "conformityVsIndividualExpression",
  ],
  values: [
    "ethicalGuidelines",
    "environmentalRiskAversion",
    "patrioticAlignment",
    "deiAlignment",
    "religiousAlignment",
    "religiousValueAlignment",
    "brandIdealismAlignment",
    "policyFocusedPersuasion",
    "politicalMobilizability",
    "authoritarianVsLibertarianTendencies",
    "freedomVsSecurityTradeOffTendency",
    "zeroSumVsAbundanceMindset",
    "materialismVsMeaningOrientation",
    "opennessToConspiracyNonMainstreamIdeas",
    "institutionalTrustAndSkepticism",
    "technologicalOptimismVsTechSkepticism",
    "civicEngagementAndAgency",
    "civicEngagementIntensity",
    "localIdeologyConsistency",
    "moralAbsolutismVsRelativism",
  ],
  emotional: [
    "emotionalSensitivity",
    "emotionalReactivity",
    "emotionalVolatilityIndex",
    "anxietySensitivity",
    "optimismBias",
    "hopeOrientation",
    "empathyResponsiveness",
    "frustrationTolerance",
    "psychologicalSecurity",
    "psychologicalSecuritySeeking",
    "shameAversion",
    "nostalgiaAffinity",
    "materialismVsMeaningOrientation",
    "conformityVsIndividualExpression",
    "tribeConformity",
    "socialValidationSensitivity",
    "socialValidationDependence",
    "anonymityDesire",
    "privacySensitivity",
    "noveltySeekingBehavior",
    "emotionallyChargedResponse",
    "identityAnchoring",
  ],
  context: [
    "localOutlier",
    "neighborhoodHomogeneity",
    "socialExposure",
    "culturalAffinityIndex",
    "communityVelocity",
    "conformityPressureIndex",
    "geoSocialInfluenceDensity",
    "behavioralDisparity",
    "civicCohesion",
    "sprawlIntensityIndex",
    "geoEconomicPressure",
    "localIdeologyConsistency",
    "localityAffinity",
    "civicEngagementIntensity",
  ],
  identity: [
    "gender_polarity_scale",
    "tradition_vs_progress",
    "localism_vs_globalism",
    "health_vitality_spectrum",
    "family_orientation_spectrum",
    "economic_anxiety_index",
    "digital_tribalism_spectrum",
    "consumption_identity_index",
    "age_perception_score",
    "civic_identity_spectrum",
  ],
};

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

/**
 * Get enrichment definitions for a specific lens.
 * Returns enrichments in the canonical order defined in lensEnrichmentMapping.
 */
export function getEnrichmentsForLens(lensId: string): EnrichmentDefinition[] {
  const enrichmentKeys = lensEnrichmentMapping[lensId as keyof typeof lensEnrichmentMapping] || [];
  return enrichmentKeys.map(key => enrichmentDictionary[key]).filter(Boolean);
}

/**
 * Get default visible columns for a lens.
 * Returns the first 6 enrichments for the lens.
 */
export function getDefaultColumnsForLens(lensId: string): EnrichmentDefinition[] {
  return getEnrichmentsForLens(lensId).slice(0, 6);
}

/**
 * Get all enrichments across all lenses (for export, etc).
 * Returns unique enrichments (deduplicated across lenses).
 */
export function getAllEnrichments(): EnrichmentDefinition[] {
  const allKeys = new Set<string>();
  Object.values(lensEnrichmentMapping).forEach(keys => {
    keys.forEach(key => allKeys.add(key));
  });
  return Array.from(allKeys).map(key => enrichmentDictionary[key]).filter(Boolean);
}

/**
 * Get friendly lens display name.
 */
export function getLensDisplayName(lensId: string): string {
  const names: Record<string, string> = {
    channel: "Channel Engagement & Reachability",
    purchase: "Purchase Drivers & Financial Behavior",
    messaging: "Messaging, Content & Influence Pathways",
    decision: "Decision Style & Trust Dynamics",
    values: "Values, Ideology & Worldview Alignment",
    emotional: "Emotional & Psychographic Orientation",
    context: "Social & Cultural Context (ZIP / Community-Level)",
    identity: "Identity, Lifestyle & Life Stage (Sub-Models)",
  };
  return names[lensId] || "Behavioral Lens";
}
// Lens-specific color and gradient system for Moonbrush

export type LensId = 'channel' | 'purchase' | 'messaging' | 'decision' | 'context' | 'emotional' | 'values' | 'identity';

interface LensColors {
  solid: string;
  gradient: string;
  lightBg: string;
}

export const lensColors: Record<LensId, LensColors> = {
  channel: {
    solid: '#06B6D4', // Teal
    gradient: 'linear-gradient(to right, #06B6D4, #2563EB)', // Teal → Blue
    lightBg: 'rgba(6, 182, 212, 0.08)',
  },
  purchase: {
    solid: '#16A34A', // Green
    gradient: 'linear-gradient(to right, #16A34A, #22C55E)', // Green → Light Green
    lightBg: 'rgba(22, 163, 74, 0.08)',
  },
  messaging: {
    solid: '#EC4899', // Pink
    gradient: 'linear-gradient(to right, #EC4899, #7C3AED)', // Pink → Purple
    lightBg: 'rgba(236, 72, 153, 0.08)',
  },
  decision: {
    solid: '#7C3AED', // Purple
    gradient: 'linear-gradient(to right, #7C3AED, #4F46E5)', // Purple → Indigo
    lightBg: 'rgba(124, 58, 237, 0.08)',
  },
  context: {
    solid: '#F97316', // Orange
    gradient: 'linear-gradient(to right, #F97316, #FB923C)', // Orange → Light Orange
    lightBg: 'rgba(249, 115, 22, 0.08)',
  },
  emotional: {
    solid: '#4F46E5', // Indigo
    gradient: 'linear-gradient(to right, #4F46E5, #7C3AED)', // Indigo → Purple
    lightBg: 'rgba(79, 70, 229, 0.08)',
  },
  values: {
    solid: '#9333EA', // Purple/Violet
    gradient: 'linear-gradient(to right, #9333EA, #C026D3)', // Purple → Magenta
    lightBg: 'rgba(147, 51, 234, 0.08)',
  },
  identity: {
    solid: '#0891B2', // Teal/Cyan
    gradient: 'linear-gradient(to right, #0891B2, #4F46E5)', // Teal → Indigo
    lightBg: 'rgba(8, 145, 178, 0.08)',
  },
};

export function getLensColors(lensId: string): LensColors {
  return lensColors[lensId as LensId] || lensColors.decision;
}

export function getLensSolidColor(lensId: string): string {
  return getLensColors(lensId).solid;
}

export function getLensGradient(lensId: string): string {
  return getLensColors(lensId).gradient;
}

export function getLensLightBg(lensId: string): string {
  return getLensColors(lensId).lightBg;
}
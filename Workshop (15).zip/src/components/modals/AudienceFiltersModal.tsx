import { X } from "lucide-react";
import { Button } from "../ui/button";

export function AudienceFiltersModal({
  isOpen,
  onClose,
}: {
  isOpen: boolean;
  onClose: () => void;
}) {
  // Base audience filters (read-only from Search)
  const baseFilters = [
    { field: "Job title", operator: "contains", value: "VP Finance" },
    { field: "Location", operator: "in", value: "CA" },
    { field: "Email Engagement", operator: "≥", value: "0.95" },
    { field: "Company Size", operator: "between", value: "51–500" },
  ];
  
  if (!isOpen) return null;
  
  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/30 z-50 flex items-center justify-center p-4"
        onClick={onClose}
      >
        {/* Modal */}
        <div 
          className="bg-white rounded-xl shadow-2xl w-full max-w-2xl max-h-[80vh] overflow-hidden flex flex-col"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="px-6 py-5 border-b border-gray-200 flex items-center justify-between">
            <h2 className="text-lg text-gray-900 font-semibold">Audience filters</h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <X className="w-5 h-5 text-gray-500" />
            </button>
          </div>
          
          {/* Content */}
          <div className="flex-1 overflow-y-auto px-6 py-6">
            {/* Intro Text */}
            <div className="mb-6">
              <p className="text-sm text-gray-700 mb-1">
                These filters were used to define this audience in Search.
              </p>
              <p className="text-xs text-gray-500">
                To change them, edit the audience in Search.
              </p>
            </div>
            
            {/* Base Audience Filters */}
            <div>
              <h3 className="text-sm text-gray-900 font-medium mb-4">Base audience (from Search)</h3>
              
              <div className="flex flex-wrap gap-2">
                {baseFilters.map((filter, idx) => (
                  <div 
                    key={idx}
                    className="inline-flex items-center px-3 py-2 rounded-full bg-gray-100 border border-gray-200"
                  >
                    <span className="text-xs">
                      <span className="text-gray-700 font-medium">{filter.field}</span>
                      {" "}
                      <span className="text-gray-500">{filter.operator}</span>
                      {" "}
                      <span className="text-gray-900 font-medium">{filter.value}</span>
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          {/* Footer */}
          <div className="px-6 py-4 border-t border-gray-200 flex justify-end">
            <Button
              variant="outline"
              onClick={onClose}
            >
              Close
            </Button>
          </div>
        </div>
      </div>
    </>
  );
}
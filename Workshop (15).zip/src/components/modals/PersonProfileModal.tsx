import { useState, useEffect } from "react";
import { X, ChevronLeft, Clock, Filter, TrendingUp, TrendingDown, Minus } from "lucide-react";
import { Button } from "../ui/button";

interface Person {
  name: string;
  title: string;
  company: string;
  companySize: string;
  location: string;
  [key: string]: string | number;
}

interface PersonProfileModalProps {
  person: Person | null;
  isOpen: boolean;
  onClose: () => void;
}

export function PersonProfileModal({ person, isOpen, onClose }: PersonProfileModalProps) {
  const [activeTab, setActiveTab] = useState<"overview" | "behavioral" | "identity" | "activity">("overview");

  // Add event listener for ESC key
  useEffect(() => {
    if (!isOpen) return;
    
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onClose();
      }
    };
    
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen || !person) return null;

  // Extract initials from name
  const initials = person.name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase();

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/30"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          onClose();
        }
      }}
    >
      {/* Fixed size modal shell - uses 85% viewport height, same dimensions for all tabs */}
      <div className="bg-white rounded-xl shadow-2xl w-[1100px] flex flex-col overflow-hidden" style={{ height: '85vh' }}>
        {/* Header */}
        <div className="border-b border-gray-200 px-6 pt-5 pb-4 flex-shrink-0">
          <div className="flex items-center justify-between mb-5">
            {/* Left - Back button */}
            <button
              onClick={onClose}
              className="flex items-center gap-2 text-sm text-gray-600 hover:text-gray-900 transition-colors"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Person preview</span>
            </button>

            {/* Center - Avatar and name */}
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-semibold text-sm flex-shrink-0">
                {initials}
              </div>
              <span className="text-sm font-medium text-gray-900">
                {person.name}
              </span>
            </div>

            {/* Right - Close button */}
            <button
              onClick={onClose}
              className="p-1.5 hover:bg-gray-100 rounded transition-colors"
            >
              <X className="w-5 h-5 text-gray-500" />
            </button>
          </div>

          {/* Tabs - Centered */}
          <div className="flex gap-1 justify-center border-b border-gray-200">
            <button
              onClick={() => setActiveTab("overview")}
              className={`px-4 py-2 text-sm font-medium transition-colors border-b-2 ${
                activeTab === "overview"
                  ? "text-blue-600 border-blue-600"
                  : "text-gray-600 hover:text-gray-900 border-transparent"
              }`}
            >
              Overview
            </button>
            <button
              onClick={() => setActiveTab("behavioral")}
              className={`px-4 py-2 text-sm font-medium transition-colors border-b-2 ${
                activeTab === "behavioral"
                  ? "text-blue-600 border-blue-600"
                  : "text-gray-600 hover:text-gray-900 border-transparent"
              }`}
            >
              Behavioral profile
            </button>
            <button
              onClick={() => setActiveTab("identity")}
              className={`px-4 py-2 text-sm font-medium transition-colors border-b-2 ${
                activeTab === "identity"
                  ? "text-blue-600 border-blue-600"
                  : "text-gray-600 hover:text-gray-900 border-transparent"
              }`}
            >
              Identity, Lifestyle & Life Stage
            </button>
            <button
              onClick={() => setActiveTab("activity")}
              className={`px-4 py-2 text-sm font-medium transition-colors border-b-2 ${
                activeTab === "activity"
                  ? "text-blue-600 border-blue-600"
                  : "text-gray-600 hover:text-gray-900 border-transparent"
              }`}
            >
              Recent activity
            </button>
          </div>
        </div>

        {/* Fixed-height content area with scroll */}
        <div className="flex-1 overflow-y-auto px-6 py-5">
          {activeTab === "overview" && <OverviewTab person={person} />}
          {activeTab === "behavioral" && <BehavioralTab person={person} />}
          {activeTab === "identity" && <IdentityTab person={person} />}
          {activeTab === "activity" && <ActivityTab person={person} />}
        </div>
      </div>
    </div>
  );
}

function OverviewTab({ person }: { person: Person }) {
  return (
    <div className="grid grid-cols-2 gap-6">
      {/* Left Column */}
      <div className="space-y-6">
        {/* Demographic Information */}
        <div className="bg-white border border-gray-200 rounded-lg p-5">
          <h3 className="text-sm font-semibold text-gray-900 mb-4">
            Demographic information
          </h3>
          <div className="space-y-3">
            <InfoRow label="Age" value="55–64" />
            <InfoRow label="Gender" value="Female" />
            <InfoRow label="Household income" value="Less than $200,000" />
            <InfoRow label="Estimated net worth" value="$750,000 to $999,999" />
            <InfoRow label="Married?" value="No" />
            <InfoRow label="Has children?" value="No" />
            <InfoRow label="Homeowner?" value="Yes" />
            <InfoRow label="Personal city" value="Minneapolis" />
            <InfoRow label="Personal state" value="Minnesota" />
            <InfoRow label="Personal ZIP" value="55401" />
            <InfoRow label="Personal address" value="710 N 4th St E313" />
          </div>
        </div>

        {/* Contact Information */}
        <div className="bg-white border border-gray-200 rounded-lg p-5">
          <h3 className="text-sm font-semibold text-gray-900 mb-4">
            Contact information
          </h3>
          <div className="space-y-3">
            <InfoRow label="Personal email" value="lucinda.brown@gmail.com" />
            <InfoRow label="Additional emails" value="lbrown@yahoo.com" />
            <InfoRow label="Business email" value="l.brown@company.com" />
            <InfoRow label="Mobile phone" value="+1 (612) 555-0142" />
            <InfoRow label="Personal phone" value="+1 (612) 555-0143" />
            <InfoRow label="Direct line" value="+1 (612) 555-0144" />
          </div>
        </div>
      </div>

      {/* Right Column */}
      <div className="space-y-6">
        {/* Professional */}
        <div className="bg-white border border-gray-200 rounded-lg p-5">
          <h3 className="text-sm font-semibold text-gray-900 mb-4">Professional</h3>
          <div className="space-y-3">
            <InfoRow label="Job title" value={person.title} />
            <InfoRow label="Department" value="Finance" />
            <InfoRow label="Seniority level" value="Executive" />
            <InfoRow label="Company name" value={person.company} />
            <InfoRow label="Company domain" value="company.com" />
            <InfoRow label="Industry" value="Technology" />
            <InfoRow label="Company size" value={person.companySize} />
            <InfoRow label="Company revenue" value="$10M - $50M" />
            <InfoRow label="Company phone" value="+1 (415) 555-0100" />
            <InfoRow
              label="Company LinkedIn"
              value="linkedin.com/company/example"
            />
            <InfoRow label="Company address" value="123 Market St" />
            <InfoRow label="Company city" value="San Francisco" />
            <InfoRow label="Company state" value="California" />
            <InfoRow label="Company ZIP" value="94105" />
            <InfoRow
              label="Work history"
              value="VP Finance at Previous Co. (2018-2022)"
            />
            <InfoRow
              label="Education history"
              value="MBA, Stanford University (2010)"
            />
          </div>
        </div>

        {/* Company Snapshot */}
        <div className="bg-white border border-gray-200 rounded-lg p-5">
          <h3 className="text-sm font-semibold text-gray-900 mb-4">
            Company snapshot
          </h3>
          <div className="space-y-3">
            <InfoRow label="Industry" value="Technology & Software" />
            <InfoRow label="Size" value={person.companySize} />
            <InfoRow label="Location" value={person.location} />
          </div>
        </div>
      </div>
    </div>
  );
}

function BehavioralTab({ person }: { person: Person }) {
  // Helper to get a score value from person data
  const getScore = (key: string): number => {
    const value = person[key];
    return typeof value === "number" ? value : Math.random() * 0.7 + 0.2;
  };

  return (
    <div className="space-y-6">
      {/* Engagement & Channel Fit */}
      <BehavioralSection
        title="Engagement & channel fit"
        enrichments={[
          { key: "emailEngagement", label: "Email Engagement Score" },
          { key: "smsEngagement", label: "SMS Engagement Score" },
          { key: "digitalAdResponsiveness", label: "Digital Ad Responsiveness Score" },
          { key: "influencerResponsiveness", label: "Influencer Responsiveness Score" },
          { key: "mobileEngagement", label: "Mobile Engagement Score" },
          { key: "desktopEngagement", label: "Desktop Engagement Score" },
          { key: "mediaLayerSaturation", label: "Media Layer Saturation Score" },
          { key: "daypartResponsiveness", label: "Daypart Responsiveness Score" },
          { key: "weekdayVsWeekendActivity", label: "Weekday vs Weekend Activity Score" },
        ]}
        person={person}
        getScore={getScore}
      />

      {/* Purchase Drivers & Financial Behavior */}
      <BehavioralSection
        title="Purchase drivers & financial behavior"
        enrichments={[
          { key: "impulseBuyLikelihood", label: "Impulse Buy Likelihood Score" },
          { key: "subscriptionPurchaseReadiness", label: "Subscription Purchase Readiness Score" },
          { key: "brandLoyalty", label: "Brand Loyalty Score" },
          { key: "couponResponsiveness", label: "Coupon Responsiveness Score" },
          { key: "urgencyResponsiveness", label: "Urgency Responsiveness Score" },
          { key: "dealHuntingTendency", label: "Deal Hunting Tendency Score" },
          { key: "timeToPurchaseSensitivity", label: "Time-to-Purchase Sensitivity Score" },
          { key: "subscriptionFatigue", label: "Subscription Fatigue Score" },
          { key: "trialWillingness", label: "Trial Willingness Score" },
          { key: "financialCautiousness", label: "Financial Cautiousness Score" },
          { key: "valueSeekingBehavior", label: "Value Seeking Behavior Score" },
          { key: "brandSwitchingRisk", label: "Brand Switching Risk Score" },
          { key: "overextensionRisk", label: "Overextension Risk Score" },
          { key: "luxuryPurchaseTendency", label: "Luxury Purchase Tendency Score" },
          { key: "loyaltyProgramResponsiveness", label: "Loyalty Program Responsiveness Score" },
          { key: "riskTolerance", label: "Risk Tolerance Score" },
          { key: "financialOptimization", label: "Financial Optimization Score" },
        ]}
        person={person}
        getScore={getScore}
      />

      {/* Psychographic & Messaging Fit */}
      <BehavioralSection
        title="Psychographic & messaging fit"
        enrichments={[
          { key: "socialValidationSensitivity", label: "Social Validation Sensitivity Score" },
          { key: "emotionalSensitivity", label: "Emotional Sensitivity Score" },
          { key: "trustSignalSensitivity", label: "Trust Signal Sensitivity Score" },
          { key: "authorityResponse", label: "Authority Response Score" },
          { key: "relationshipReliance", label: "Relationship Reliance Score" },
          { key: "skepticismScore", label: "Skepticism Score" },
          { key: "trendSensitivity", label: "Trend Sensitivity Score" },
          { key: "convenienceOverQuality", label: "Convenience Over Quality Score" },
          { key: "ethicalConsumptionSensitivity", label: "Ethical Consumption Sensitivity Score" },
          { key: "exclusivityAffinity", label: "Exclusivity Affinity Score" },
          { key: "emotionallyChargedResponse", label: "Emotionally Charged Response Score" },
          { key: "authorityDefiance", label: "Authority Defiance Score" },
          { key: "civicEngagementIntensity", label: "Civic Engagement Intensity Score" },
          { key: "narrativePersuasion", label: "Narrative Persuasion Score" },
          { key: "informationOverloadTolerance", label: "Information Overload Tolerance Score" },
          { key: "algorithmTrust", label: "Algorithm Trust Score" },
          { key: "brandIdealismAlignment", label: "Brand Idealism Alignment Score" },
          { key: "privacySensitivity", label: "Privacy Sensitivity Score" },
        ]}
        person={person}
        getScore={getScore}
      />

      {/* Decision Style & Trust Dynamics */}
      <BehavioralSection
        title="Decision style & trust dynamics"
        enrichments={[
          { key: "purchaseRationality", label: "Purchase Rationality Score" },
          { key: "policyFocusedPersuasion", label: "Policy Focused Persuasion Score" },
          { key: "tribeConformity", label: "Tribe Conformity Score" },
          { key: "deliberativeDecisionMaking", label: "Deliberative Decision Making Score" },
          { key: "mediaLayerSaturation", label: "Media Layer Saturation Score" },
          { key: "moralAbsolutismVsRelativism", label: "Moral Absolutism vs Relativism Score" },
          { key: "realWorldVsDigitalBias", label: "Real-World vs Digital Bias Score" },
          { key: "intellectualEngagement", label: "Intellectual Engagement Score" },
          { key: "bargainVsQualityBias", label: "Bargain vs Quality Bias Score" },
          { key: "patrioticAlignment", label: "Patriotic Alignment Score" },
          { key: "environmentalRiskAversion", label: "Environmental Risk Aversion Score" },
          { key: "anonymityDesire", label: "Anonymity Desire Score" },
          { key: "deiAlignment", label: "DEI Alignment Score" },
          { key: "opennessToNonMainstreamIdeas", label: "Openness to Non-Mainstream Ideas Score" },
          { key: "psychologicalSecurity", label: "Psychological Security Score" },
          { key: "polarizationTolerance", label: "Polarization Tolerance Score" },
          { key: "riskMitigation", label: "Risk Mitigation Score" },
        ]}
        person={person}
        getScore={getScore}
      />

      {/* Psychological & Emotional Landscape */}
      <BehavioralSection
        title="Psychological & emotional landscape"
        enrichments={[
          { key: "emotionalSensitivity", label: "Emotional Sensitivity Score" },
          { key: "emotionalReactivity", label: "Emotional Reactivity Score" },
          { key: "anxietySensitivity", label: "Anxiety Sensitivity Score" },
          { key: "optimismBias", label: "Optimism Bias Score" },
          { key: "empathyResponsiveness", label: "Empathy Responsiveness Score" },
          { key: "frustrationTolerance", label: "Frustration Tolerance Score" },
          { key: "privacySensitivity", label: "Privacy Sensitivity Score" },
        ]}
        person={person}
        getScore={getScore}
      />

      {/* Social, Civic & Identity Context */}
      <BehavioralSection
        title="Social, civic & identity context"
        enrichments={[
          { key: "localOutlier", label: "Local Outlier Score" },
          { key: "neighborhoodHomogeneity", label: "Neighborhood Homogeneity Score" },
          { key: "socialExposure", label: "Social Exposure Score" },
          { key: "communityVelocity", label: "Community Velocity Score" },
          { key: "conformityPressureIndex", label: "Conformity Pressure Index Score" },
          { key: "civicCohesion", label: "Civic Cohesion Score" },
        ]}
        person={person}
        getScore={getScore}
      />
    </div>
  );
}

function IdentityTab({ person }: { person: Person }) {
  // Helper to get a score value from person data (generating 0-6 scale values)
  const getScore = (): number => {
    return Math.random() * 6; // Random score between 0-6
  };

  // Generate 24 placeholder sub-models (12 per column) to fill the height
  const leftColumnModels = Array.from({ length: 12 }, (_, i) => ({
    label: `[Sub-model ${String.fromCharCode(65 + i)}]`, // A, B, C, etc.
    score: getScore(),
  }));

  const rightColumnModels = Array.from({ length: 12 }, (_, i) => ({
    label: `[Sub-model ${String.fromCharCode(77 + i)}]`, // M, N, O, etc.
    score: getScore(),
  }));

  return (
    <div className="grid grid-cols-2 gap-6">
      {/* Left Column */}
      <div className="space-y-4">
        {leftColumnModels.map((model, idx) => (
          <IdentitySubModelRow
            key={idx}
            label={model.label}
            score={model.score}
          />
        ))}
      </div>

      {/* Right Column */}
      <div className="space-y-4">
        {rightColumnModels.map((model, idx) => (
          <IdentitySubModelRow
            key={idx}
            label={model.label}
            score={model.score}
          />
        ))}
      </div>
    </div>
  );
}

function IdentitySubModelRow({
  label,
  score,
}: {
  label: string;
  score: number;
}) {
  const getColor = (score: number) => {
    if (score >= 4) return "#16A34A";
    if (score >= 2) return "#CA8A04";
    return "#DC2626";
  };

  const color = getColor(score);
  const percentage = (score / 6) * 100;

  return (
    <div className="flex items-center justify-between gap-4">
      <span className="text-sm text-gray-700 flex-1">{label}</span>
      <div className="flex items-center gap-3 w-48">
        <div className="relative flex-1 h-2 bg-gray-100 rounded-full overflow-hidden">
          <div
            className="h-full rounded-full transition-all"
            style={{
              width: `${percentage}%`,
              backgroundColor: color,
            }}
          />
          {/* Tick marks for 0-6 scale */}
          <div className="absolute inset-0 flex justify-between px-[1px]">
            {[0, 1, 2, 3, 4, 5, 6].map((tick) => (
              <div
                key={tick}
                className="w-[1px] h-full bg-white/50"
                style={{ marginLeft: tick === 0 ? 0 : undefined }}
              />
            ))}
          </div>
        </div>
        <span className="text-xs font-medium text-gray-900 w-12 text-right">
          {score.toFixed(1)}
        </span>
      </div>
    </div>
  );
}

function BehavioralSection({
  title,
  enrichments,
  person,
  getScore,
}: {
  title: string;
  enrichments: Array<{ key: string; label: string }>;
  person: Person;
  getScore: (key: string) => number;
}) {
  return (
    <div className="bg-white border border-gray-200 rounded-lg p-5">
      <h3 className="text-sm font-semibold text-gray-900 mb-4">{title}</h3>
      <div className="space-y-3">
        {enrichments.map((enrichment) => {
          const score = getScore(enrichment.key);
          return (
            <EnrichmentRow
              key={enrichment.key}
              label={enrichment.label}
              score={score}
            />
          );
        })}
      </div>
    </div>
  );
}

function EnrichmentRow({ label, score }: { label: string; score: number }) {
  const getLevel = (score: number) => {
    if (score >= 0.67) return { level: "High", color: "#16A34A" };
    if (score >= 0.34) return { level: "Medium", color: "#CA8A04" };
    return { level: "Low", color: "#DC2626" };
  };

  const { level, color } = getLevel(score);
  const percentage = score * 100;

  return (
    <div className="flex items-center justify-between gap-4">
      <span className="text-xs text-gray-700 flex-shrink-0 min-w-[240px]">
        {label}
      </span>
      <div className="flex items-center gap-3 flex-1">
        <div className="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden">
          <div
            className="h-full rounded-full transition-all"
            style={{
              width: `${percentage}%`,
              backgroundColor: color,
            }}
          />
        </div>
        <span className="text-xs font-medium text-gray-900 min-w-[100px] text-right">
          {level} · {score.toFixed(2)}
        </span>
      </div>
    </div>
  );
}

function ActivityTab({ person }: { person: Person }) {
  const [timeRange, setTimeRange] = useState<"7d" | "30d" | "all">("all");

  return (
    <div className="grid grid-cols-2 gap-6">
      {/* Recent Activity */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-gray-900">Recent activity</h3>
          <div className="flex items-center gap-2">
            <button className="p-1.5 hover:bg-gray-100 rounded transition-colors">
              <Filter className="w-4 h-4 text-gray-500" />
            </button>
            <div className="flex gap-1 bg-gray-100 rounded-lg p-1">
              <button
                onClick={() => setTimeRange("7d")}
                className={`px-3 py-1 text-xs rounded transition-all ${
                  timeRange === "7d"
                    ? "bg-white text-blue-700 shadow-sm"
                    : "text-gray-600 hover:text-gray-900"
                }`}
              >
                Past 7 days
              </button>
              <button
                onClick={() => setTimeRange("30d")}
                className={`px-3 py-1 text-xs rounded transition-all ${
                  timeRange === "30d"
                    ? "bg-white text-blue-700 shadow-sm"
                    : "text-gray-600 hover:text-gray-900"
                }`}
              >
                Past 30 days
              </button>
              <button
                onClick={() => setTimeRange("all")}
                className={`px-3 py-1 text-xs rounded transition-all ${
                  timeRange === "all"
                    ? "bg-white text-blue-700 shadow-sm"
                    : "text-gray-600 hover:text-gray-900"
                }`}
              >
                All time
              </button>
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <ActivityCard
            topic="Flood Zones And Flood Insurance"
            date="2025-08-18"
            status="active"
          />
          <ActivityCard
            topic="Climate Risk Assessment Tools"
            date="2025-08-15"
            status="active"
          />
          <ActivityCard
            topic="Property Value Trends"
            date="2025-08-12"
            status="inactive"
          />
          <ActivityCard
            topic="Insurance Premium Optimization"
            date="2025-08-10"
            status="active"
          />
          <ActivityCard
            topic="Financial Planning Strategies"
            date="2025-08-08"
            status="inactive"
          />
          <ActivityCard
            topic="Risk Mitigation Best Practices"
            date="2025-08-05"
            status="active"
          />
          <ActivityCard
            topic="Investment Portfolio Analysis"
            date="2025-08-02"
            status="inactive"
          />
          <ActivityCard
            topic="Market Volatility Indicators"
            date="2025-07-30"
            status="active"
          />
          <ActivityCard
            topic="Asset Allocation Strategies"
            date="2025-07-28"
            status="inactive"
          />
        </div>
      </div>

      {/* Signal Volume */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-gray-900">Signal volume</h3>
          <button className="text-xs text-gray-600 hover:text-gray-900 px-3 py-1.5 border border-gray-200 rounded-lg transition-colors">
            Select date
          </button>
        </div>

        <div className="space-y-3">
          <SignalRow
            topic="Flood Zones And Flood Insurance"
            signals={24}
            trend="up"
          />
          <SignalRow
            topic="Climate Risk Assessment Tools"
            signals={18}
            trend="up"
          />
          <SignalRow topic="Property Value Trends" signals={12} trend="flat" />
          <SignalRow
            topic="Insurance Premium Optimization"
            signals={15}
            trend="down"
          />
          <SignalRow
            topic="Financial Planning Strategies"
            signals={9}
            trend="flat"
          />
          <SignalRow
            topic="Risk Mitigation Best Practices"
            signals={21}
            trend="up"
          />
          <SignalRow
            topic="Investment Portfolio Analysis"
            signals={14}
            trend="up"
          />
          <SignalRow
            topic="Market Volatility Indicators"
            signals={11}
            trend="down"
          />
          <SignalRow
            topic="Asset Allocation Strategies"
            signals={8}
            trend="flat"
          />
        </div>
      </div>
    </div>
  );
}

function ActivityCard({
  topic,
  date,
  status,
}: {
  topic: string;
  date: string;
  status: "active" | "inactive";
}) {
  return (
    <div className="bg-gray-50 border border-gray-200 rounded-lg p-3 hover:bg-gray-100 transition-colors">
      <div className="flex items-start gap-3">
        <div
          className={`w-2 h-2 rounded-full mt-1.5 flex-shrink-0 ${
            status === "active" ? "bg-green-500" : "bg-gray-400"
          }`}
        />
        <div className="flex-1">
          <div className="text-sm text-gray-900 mb-1">{topic}</div>
          <div className="flex items-center gap-1.5 text-xs text-gray-600">
            <Clock className="w-3 h-3" />
            <span>{date}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function SignalRow({
  topic,
  signals,
  trend,
}: {
  topic: string;
  signals: number;
  trend: "up" | "down" | "flat";
}) {
  const getTrendIcon = () => {
    if (trend === "up")
      return <TrendingUp className="w-4 h-4 text-green-600" />;
    if (trend === "down")
      return <TrendingDown className="w-4 h-4 text-red-600" />;
    return <Minus className="w-4 h-4 text-gray-400" />;
  };

  return (
    <div className="flex items-center justify-between py-2 border-b border-gray-100 last:border-0">
      <div className="flex items-center gap-2 flex-1">
        {getTrendIcon()}
        <span className="text-sm text-gray-900">{topic}</span>
      </div>
      <span className="text-xs text-gray-600 font-medium">{signals} signals</span>
    </div>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start justify-between py-1.5">
      <span className="text-xs text-gray-600 flex-shrink-0 w-1/3">{label}</span>
      <span className="text-xs text-gray-900 text-right flex-1">{value}</span>
    </div>
  );
}
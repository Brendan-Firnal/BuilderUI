import { X } from "lucide-react";
import { useState } from "react";
import { Button } from "../ui/button";
import { Checkbox } from "../ui/checkbox";
import { Badge } from "../ui/badge";

export function ExportAudienceModal({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  const [tab, setTab] = useState<"sync" | "download">("download");
  const [scopeMode, setScopeMode] = useState<"full" | "segments" | "selection">("full");
  const [selectedSegments, setSelectedSegments] = useState<string[]>([]);
  
  // Example segments available for export
  const availableSegments = [
    { id: "seg1", name: "Q4 High-Intent Value-First VPs", count: 13100, percentage: 31 },
    { id: "seg2", name: "Q4 Test Cohort", count: 8400, percentage: 20 },
  ];
  
  const toggleSegment = (segmentId: string) => {
    setSelectedSegments(prev => 
      prev.includes(segmentId) 
        ? prev.filter(id => id !== segmentId)
        : [...prev, segmentId]
    );
  };
  
  if (!isOpen) return null;
  
  return (
    <>
      {/* Backdrop */}
      <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={onClose}>
        {/* Modal - Larger size */}
        <div 
          className="bg-white rounded-xl shadow-2xl w-full max-w-[680px] max-h-[90vh] overflow-y-auto"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="px-6 py-5 border-b border-gray-200 flex items-center justify-between">
            <h2 className="text-lg font-semibold text-gray-900">Export Audience</h2>
            <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
              <X className="w-5 h-5 text-gray-500" />
            </button>
          </div>
          
          {/* Content - More vertical spacing */}
          <div className="px-6 py-6 space-y-6">
            <p className="text-sm text-gray-600">Choose how you want to export this audience.</p>
            
            {/* Section A - Scope - Three cards */}
            <div>
              <h3 className="text-xs text-gray-500 uppercase tracking-wider mb-4">Scope</h3>
              <div className="space-y-3">
                {/* Full audience */}
                <label className={`flex items-center gap-3 p-4 border-2 rounded-lg cursor-pointer transition-colors ${
                  scopeMode === "full" 
                    ? "border-blue-500 bg-blue-50" 
                    : "border-gray-200 hover:border-gray-300"
                }`}>
                  <input 
                    type="radio" 
                    name="scope" 
                    checked={scopeMode === "full"}
                    onChange={() => setScopeMode("full")}
                    className="w-4 h-4 text-blue-600" 
                  />
                  <div className="flex-1">
                    <div className="text-sm font-semibold text-gray-900">Full audience</div>
                    <div className="text-xs text-gray-600 mt-0.5">42,318 people</div>
                  </div>
                </label>
                
                {/* Applied segments - NEW */}
                <label className={`flex flex-col gap-3 p-4 border-2 rounded-lg cursor-pointer transition-colors ${
                  scopeMode === "segments" 
                    ? "border-blue-500 bg-blue-50" 
                    : "border-gray-200 hover:border-gray-300"
                }`}>
                  <div className="flex items-center gap-3">
                    <input 
                      type="radio" 
                      name="scope" 
                      checked={scopeMode === "segments"}
                      onChange={() => setScopeMode("segments")}
                      className="w-4 h-4 text-blue-600" 
                    />
                    <div className="flex-1">
                      <div className="text-sm font-semibold text-gray-900">Applied segments</div>
                      <div className="text-xs text-gray-600 mt-0.5">Export one or more segments from this audience</div>
                    </div>
                  </div>
                  
                  {/* Nested segment checkboxes - show when this option is selected */}
                  {scopeMode === "segments" && availableSegments.length > 0 && (
                    <div className="ml-7 space-y-2 pt-2 border-t border-gray-200">
                      {availableSegments.map(segment => (
                        <label 
                          key={segment.id}
                          className="flex items-center gap-3 p-2 rounded-lg hover:bg-blue-100 cursor-pointer"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <Checkbox 
                            checked={selectedSegments.includes(segment.id)}
                            onCheckedChange={() => toggleSegment(segment.id)}
                          />
                          <span className="text-xs text-gray-900">
                            {segment.name} – {segment.count.toLocaleString()} people ({segment.percentage}%)
                          </span>
                        </label>
                      ))}
                    </div>
                  )}
                  
                  {/* If no segments exist */}
                  {scopeMode === "segments" && availableSegments.length === 0 && (
                    <div className="ml-7 text-xs text-gray-500 italic pt-2 border-t border-gray-200">
                      No segments created yet in this audience.
                    </div>
                  )}
                </label>
                
                {/* Current selection only */}
                <label className={`flex items-center gap-3 p-4 border-2 rounded-lg cursor-pointer transition-colors ${
                  scopeMode === "selection" 
                    ? "border-blue-500 bg-blue-50" 
                    : "border-gray-200 hover:border-gray-300"
                }`}>
                  <input 
                    type="radio" 
                    name="scope" 
                    checked={scopeMode === "selection"}
                    onChange={() => setScopeMode("selection")}
                    className="w-4 h-4 text-blue-600" 
                  />
                  <div className="flex-1">
                    <div className="text-sm font-semibold text-gray-900">Current selection only</div>
                    <div className="text-xs text-gray-600 mt-0.5">3 people</div>
                  </div>
                </label>
              </div>
              
              {/* Base Filters - More prominent chips */}
              <div className="mt-4">
                <span className="text-xs text-gray-500 mr-2">Filters:</span>
                <div className="inline-flex flex-wrap gap-2 mt-1">
                  <span className="inline-flex items-center px-3 py-1.5 rounded-full bg-gray-100 text-xs font-medium text-gray-700">
                    Base: CA
                  </span>
                  <span className="inline-flex items-center px-3 py-1.5 rounded-full bg-gray-100 text-xs font-medium text-gray-700">
                    VP Finance
                  </span>
                  <span className="inline-flex items-center px-3 py-1.5 rounded-full bg-gray-100 text-xs font-medium text-gray-700">
                    EMAIL_ENGAGEMENT ≥ 0.95
                  </span>
                </div>
              </div>
            </div>
            
            {/* Section B - Destination - Sync to tools disabled */}
            <div>
              <h3 className="text-xs text-gray-500 uppercase tracking-wider mb-4">Destination</h3>
              
              {/* Tabs - Download active, Sync disabled */}
              <div className="flex gap-2 mb-4 border-b border-gray-200">
                <button
                  onClick={() => setTab("download")}
                  className={`px-4 py-2 text-sm font-medium transition-colors relative ${
                    tab === "download" ? "text-blue-600" : "text-gray-600 hover:text-gray-900"
                  }`}
                >
                  Download
                  {tab === "download" && (
                    <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-blue-600 to-indigo-600" />
                  )}
                </button>
                <button
                  disabled
                  className="px-4 py-2 text-sm font-medium text-gray-400 cursor-not-allowed flex items-center gap-2"
                >
                  Sync to tools
                  <span className="text-xs px-2 py-0.5 rounded-full bg-gray-100 text-gray-500">
                    Coming soon
                  </span>
                </button>
              </div>
              
              {/* Download tab content - CSV only, added playbook labels */}
              {tab === "download" && (
                <div className="space-y-4">
                  <div>
                    <label className="text-xs text-gray-600 block mb-2">File format</label>
                    <select className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white">
                      <option>CSV (default)</option>
                    </select>
                  </div>
                  <div className="space-y-3">
                    <label className="flex items-center gap-3 cursor-pointer">
                      <Checkbox />
                      <span className="text-sm text-gray-900">Include enrichment scores</span>
                    </label>
                    <label className="flex items-center gap-3 cursor-pointer">
                      <Checkbox />
                      <span className="text-sm text-gray-900">Include persona labels</span>
                    </label>
                    <label className="flex items-center gap-3 cursor-pointer">
                      <Checkbox />
                      <span className="text-sm text-gray-900">Include playbook labels</span>
                    </label>
                  </div>
                </div>
              )}
            </div>
          </div>
          
          {/* Footer */}
          <div className="px-6 py-4 border-t border-gray-200 flex justify-end gap-3">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button 
              className="text-white"
              style={{ background: 'linear-gradient(to right, #2563EB, #4F46E5)' }}
            >
              Export
            </Button>
          </div>
        </div>
      </div>
    </>
  );
}
import { X } from "lucide-react";
import { Button } from "../ui/button";

export function MySegmentsModal({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  if (!isOpen) return null;
  
  return (
    <>
      {/* Backdrop */}
      <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={onClose}>
        {/* Modal */}
        <div 
          className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl max-h-[80vh] flex flex-col"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="px-6 py-5 border-b border-gray-200 flex items-center justify-between">
            <div>
              <h2 className="text-gray-900">My segments</h2>
              <p className="text-sm text-gray-500 mt-1">Segments you've saved across Moonbrush.</p>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
              <X className="w-5 h-5 text-gray-500" />
            </button>
          </div>
          
          {/* Content */}
          <div className="flex-1 overflow-y-auto px-6 py-6">
            <div className="space-y-2">
              <SegmentRow
                name="Q4 High-Intent Value-First VPs"
                scope="Audience: Q4 Finance VPs in CA"
                lastUpdated="Nov 14, 2025"
                destinations={['H', 'S']}
                compatible={true}
              />
              <SegmentRow
                name="Enterprise Decision Makers"
                scope="Audience: Enterprise Tech Buyers"
                lastUpdated="Nov 10, 2025"
                destinations={['H', 'C', 'S']}
                compatible={false}
              />
              <SegmentRow
                name="Privacy-First Researchers"
                scope="Global"
                lastUpdated="Nov 8, 2025"
                destinations={['S']}
                compatible={true}
              />
              <SegmentRow
                name="Mobile-First Millennials"
                scope="Audience: Consumer Tech Early Adopters"
                lastUpdated="Nov 5, 2025"
                destinations={['H', 'C']}
                compatible={false}
              />
              <SegmentRow
                name="Deal-Responsive SMB Owners"
                scope="Audience: SMB Decision Makers"
                lastUpdated="Oct 28, 2025"
                destinations={['H']}
                compatible={true}
              />
            </div>
          </div>
          
          {/* Footer */}
          <div className="px-6 py-4 border-t border-gray-200">
            <Button variant="outline" onClick={onClose} className="w-full">
              Close
            </Button>
          </div>
        </div>
      </div>
    </>
  );
}

function SegmentRow({
  name,
  scope,
  lastUpdated,
  destinations,
  compatible,
}: {
  name: string;
  scope: string;
  lastUpdated: string;
  destinations: string[];
  compatible: boolean;
}) {
  return (
    <div className="border border-gray-200 rounded-lg p-4 hover:border-violet-300 transition-colors">
      <div className="flex items-start justify-between mb-2">
        <div className="flex-1">
          <div className="text-sm text-gray-900 mb-1">{name}</div>
          <div className="text-xs text-gray-600">{scope}</div>
        </div>
        <div className="flex items-center gap-2 ml-4">
          {destinations.map((dest, idx) => {
            const colorMap: Record<string, string> = {
              'H': 'from-orange-500 to-red-500',
              'C': 'from-blue-500 to-indigo-500',
              'S': 'from-cyan-500 to-blue-600',
            };
            return (
              <div key={idx} className={`w-5 h-5 rounded bg-gradient-to-br ${colorMap[dest]} flex items-center justify-center text-white text-xs`}>
                {dest}
              </div>
            );
          })}
        </div>
      </div>
      
      <div className="flex items-center justify-between text-xs text-gray-500 mb-3">
        <span>Last updated: {lastUpdated}</span>
      </div>
      
      <div className="flex gap-3">
        <button className="text-sm text-violet-600 hover:text-violet-700">
          View details
        </button>
        {compatible ? (
          <button className="text-sm text-indigo-600 hover:text-indigo-700">
            Apply to this audience
          </button>
        ) : (
          <button className="text-sm text-gray-400 cursor-not-allowed" title="Outside this audience's filters">
            Apply to this audience
          </button>
        )}
      </div>
    </div>
  );
}

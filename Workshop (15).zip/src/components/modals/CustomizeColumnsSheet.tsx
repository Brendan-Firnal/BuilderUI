import { useState, useMemo } from "react";
import { X, Search, ChevronDown, ChevronRight } from "lucide-react";
import { Button } from "../ui/button";
import { Checkbox } from "../ui/checkbox";
import { getEnrichmentsForLens } from "../../lib/enrichment-dictionary";

type ColumnPreset = "behavior-only" | "identity-behavior" | "everything" | "custom";

interface FieldDefinition {
  key: string;
  label: string;
  locked?: boolean;
}

interface ColumnGroup {
  id: string;
  label: string;
  fields: FieldDefinition[];
}

const columnGroups: ColumnGroup[] = [
  {
    id: "personal-identity",
    label: "Personal identity",
    fields: [
      { key: "NAME", label: "Name", locked: true },
      { key: "FIRST_NAME", label: "First name" },
      { key: "LAST_NAME", label: "Last name" },
      { key: "AGE_RANGE", label: "Age range" },
      { key: "GENDER", label: "Gender" },
      { key: "MARRIED", label: "Married" },
      { key: "CHILDREN", label: "Children" },
      { key: "INCOME_RANGE", label: "Income range" },
      { key: "NET_WORTH", label: "Net worth" },
      { key: "HOMEOWNER", label: "Homeowner" },
      { key: "SOCIAL_CONNECTIONS", label: "Social connections" },
      { key: "PERSONAL_EMAILS_VALIDATION_STATUS", label: "Personal emails validation status" },
    ],
  },
  {
    id: "contact-emails",
    label: "Contact & emails",
    fields: [
      { key: "PERSONAL_EMAIL", label: "Personal email" },
      { key: "ADDITIONAL_PERSONAL_EMAILS", label: "Additional personal emails" },
      { key: "PERSONAL_PHONE", label: "Personal phone" },
      { key: "BUSINESS_EMAIL", label: "Business email" },
      { key: "PROGRAMMATIC_BUSINESS_EMAILS", label: "Programmatic business emails" },
      { key: "MOBILE_PHONE", label: "Mobile phone" },
      { key: "DIRECT_NUMBER", label: "Direct number" },
      { key: "BUSINESS_EMAIL_VALIDATION_STATUS", label: "Business email validation status" },
    ],
  },
  {
    id: "personal-address",
    label: "Personal address",
    fields: [
      { key: "PERSONAL_ADDRESS", label: "Personal address" },
      { key: "PERSONAL_ADDRESS_2", label: "Personal address 2" },
      { key: "PERSONAL_CITY", label: "Personal city" },
      { key: "PERSONAL_STATE", label: "Personal state" },
      { key: "PERSONAL_ZIP", label: "Personal ZIP" },
      { key: "PERSONAL_ZIP4", label: "Personal ZIP+4" },
    ],
  },
  {
    id: "professional-identity",
    label: "Professional identity",
    fields: [
      { key: "JOB_TITLE", label: "Job title" },
      { key: "JOB_TITLE_NORMALIZED", label: "Job title (normalized)" },
      { key: "SENIORITY_LEVEL", label: "Seniority level" },
      { key: "SENIORITY_LEVEL_2", label: "Seniority level 2" },
      { key: "DEPARTMENT", label: "Department" },
      { key: "DEPARTMENT_2", label: "Department 2" },
      { key: "WORK_HISTORY", label: "Work history" },
      { key: "EDUCATION_HISTORY", label: "Education history" },
      { key: "LINKEDIN_URL", label: "LinkedIn URL" },
      { key: "CC_ID", label: "CC ID" },
    ],
  },
  {
    id: "professional-address",
    label: "Professional address",
    fields: [
      { key: "PROFESSIONAL_ADDRESS", label: "Professional address" },
      { key: "PROFESSIONAL_ADDRESS2", label: "Professional address 2" },
      { key: "PROFESSIONAL_CITY", label: "Professional city" },
      { key: "PROFESSIONAL_STATE", label: "Professional state" },
      { key: "PROFESSIONAL_ZIP", label: "Professional ZIP" },
      { key: "PROFESSIONAL_ZIP4", label: "Professional ZIP+4" },
    ],
  },
  {
    id: "company",
    label: "Company",
    fields: [
      { key: "COMPANY_NAME", label: "Company name" },
      { key: "PRIMARY_INDUSTRY", label: "Primary industry" },
      { key: "COMPANY_DOMAIN", label: "Company domain" },
      { key: "COMPANY_LINKEDIN_URL", label: "Company LinkedIn URL" },
      { key: "COMPANY_PHONE", label: "Company phone" },
      { key: "COMPANY_REVENUE", label: "Company revenue" },
      { key: "COMPANY_EMPLOYEE_COUNT", label: "Company employee count" },
      { key: "COMPANY_SIC", label: "Company SIC" },
      { key: "COMPANY_NAICS", label: "Company NAICS" },
      { key: "COMPANY_DESCRIPTION", label: "Company description" },
      { key: "COMPANY_ADDRESS", label: "Company address" },
      { key: "COMPANY_CITY", label: "Company city" },
      { key: "COMPANY_STATE", label: "Company state" },
      { key: "COMPANY_ZIP", label: "Company ZIP" },
      { key: "COMPANY_COUNTRY", label: "Company country" },
      { key: "RELATED_DOMAINS", label: "Related domains" },
    ],
  },
  {
    id: "geo-zip",
    label: "Geo & ZIP context",
    fields: [
      { key: "METRO_NAME", label: "Metro name" },
      { key: "COUNTY_NAME", label: "County name" },
      { key: "COUNTY_FIPS", label: "County FIPS" },
      { key: "CBSA_FIPS", label: "CBSA FIPS" },
      { key: "STATE_ID", label: "State ID" },
      { key: "STATE", label: "State" },
      { key: "ZIPCODE_LAT", label: "Zipcode latitude" },
      { key: "ZIPCODE_LONG", label: "Zipcode longitude" },
      { key: "DENSITY", label: "Density" },
      { key: "TIMEZONE_FROM_ZIP", label: "Timezone from ZIP" },
      { key: "DPV_CODE", label: "DPV code" },
    ],
  },
];

interface ColumnConfig {
  [key: string]: boolean;
}

export function CustomizeColumnsSheet({
  isOpen,
  onClose,
  activeLens,
  onApply,
}: {
  isOpen: boolean;
  onClose: () => void;
  activeLens: string;
  onApply: (config: ColumnConfig) => void;
}) {
  // Get ALL enrichments for the active lens (not just first 6)
  const enrichments = getEnrichmentsForLens(activeLens);
  
  // Build behavioral group dynamically from enrichments
  const behavioralGroup: ColumnGroup = {
    id: "behavioral",
    label: "Behavior – current lens enrichments",
    fields: enrichments.map(e => ({ key: e.key, label: e.name })),
  };
  
  const allGroups = [...columnGroups, behavioralGroup];
  
  // Initialize with behavior-only preset
  const getDefaultConfig = (preset: ColumnPreset): ColumnConfig => {
    const config: ColumnConfig = {};
    
    switch (preset) {
      case "behavior-only":
        // Only Name + behavioral enrichments
        config.NAME = true;
        enrichments.forEach(e => config[e.key] = true);
        break;
        
      case "identity-behavior":
        // Core identity fields + behavioral
        config.NAME = true;
        config.FIRST_NAME = true;
        config.LAST_NAME = true;
        config.AGE_RANGE = true;
        config.GENDER = true;
        config.JOB_TITLE = true;
        config.COMPANY_NAME = true;
        config.PERSONAL_CITY = true;
        config.PERSONAL_STATE = true;
        enrichments.forEach(e => config[e.key] = true);
        break;
        
      case "everything":
        // All fields
        allGroups.forEach(group => {
          group.fields.forEach(field => config[field.key] = true);
        });
        break;
    }
    
    return config;
  };
  
  const [config, setConfig] = useState<ColumnConfig>(getDefaultConfig("behavior-only"));
  const [activePreset, setActivePreset] = useState<ColumnPreset>("behavior-only");
  const [searchQuery, setSearchQuery] = useState("");
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(
    new Set(allGroups.map(g => g.id))
  );
  
  const applyPreset = (preset: ColumnPreset) => {
    setActivePreset(preset);
    setConfig(getDefaultConfig(preset));
  };
  
  const toggleField = (fieldKey: string, locked?: boolean) => {
    if (locked) return;
    
    setConfig(prev => ({
      ...prev,
      [fieldKey]: !prev[fieldKey],
    }));
    setActivePreset("custom");
  };
  
  const toggleGroup = (groupId: string) => {
    setExpandedGroups(prev => {
      const next = new Set(prev);
      if (next.has(groupId)) {
        next.delete(groupId);
      } else {
        next.add(groupId);
      }
      return next;
    });
  };
  
  // Filter groups and fields based on search
  const filteredGroups = useMemo(() => {
    if (!searchQuery.trim()) return allGroups;
    
    const query = searchQuery.toLowerCase();
    return allGroups.map(group => ({
      ...group,
      fields: group.fields.filter(field => 
        field.label.toLowerCase().includes(query) ||
        field.key.toLowerCase().includes(query)
      ),
    })).filter(group => group.fields.length > 0);
  }, [searchQuery, allGroups]);
  
  const getGroupStats = (group: ColumnGroup) => {
    const total = group.fields.length;
    const visible = group.fields.filter(f => config[f.key]).length;
    return { total, visible };
  };
  
  if (!isOpen) return null;
  
  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/30 z-50 flex items-center justify-center p-8"
        onClick={onClose}
      >
        {/* Modal */}
        <div 
          className="bg-white rounded-xl shadow-2xl w-full max-w-[800px] max-h-[85vh] flex flex-col"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="px-6 py-5 border-b border-gray-200 flex items-center justify-between flex-shrink-0">
            <h2 className="text-lg text-gray-900 font-semibold">Customize columns</h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <X className="w-5 h-5 text-gray-500" />
            </button>
          </div>
          
          {/* Content */}
          <div className="flex-1 overflow-y-auto px-6 py-6">
            {/* Presets */}
            <div className="mb-6">
              <div className="flex gap-2 justify-center">
                <button
                  onClick={() => applyPreset("behavior-only")}
                  className={`px-5 py-2.5 rounded-lg text-sm font-medium transition-all ${
                    activePreset === "behavior-only"
                      ? "text-white shadow-sm"
                      : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                  }`}
                  style={activePreset === "behavior-only" ? { background: 'linear-gradient(to right, #2563EB, #4F46E5)' } : {}}
                >
                  Behavior-only
                </button>
                <button
                  onClick={() => applyPreset("identity-behavior")}
                  className={`px-5 py-2.5 rounded-lg text-sm font-medium transition-all ${
                    activePreset === "identity-behavior"
                      ? "text-white shadow-sm"
                      : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                  }`}
                  style={activePreset === "identity-behavior" ? { background: 'linear-gradient(to right, #2563EB, #4F46E5)' } : {}}
                >
                  Identity + behavior
                </button>
                <button
                  onClick={() => applyPreset("everything")}
                  className={`px-5 py-2.5 rounded-lg text-sm font-medium transition-all ${
                    activePreset === "everything"
                      ? "text-white shadow-sm"
                      : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                  }`}
                  style={activePreset === "everything" ? { background: 'linear-gradient(to right, #2563EB, #4F46E5)' } : {}}
                >
                  Everything
                </button>
              </div>
              {activePreset === "custom" && (
                <div className="text-center mt-2">
                  <span className="text-xs text-gray-500 italic">Custom selection</span>
                </div>
              )}
            </div>
            
            {/* Search */}
            <div className="mb-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search columns..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-4 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>
            
            {/* Column Groups */}
            <div className="space-y-3">
              {filteredGroups.map((group) => {
                const stats = getGroupStats(group);
                const isExpanded = expandedGroups.has(group.id);
                
                return (
                  <div key={group.id} className="border border-gray-200 rounded-lg overflow-hidden">
                    {/* Group Header */}
                    <button
                      onClick={() => toggleGroup(group.id)}
                      className="w-full px-4 py-3 bg-gray-50 hover:bg-gray-100 transition-colors flex items-center justify-between"
                    >
                      <div className="flex items-center gap-2">
                        {isExpanded ? (
                          <ChevronDown className="w-4 h-4 text-gray-500" />
                        ) : (
                          <ChevronRight className="w-4 h-4 text-gray-500" />
                        )}
                        <span className="text-sm font-medium text-gray-900">{group.label}</span>
                      </div>
                      <span className="text-xs text-gray-500">
                        {stats.visible} of {stats.total} visible
                      </span>
                    </button>
                    
                    {/* Group Fields */}
                    {isExpanded && (
                      <div className="p-3 space-y-1">
                        {group.fields.map((field) => (
                          <label 
                            key={field.key}
                            className={`flex items-center gap-3 p-2 rounded-lg transition-colors ${
                              field.locked 
                                ? "cursor-not-allowed opacity-60 bg-gray-50" 
                                : "cursor-pointer hover:bg-gray-50"
                            }`}
                          >
                            <Checkbox 
                              checked={config[field.key] || false}
                              disabled={field.locked}
                              onCheckedChange={() => toggleField(field.key, field.locked)}
                            />
                            <div className="flex-1">
                              <span className="text-sm text-gray-900">{field.label}</span>
                              {field.locked && (
                                <span className="text-xs text-gray-500 ml-2">(Always visible)</span>
                              )}
                            </div>
                          </label>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
          
          {/* Footer */}
          <div className="px-6 py-4 border-t border-gray-200 flex items-center justify-between flex-shrink-0">
            <button
              onClick={() => applyPreset("behavior-only")}
              className="text-sm text-gray-600 hover:text-gray-900 transition-colors"
            >
              Reset to behavior-only
            </button>
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={onClose}
              >
                Cancel
              </Button>
              <Button
                onClick={() => {
                  onApply(config);
                  onClose();
                }}
                className="text-white"
                style={{ background: 'linear-gradient(to right, #2563EB, #4F46E5)' }}
              >
                Apply columns
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
import { Download, ChevronRight, ChevronDown, Check, Filter } from "lucide-react";
import { Button } from "./ui/button";
import { useState } from "react";

export function AudienceHeader({ 
  onExportAudience,
  appliedSegment,
  onClearSelection,
  viewMode = "audience",
  onViewModeChange,
  onOpenFilters,
  workspaceMode = "workshop",
  onWorkspaceModeChange,
}: { 
  onExportAudience: () => void;
  appliedSegment?: {name: string; count: number; percentage: number} | null;
  onClearSelection?: () => void;
  viewMode?: "audience" | "selection";
  onViewModeChange?: (mode: "audience" | "selection") => void;
  onOpenFilters?: () => void;
  workspaceMode?: "builder" | "workshop";
  onWorkspaceModeChange?: (mode: "builder" | "workshop") => void;
}) {
  const [showScopeDropdown, setShowScopeDropdown] = useState(false);
  
  return (
    <div className="border-b border-gray-100 bg-white">
      {/* Single Row: Breadcrumbs + Title + Actions */}
      <div className="px-8 pt-7 pb-5">
        <div className="flex items-start justify-between gap-8">
          {/* Left - Breadcrumbs + Title stack (no card background) */}
          <div className="flex-shrink-0">
            {/* Row 1: Title + Breadcrumbs on same line */}
            <div className="flex items-center gap-3 mb-1.5">
              {/* Audience Title */}
              <h1 className="text-[19px] font-semibold text-gray-900 leading-tight">
                Q4 – Finance VPs in CA (Email {'>'} 0.95)
              </h1>
              
              {/* Separator */}
              <span className="text-gray-400">·</span>
              
              {/* Breadcrumbs */}
              <div className="flex items-center gap-2 text-[13px] text-gray-500">
                <span>Audiences</span>
                <span>›</span>
                <span>Q4 Finance VPs</span>
                <span>›</span>
                <span>Workspace</span>
              </div>
            </div>
            
            {/* Row 2: Subhead */}
            <p className="text-[13px] text-gray-600 max-w-[560px]">
              Behavioral Workspace – Edit how you view and act on this audience.
            </p>
          </div>
          
          {/* Center - Builder/Workshop Toggle */}
          <div className="flex items-center justify-center flex-1">
            <div className="inline-flex items-center bg-white border border-gray-200 rounded-full p-1">
              <button
                onClick={() => onWorkspaceModeChange?.("builder")}
                className={`px-5 py-2 rounded-full text-[13px] font-medium transition-all ${
                  workspaceMode === "builder"
                    ? "text-white shadow-sm"
                    : "text-gray-700 hover:text-gray-900"
                }`}
                style={
                  workspaceMode === "builder"
                    ? { background: "linear-gradient(to right, #2563EB, #4F46E5)" }
                    : undefined
                }
              >
                Builder
              </button>
              <button
                onClick={() => onWorkspaceModeChange?.("workshop")}
                className={`px-5 py-2 rounded-full text-[13px] font-medium transition-all ${
                  workspaceMode === "workshop"
                    ? "text-white shadow-sm"
                    : "text-gray-700 hover:text-gray-900"
                }`}
                style={
                  workspaceMode === "workshop"
                    ? { background: "linear-gradient(to right, #2563EB, #4F46E5)" }
                    : undefined
                }
              >
                Workshop
              </button>
            </div>
          </div>
          
          {/* Right - Unified Control Cluster */}
          <div className="flex items-center gap-3 flex-shrink-0">
            {/* 1. Filters Button (Primary) */}
            <button 
              onClick={onOpenFilters}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full text-white text-sm font-semibold transition-opacity hover:opacity-90"
              style={{ background: 'linear-gradient(to right, #2563EB, #4F46E5)' }}
            >
              <Filter className="w-4 h-4" />
              Filters
            </button>
            
            {/* 2. Scope Pill (Secondary/Informational) */}
            {appliedSegment ? (
              <div className="relative">
                <button
                  onClick={() => setShowScopeDropdown(!showScopeDropdown)}
                  className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full bg-gray-100 border border-gray-200 text-sm text-gray-900 transition-colors hover:bg-gray-200"
                >
                  <span className="font-medium">
                    Scope: "{appliedSegment.name}" ({appliedSegment.count.toLocaleString()} people)
                  </span>
                  <ChevronDown className="w-4 h-4 text-gray-600" />
                </button>
                
                {showScopeDropdown && (
                  <>
                    <div 
                      className="fixed inset-0 z-[50]" 
                      onClick={() => setShowScopeDropdown(false)}
                    />
                    <div className="absolute top-full left-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg z-[60] w-72 py-1">
                      <button
                        onClick={() => {
                          onViewModeChange?.("audience");
                          setShowScopeDropdown(false);
                        }}
                        className="w-full px-4 py-2 text-left text-sm hover:bg-gray-50 flex items-center justify-between"
                      >
                        <span className="text-gray-700">View entire audience</span>
                        {viewMode === "audience" && <Check className="w-4 h-4 text-blue-600" />}
                      </button>
                      <button
                        onClick={() => {
                          onViewModeChange?.("selection");
                          setShowScopeDropdown(false);
                        }}
                        className="w-full px-4 py-2 text-left text-sm hover:bg-gray-50 flex items-center justify-between"
                      >
                        <span className="text-gray-700">View current selection only</span>
                        {viewMode === "selection" && <Check className="w-4 h-4 text-blue-600" />}
                      </button>
                      <div className="border-t border-gray-200 my-1"></div>
                      <button
                        onClick={() => {
                          onClearSelection?.();
                          setShowScopeDropdown(false);
                        }}
                        className="w-full px-4 py-2 text-left text-sm hover:bg-gray-50 text-red-600"
                      >
                        Clear selection
                      </button>
                    </div>
                  </>
                )}
              </div>
            ) : (
              <div className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full bg-gray-100 border border-gray-200">
                <span className="text-sm text-gray-900">
                  Scope: Entire audience (42,318 people)
                </span>
              </div>
            )}
            
            {/* 3. Export Audience Button (Tertiary) */}
            <button 
              onClick={onExportAudience}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full bg-white border border-blue-600 text-blue-600 text-sm font-semibold transition-colors hover:bg-blue-50"
            >
              <Download className="w-4 h-4" />
              Export Audience
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
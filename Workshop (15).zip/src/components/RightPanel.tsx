import { useState } from "react";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Checkbox } from "./ui/checkbox";
import { ChevronDown, ChevronRight, ChevronLeft, PanelRightClose } from "lucide-react";
import { getEnrichmentsForLens } from "../lib/enrichment-dictionary";
import { getLensColors } from "../lib/lens-colors";

export function RightPanel({ 
  onOpenCampaignDrillIn,
  activeLens = "purchase",
  onCreateSegment,
  onViewSegments,
  audienceAverages,
  onApplySegment,
  isCollapsed = false,
  onToggleCollapse,
}: { 
  onOpenCampaignDrillIn: () => void;
  activeLens?: string;
  onCreateSegment?: () => void;
  onViewSegments?: () => void;
  audienceAverages?: Record<string, number>;
  onApplySegment?: (segmentName: string, matchCount: number, matchPercentage: number) => void;
  isCollapsed?: boolean;
  onToggleCollapse?: () => void;
}) {
  const [viewMode, setViewMode] = useState<"segments" | "behavior">("segments");
  
  // Collapsed state - thin rail
  if (isCollapsed) {
    return (
      <div className="w-8 border-l border-gray-200 bg-white flex flex-col items-center py-4">
        <button
          onClick={onToggleCollapse}
          className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          title="Show insights panel"
        >
          <ChevronLeft className="w-5 h-5 text-gray-500" />
        </button>
      </div>
    );
  }
  
  return (
    <div className="w-96 border-l border-gray-200 bg-white flex flex-col overflow-y-auto transition-all duration-300">
      <div className="p-6 space-y-4">
        {/* Segments & Behavior - Just Tab Bar */}
        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          {/* Tab Bar with Collapse Button */}
          <div className="p-4 border-b border-gray-100 flex items-center justify-between">
            <div className="flex gap-1 bg-gray-100 rounded-lg p-1 flex-1 mr-2">
              <button
                onClick={() => setViewMode("segments")}
                className={`flex-1 px-4 py-2 text-sm rounded transition-all ${
                  viewMode === "segments"
                    ? "bg-white text-blue-700 shadow-sm"
                    : "text-gray-600 hover:text-gray-900"
                }`}
              >
                Segments
              </button>
              <button
                onClick={() => setViewMode("behavior")}
                className={`flex-1 px-4 py-2 text-sm rounded transition-all ${
                  viewMode === "behavior"
                    ? "bg-white text-blue-700 shadow-sm"
                    : "text-gray-600 hover:text-gray-900"
                }`}
              >
                Behavior
              </button>
            </div>
            
            {/* Collapse Button */}
            <button
              onClick={onToggleCollapse}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors flex-shrink-0"
              title="Hide insights panel"
            >
              <ChevronRight className="w-4 h-4 text-gray-500" />
            </button>
          </div>
          
          {/* Content based on active tab */}
          <div className="p-5">
            {viewMode === "segments" ? (
              <SegmentsView 
                activeLens={activeLens}
                onCreateSegment={onCreateSegment}
                onApplySegment={onApplySegment}
              />
            ) : (
              <BehaviorView activeLens={activeLens} audienceAverages={audienceAverages || {}} />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function SegmentsView({ 
  activeLens,
  onCreateSegment,
  onApplySegment,
}: { 
  activeLens: string;
  onCreateSegment?: () => void;
  onApplySegment?: (segmentName: string, matchCount: number, matchPercentage: number) => void;
}) {
  const [createdExpanded, setCreatedExpanded] = useState(true);
  const [suggestedExpanded, setSuggestedExpanded] = useState(true);
  const [selectedSegments, setSelectedSegments] = useState<string[]>([]);
  const [previewSegment, setPreviewSegment] = useState<{ name: string; description: string; } | null>(null);
  
  const toggleSegmentSelection = (segmentName: string) => {
    setSelectedSegments(prev => 
      prev.includes(segmentName) 
        ? prev.filter(s => s !== segmentName)
        : [...prev, segmentName]
    );
  };
  
  const handleApplySelection = () => {
    if (selectedSegments.length > 0) {
      // Call the onApplySegment with a combined label
      onApplySegment?.(`${selectedSegments.length} segment(s) applied`, 0, 0);
      // Clear selection after apply
      setSelectedSegments([]);
    }
  };
  
  const handleClearSelection = () => {
    setSelectedSegments([]);
  };
  
  const suggestedSegments = [
    { name: "Highly Engaged Email Users", percentage: 25, count: 10600, description: "Frequently open and engage with email marketing." },
    { name: "SMS-Responsive Shoppers", percentage: 22, count: 9300, description: "Regularly interact with promotional text messages." },
    { name: "Multi-Channel Engagers", percentage: 28, count: 11800, description: "Actively engage across email, SMS, and ads." },
    { name: "High Intent Ad Clickers", percentage: 19, count: 8000, description: "Frequently click on paid ads with purchase signals." },
    { name: "Low Friction Funnel Movers", percentage: 16, count: 6800, description: "Glide through sales funnels with minimal resistance." },
    { name: "Silent But Loyal", percentage: 14, count: 5900, description: "Rarely engage but consistently purchase or return." },
  ];
  
  return (
    <div className="space-y-4">
      {/* Create Segment CTA */}
      <Button 
        onClick={onCreateSegment}
        className="w-full text-white"
        style={{ background: 'linear-gradient(to right, #2563EB, #4F46E5)' }}
      >
        Create segment
      </Button>
      
      {/* Selected Segments Control Bar - Sticky */}
      <div className="sticky top-0 z-10 bg-white pt-1 -mt-1">
        {selectedSegments.length > 0 && (
          <div className="flex items-center justify-between py-2 px-4 bg-[#F9FAFB] rounded-full border border-[#E5E7EB] transition-all hover:bg-gray-50">
            {/* Left: Status with count badge */}
            <div className="flex items-center gap-2.5">
              <div className="w-5 h-5 rounded-full bg-[#111827] flex items-center justify-center">
                <span className="text-[11px] font-medium text-white leading-none">
                  {selectedSegments.length}
                </span>
              </div>
              <span className="text-xs text-[#4B5563]">
                {selectedSegments.length === 1 ? 'segment selected' : 'segments selected'}
              </span>
            </div>
            
            {/* Right: Actions */}
            <div className="flex items-center gap-2.5">
              <button
                onClick={handleClearSelection}
                className="text-xs text-[#6B7280] hover:text-gray-900 transition-colors"
              >
                Clear
              </button>
              <button
                onClick={handleApplySelection}
                className="px-4 py-1.5 text-xs font-medium text-white rounded-full transition-colors"
                style={{ background: 'linear-gradient(to right, #4F46E5, #4338CA)' }}
              >
                Apply selection
              </button>
            </div>
          </div>
        )}
      </div>
      
      {/* Created Segments - Collapsible */}
      <div className="border border-gray-200 rounded-lg overflow-hidden">
        <button
          onClick={() => setCreatedExpanded(!createdExpanded)}
          className="w-full px-4 py-3 bg-gray-50 flex items-center justify-between hover:bg-gray-100 transition-colors"
        >
          <span className="text-sm text-gray-900">Created segments</span>
          {createdExpanded ? (
            <ChevronDown className="w-4 h-4 text-gray-500" />
          ) : (
            <ChevronRight className="w-4 h-4 text-gray-500" />
          )}
        </button>
        
        {createdExpanded && (
          <div className="p-4 space-y-3">
            {/* Segment 1 with checkbox - NO Apply link */}
            <div 
              className={`rounded-lg border border-gray-200 p-4 transition-colors cursor-pointer ${
                selectedSegments.includes("Q4 High-Intent Value-First VPs")
                  ? "bg-gray-50"
                  : "bg-white"
              }`}
              onClick={() => toggleSegmentSelection("Q4 High-Intent Value-First VPs")}
            >
              <div className="flex items-start gap-3">
                {/* Checkbox - same style as table row select */}
                <div onClick={(e) => e.stopPropagation()}>
                  <Checkbox
                    checked={selectedSegments.includes("Q4 High-Intent Value-First VPs")}
                    onCheckedChange={() => toggleSegmentSelection("Q4 High-Intent Value-First VPs")}
                  />
                </div>
                
                <div className="flex-1">
                  <div className="text-sm font-semibold text-gray-900 mb-2">Q4 High-Intent Value-First VPs</div>
                  <div className="text-xs text-gray-600 mb-2 font-mono">
                    EMAIL_ENGAGEMENT_SCORE ≥ 0.8 · VALUE_SEEKER_SCORE ≥ 0.7
                  </div>
                  <div className="text-xs text-gray-500 mb-3">~13,100 people (31%)</div>
                  <div className="flex gap-3" onClick={(e) => e.stopPropagation()}>
                    <button className="text-xs text-gray-600 hover:text-gray-900 transition-colors">View details</button>
                    <button className="text-xs text-red-600 hover:text-red-700 transition-colors">Delete</button>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Segment 2 with checkbox - NO Apply link */}
            <div 
              className={`rounded-lg border border-gray-200 p-4 transition-colors cursor-pointer ${
                selectedSegments.includes("Q4 Test Cohort")
                  ? "bg-gray-50"
                  : "bg-white"
              }`}
              onClick={() => toggleSegmentSelection("Q4 Test Cohort")}
            >
              <div className="flex items-start gap-3">
                {/* Checkbox - same style as table row select */}
                <div onClick={(e) => e.stopPropagation()}>
                  <Checkbox
                    checked={selectedSegments.includes("Q4 Test Cohort")}
                    onCheckedChange={() => toggleSegmentSelection("Q4 Test Cohort")}
                  />
                </div>
                
                <div className="flex-1">
                  <div className="text-sm font-semibold text-gray-900 mb-2">Q4 Test Cohort</div>
                  <div className="text-xs text-gray-600 mb-2 font-mono">
                    DEAL_HUNTING_SCORE ≥ 0.75 · IMPULSE_BUY_SCORE ≥ 0.6
                  </div>
                  <div className="text-xs text-gray-500 mb-3">~8,400 people (20%)</div>
                  <div className="flex gap-3" onClick={(e) => e.stopPropagation()}>
                    <button className="text-xs text-gray-600 hover:text-gray-900 transition-colors">View details</button>
                    <button className="text-xs text-red-600 hover:text-red-700 transition-colors">Delete</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
      
      {/* Suggested Quick Segments - Collapsible */}
      <div className="border border-gray-200 rounded-lg overflow-hidden">
        <button
          onClick={() => setSuggestedExpanded(!suggestedExpanded)}
          className="w-full px-4 py-3 bg-gray-50 flex items-center justify-between hover:bg-gray-100 transition-colors"
        >
          <span className="text-sm text-gray-900">Suggested quick segments</span>
          {suggestedExpanded ? (
            <ChevronDown className="w-4 h-4 text-gray-500" />
          ) : (
            <ChevronRight className="w-4 h-4 text-gray-500" />
          )}
        </button>
        
        {suggestedExpanded && (
          <div className="p-4 space-y-3 max-h-[600px] overflow-y-auto">
            {suggestedSegments.map((segment) => (
              <div 
                key={segment.name} 
                className={`rounded-lg border border-gray-200 p-4 transition-colors cursor-pointer ${
                  selectedSegments.includes(segment.name) ? "bg-gray-50" : "bg-white"
                }`}
                onClick={() => toggleSegmentSelection(segment.name)}
              >
                <div className="flex items-start gap-3">
                  {/* Checkbox - same style as table row select */}
                  <div onClick={(e) => e.stopPropagation()}>
                    <Checkbox
                      checked={selectedSegments.includes(segment.name)}
                      onCheckedChange={() => toggleSegmentSelection(segment.name)}
                    />
                  </div>
                  
                  <div className="flex-1">
                    {/* Segment name */}
                    <div className="text-sm font-semibold text-gray-900 mb-2">{segment.name}</div>
                    
                    {/* Match line */}
                    <div className="text-xs text-gray-600 mb-3">
                      {segment.percentage}% · {segment.count.toLocaleString()} people
                    </div>
                    
                    {/* Preview link only - NO Apply */}
                    <div className="flex justify-end" onClick={(e) => e.stopPropagation()}>
                      <button 
                        onClick={() => setPreviewSegment({ name: segment.name, description: segment.description })}
                        className="text-xs text-gray-600 hover:text-gray-900 transition-colors"
                      >
                        Preview
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      
      {/* Quick Segment Preview Modal */}
      {previewSegment && (
        <QuickSegmentPreviewModal
          segment={previewSegment}
          onClose={() => setPreviewSegment(null)}
          onApply={() => {
            const segment = suggestedSegments.find(s => s.name === previewSegment.name);
            if (segment) {
              onApplySegment?.(segment.name, segment.count, segment.percentage);
              setPreviewSegment(null);
            }
          }}
        />
      )}
    </div>
  );
}

function BehaviorView({ activeLens, audienceAverages, onFilterToHigh, onAddToSegment }: { 
  activeLens: string; 
  audienceAverages: Record<string, number>;
  onFilterToHigh?: (enrichmentKey: string, enrichmentName: string) => void;
  onAddToSegment?: (enrichmentKey: string, enrichmentName: string) => void;
}) {
  const enrichments = getEnrichmentsForLens(activeLens);
  const [expandedItem, setExpandedItem] = useState<string | null>(null);
  const colors = getLensColors(activeLens);
  
  // Identity sub-models use 0-6 scale
  const identityKeys = [
    "gender_polarity_scale", "tradition_vs_progress", "localism_vs_globalism",
    "health_vitality_spectrum", "family_orientation_spectrum", "economic_anxiety_index",
    "digital_tribalism_spectrum", "consumption_identity_index", "age_perception_score",
    "civic_identity_spectrum"
  ];
  
  const formatScore = (score: number, enrichmentKey: string): { label: string; value: string; color: string } => {
    const isZeroToSix = identityKeys.includes(enrichmentKey);
    
    if (isZeroToSix) {
      // For 0-6 scale: 0-2 = Low, 3 = Medium, 4-6 = High
      if (score >= 4) return { label: "High", value: `${score.toFixed(1)} / 6`, color: "#16A34A" };
      if (score >= 3) return { label: "Medium", value: `${score.toFixed(1)} / 6`, color: "#CA8A04" };
      return { label: "Low", value: `${score.toFixed(1)} / 6`, color: "#DC2626" };
    } else {
      // For 0-1 scale
      if (score >= 0.67) return { label: "High", value: score.toFixed(2), color: "#16A34A" };
      if (score >= 0.34) return { label: "Medium", value: score.toFixed(2), color: "#CA8A04" };
      return { label: "Low", value: score.toFixed(2), color: "#DC2626" };
    }
  };
  
  // Sort enrichments by average score (descending)
  const sortedEnrichments = [...enrichments].sort((a, b) => {
    const scoreA = audienceAverages[a.key] || 0.5;
    const scoreB = audienceAverages[b.key] || 0.5;
    // Normalize for comparison if one is 0-6 scale
    const normalizedA = identityKeys.includes(a.key) ? scoreA / 6 : scoreA;
    const normalizedB = identityKeys.includes(b.key) ? scoreB / 6 : scoreB;
    return normalizedB - normalizedA; // Descending order
  });
  
  return (
    <div className="space-y-0">
      <div className="mb-3 pb-3 border-b border-gray-200">
        <h4 className="text-sm text-gray-900 mb-1">Behavior for this lens</h4>
        <p className="text-xs text-gray-500 mb-2">
          Average enrichment scores and definitions for the current behavioral lens.
        </p>
        <div className="text-xs text-gray-500 text-right">
          Sorted by: Highest average score
        </div>
      </div>
      
      {sortedEnrichments.map((enrichment, idx) => {
        const isExpanded = expandedItem === enrichment.key;
        const avgScore = audienceAverages[enrichment.key] || (identityKeys.includes(enrichment.key) ? 3 : 0.5);
        const { label, value, color } = formatScore(avgScore, enrichment.key);
        const isZeroToSix = identityKeys.includes(enrichment.key);
        const progressWidth = isZeroToSix ? (avgScore / 6) * 100 : avgScore * 100;
        
        return (
          <div key={enrichment.key}>
            {/* Divider between rows */}
            {idx > 0 && <div className="h-px bg-gray-200" />}
            
            <button
              onClick={() => setExpandedItem(isExpanded ? null : enrichment.key)}
              className="w-full px-0 py-3 bg-white hover:bg-gray-50 flex items-start justify-between transition-colors group"
            >
              <div className="flex-1 text-left pr-4">
                {/* Enrichment name */}
                <div className="text-sm font-semibold text-gray-900 mb-1">{enrichment.name}</div>
                
                {/* Context label */}
                <div className="text-xs text-gray-600 mb-1.5">Audience average</div>
                
                {/* Score + bar line */}
                <div className="flex items-center gap-2">
                  {/* Score text */}
                  <div className="text-xs font-medium whitespace-nowrap" style={{ color }}>
                    {label} ({value})
                  </div>
                  
                  {/* Thin progress bar */}
                  <div className="w-24 h-[3px] bg-gray-200 rounded-full overflow-hidden">
                    <div 
                      className="h-full rounded-full transition-all"
                      style={{ 
                        width: `${progressWidth}%`,
                        background: colors.gradient,
                        opacity: 0.6
                      }}
                    />
                  </div>
                </div>
              </div>
              
              {/* Chevron - vertically centered */}
              <div className="flex-shrink-0 pt-1">
                {isExpanded ? (
                  <ChevronDown className="w-4 h-4 text-gray-400 group-hover:text-gray-600" />
                ) : (
                  <ChevronRight className="w-4 h-4 text-gray-400 group-hover:text-gray-600" />
                )}
              </div>
            </button>
            
            {isExpanded && (
              <div 
                className="px-3 py-3 bg-gray-50 space-y-3 ml-2 mb-2"
                style={{ borderLeft: `2px solid ${colors.solid}` }}
              >
                <div>
                  <p className="text-xs text-gray-700 leading-relaxed line-clamp-2">
                    {enrichment.shortDescription}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-gray-600 leading-relaxed">
                    <span className="text-gray-500">Directionality:</span> {enrichment.scoringDirectionality}
                  </p>
                </div>
                
                {/* Micro-actions row */}
                <div className="pt-1.5 border-t border-gray-200 flex items-center gap-2">
                  <span className="text-xs text-gray-500">Quick actions:</span>
                  <button
                    onClick={() => onFilterToHigh?.(enrichment.key, enrichment.name)}
                    className="px-2 py-1 text-xs border border-gray-300 rounded hover:bg-white hover:border-blue-300 hover:text-blue-700 transition-colors"
                  >
                    Filter to High
                  </button>
                  <button
                    onClick={() => onAddToSegment?.(enrichment.key, enrichment.name)}
                    className="px-2 py-1 text-xs border border-gray-300 rounded hover:bg-white hover:border-blue-300 hover:text-blue-700 transition-colors"
                  >
                    Add to segment…
                  </button>
                </div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

// Helper functions
function getLensDisplayName(lens: string): string {
  const names: Record<string, string> = {
    channel: "Channel Engagement",
    purchase: "Purchase",
    messaging: "Messaging",
    decision: "Decision Style",
    context: "Context",
    values: "Values",
    emotional: "Emotional",
  };
  return names[lens] || "Purchase";
}

function getLensShortName(lens: string): string {
  const names: Record<string, string> = {
    channel: "Channel",
    purchase: "Purchase",
    messaging: "Messaging",
    decision: "Decision",
    context: "Context",
    values: "Values",
    emotional: "Emotional",
  };
  return names[lens] || "Purchase";
}

function getSuggestedPersonas(lens: string, onApplySegment?: (segmentName: string, matchCount: number, matchPercentage: number) => void) {
  // TODO: Pull from canonical persona library in Google Drive with exact category mappings
  
  const personaData: Record<string, Array<{ category: string; personas: Array<{ name: string; percentage: number; count: number; match: string; tags: string[] }> }>> = {
    purchase: [
      {
        category: "Purchase Behavior",
        personas: [
          { name: "Value-Driven Decision Makers", percentage: 31, count: 13100, match: "31% · 13,100", tags: ["High Value Seeker", "Brand Loyal", "Low Impulse"] },
          { name: "Brand-Loyal Advocates", percentage: 17, count: 7200, match: "17% · 7,200", tags: ["High Brand Loyalty", "Low Switching", "High Subscription"] },
          { name: "Convenience-First Shoppers", percentage: 14, count: 5900, match: "14% · 5,900", tags: ["High Convenience", "Low Research", "Fast Decision"] },
          { name: "Quality-Over-Price Seekers", percentage: 11, count: 4700, match: "11% · 4,700", tags: ["High Quality Focus", "Low Bargain", "Premium"] },
        ]
      },
      {
        category: "Promo Sensitivity",
        personas: [
          { name: "Deal-Driven Opportunists", percentage: 22, count: 9200, match: "22% · 9,200", tags: ["High Deal Hunting", "Risk-Tolerant", "Medium Loyalty"] },
          { name: "Flash Sale Converters", percentage: 16, count: 6800, match: "16% · 6,800", tags: ["High Impulse", "Coupon Driven", "Time Sensitive"] },
          { name: "Discount-Dependent Buyers", percentage: 12, count: 5100, match: "12% · 5,100", tags: ["High Promo Sensitivity", "Price Conscious", "Bargain Focused"] },
        ]
      },
      {
        category: "Financial & Value Sensitivity",
        personas: [
          { name: "Budget-Cautious Parents", percentage: 18, count: 7600, match: "18% · 7,600", tags: ["High Financial Caution", "Risk Averse", "Value Focused"] },
          { name: "Subscription-Friendly Seekers", percentage: 14, count: 5900, match: "14% · 5,900", tags: ["High Subscription Affinity", "Recurring", "Convenience"] },
          { name: "High Net Value Seekers", percentage: 9, count: 3800, match: "9% · 3,800", tags: ["Luxury Affinity", "Exclusivity", "Premium Brands"] },
        ]
      },
    ],
    channel: [
      {
        category: "Digital Channel Preference",
        personas: [
          { name: "Highly Engaged Email Users", percentage: 34, count: 14300, match: "34% · 14,300", tags: ["High Email", "Desktop Focus", "Low SMS"] },
          { name: "Multi-Channel Engagers", percentage: 28, count: 11800, match: "28% · 11,800", tags: ["High Email", "High SMS", "High Ad"] },
          { name: "Mobile-First Shoppers", percentage: 24, count: 10100, match: "24% · 10,100", tags: ["High Mobile", "Low Desktop", "Medium Email"] },
          { name: "SMS-Responsive Buyers", percentage: 19, count: 8000, match: "19% · 8,000", tags: ["High SMS", "Mobile First", "Time Sensitive"] },
        ]
      },
      {
        category: "Device & Media Behavior",
        personas: [
          { name: "Desktop Power Users", percentage: 21, count: 8900, match: "21% · 8,900", tags: ["High Desktop", "Low Mobile", "Research Heavy"] },
          { name: "Ad-Responsive Scrollers", percentage: 17, count: 7200, match: "17% · 7,200", tags: ["High Ad Engagement", "Visual Driven", "Impulse"] },
          { name: "Media-Saturated Multitaskers", percentage: 15, count: 6300, match: "15% · 6,300", tags: ["High Saturation", "Multi-Screen", "High Frequency"] },
        ]
      },
      {
        category: "Engagement Patterns",
        personas: [
          { name: "Weekend Window Shoppers", percentage: 13, count: 5500, match: "13% · 5,500", tags: ["Weekend Active", "Low Weekday", "Leisure Shopping"] },
          { name: "Night Owl Browsers", percentage: 11, count: 4700, match: "11% · 4,700", tags: ["Evening Active", "Daypart Specific", "Mobile Heavy"] },
          { name: "Social Media Natives", percentage: 9, count: 3800, match: "9% · 3,800", tags: ["High Social", "Influencer Driven", "Visual Content"] },
        ]
      },
    ],
    messaging: [
      {
        category: "Influence & Trust",
        personas: [
          { name: "Social Proof Seekers", percentage: 29, count: 12200, match: "29% · 12,200", tags: ["High Social Validation", "Trust Signals", "Medium Expert"] },
          { name: "Expert-Driven Thinkers", percentage: 26, count: 11000, match: "26% · 11,000", tags: ["High Expert Response", "Low Influencer", "High Trust"] },
          { name: "Authority-Responsive Followers", percentage: 18, count: 7600, match: "18% · 7,600", tags: ["High Authority", "Trust Institutions", "Credentialed"] },
          { name: "Peer-Validated Buyers", percentage: 15, count: 6300, match: "15% · 6300", tags: ["High Social Validation", "Community Driven", "Reviews"] },
        ]
      },
      {
        category: "Content & Narrative",
        personas: [
          { name: "Narrative-Responsive Audience", percentage: 21, count: 8900, match: "21% · 8,900", tags: ["High Narrative", "Medium Social", "High Identity"] },
          { name: "Story-Driven Connectors", percentage: 17, count: 7200, match: "17% · 7,200", tags: ["High Storytelling", "Emotional", "Hero Identity"] },
          { name: "Case Study Converts", percentage: 14, count: 5900, match: "14% · 5,900", tags: ["Proof Driven", "Results Focused", "Rational"] },
        ]
      },
      {
        category: "Identity & Belonging",
        personas: [
          { name: "Tribe-Aligned Conformers", percentage: 19, count: 8000, match: "19% · 8,000", tags: ["High Tribe", "Conformity", "Belonging"] },
          { name: "Identity-Anchored Shoppers", percentage: 16, count: 6800, match: "16% · 6,800", tags: ["High Identity", "Values Driven", "Meaning"] },
          { name: "Independent Mavericks", percentage: 12, count: 5100, match: "12% · 5,100", tags: ["Low Social Validation", "Self-Validated", "Contrarian"] },
        ]
      },
    ],
    decision: [
      {
        category: "Research & Deliberation",
        personas: [
          { name: "Deep Research Analysts", percentage: 27, count: 11400, match: "27% · 11,400", tags: ["High Research", "Deliberative", "Rational"] },
          { name: "Information Seekers", percentage: 21, count: 8900, match: "21% · 8,900", tags: ["High Info Tolerance", "Detail Oriented", "Thorough"] },
          { name: "Spec Sheet Scrutinizers", percentage: 17, count: 7200, match: "17% · 7,200", tags: ["High Intellectual", "Data Driven", "Technical"] },
        ]
      },
      {
        category: "Decision Speed",
        personas: [
          { name: "Fast-Deciding Optimizers", percentage: 23, count: 9700, match: "23% · 9,700", tags: ["Low Research", "High Intuition", "Fast"] },
          { name: "Gut-Feel Deciders", percentage: 18, count: 7600, match: "18% · 7,600", tags: ["High Intuition", "Low Deliberation", "Emotional"] },
          { name: "Quick-Win Seekers", percentage: 14, count: 5900, match: "14% · 5,900", tags: ["Time Sensitive", "Efficiency", "Simple"] },
        ]
      },
      {
        category: "Cognitive Style",
        personas: [
          { name: "Rational Thinkers", percentage: 19, count: 8000, match: "19% · 8,000", tags: ["High Rationalism", "Low Emotion", "High Intellectual"] },
          { name: "Future-Focused Planners", percentage: 16, count: 6800, match: "16% · 6,800", tags: ["High Future Orientation", "Long-Term", "Strategic"] },
          { name: "Stability-Seeking Conservatives", percentage: 13, count: 5500, match: "13% · 5,500", tags: ["Stability Preference", "Risk Averse", "Cautious"] },
          { name: "Change-Embracing Innovators", percentage: 11, count: 4700, match: "11% · 4,700", tags: ["Change Seeking", "Risk Tolerant", "Early Adopter"] },
        ]
      },
    ],
    context: [
      {
        category: "Neighborhood Dynamics",
        personas: [
          { name: "Urban Influence Hubs", percentage: 25, count: 10600, match: "25% · 10,600", tags: ["High Social Exposure", "Low Conformity", "Diverse"] },
          { name: "Tight-Knit Suburbs", percentage: 31, count: 13100, match: "31% · 13,100", tags: ["High Homogeneity", "High Cohesion", "Low Outlier"] },
          { name: "Cultural Outliers", percentage: 18, count: 7600, match: "18% · 7,600", tags: ["High Local Outlier", "Low Conformity", "High Disparity"] },
          { name: "Neighborhood Conformers", percentage: 14, count: 5900, match: "14% · 5,900", tags: ["High Conformity", "Local Norms", "Community Aligned"] },
        ]
      },
      {
        category: "Community Context",
        personas: [
          { name: "Fast-Changing Communities", percentage: 17, count: 7200, match: "17% · 7,200", tags: ["High Velocity", "Dynamic", "Evolving"] },
          { name: "Stable Civic Engagers", percentage: 19, count: 8000, match: "19% · 8,000", tags: ["High Civic Cohesion", "Community Engaged", "Rooted"] },
          { name: "Sprawl Suburbanites", percentage: 13, count: 5500, match: "13% · 5,500", tags: ["High Sprawl", "Car Dependent", "Distributed"] },
        ]
      },
      {
        category: "Social Influence",
        personas: [
          { name: "High Social Density Areas", percentage: 21, count: 8900, match: "21% · 8,900", tags: ["High Influence Density", "Connected", "Networked"] },
          { name: "Ideological Consistents", percentage: 16, count: 6800, match: "16% · 6,800", tags: ["High Ideology Match", "Aligned", "Echo Chamber"] },
          { name: "Economic Pressure Zones", percentage: 12, count: 5100, match: "12% · 5,100", tags: ["High Economic Pressure", "Stressed", "Budget Constrained"] },
        ]
      },
    ],
    values: [
      {
        category: "Environmental & Social Values",
        personas: [
          { name: "Climate-First Progressives", percentage: 28, count: 11800, match: "28% · 11,800", tags: ["High Environmental", "High DEI", "Ethical"] },
          { name: "Ethical Consumption Advocates", percentage: 21, count: 8900, match: "21% · 8,900", tags: ["High Ethical", "Sustainability", "Conscious"] },
          { name: "DEI-Aligned Advocates", percentage: 17, count: 7200, match: "17% · 7,200", tags: ["High DEI", "Inclusive", "Progressive"] },
        ]
      },
      {
        category: "Traditional & Religious Values",
        personas: [
          { name: "Tradition-Anchored Guardians", percentage: 22, count: 9300, match: "22% · 9,300", tags: ["High Religious", "High Patriotic", "Stable"] },
          { name: "Faith-Driven Buyers", percentage: 16, count: 6800, match: "16% · 6,800", tags: ["High Religious", "Values Based", "Community"] },
          { name: "Patriotic Traditionalists", percentage: 13, count: 5500, match: "13% · 5,500", tags: ["High Patriotic", "National Pride", "Heritage"] },
        ]
      },
      {
        category: "Privacy & Technology Values",
        personas: [
          { name: "Privacy-Conscious Skeptics", percentage: 19, count: 8000, match: "19% · 8,000", tags: ["High Privacy", "Low Algorithmic Trust", "Security"] },
          { name: "Tech Optimists", percentage: 14, count: 5900, match: "14% · 5,900", tags: ["High Tech Optimism", "Innovation", "Future Focused"] },
          { name: "Data Security Advocates", percentage: 11, count: 4700, match: "11% · 4,700", tags: ["High Privacy", "Security Conscious", "Cautious"] },
          { name: "Freedom-First Libertarians", percentage: 9, count: 3800, match: "9% · 3,800", tags: ["High Freedom", "Low Security Trade", "Independent"] },
        ]
      },
    ],
    emotional: [
      {
        category: "Emotional Orientation",
        personas: [
          { name: "Optimistic Empaths", percentage: 27, count: 11400, match: "27% · 11,400", tags: ["High Empathy", "High Hope", "High Optimism"] },
          { name: "Emotionally Sensitive Connectors", percentage: 19, count: 8000, match: "19% · 8,000", tags: ["High Emotional Sensitivity", "Empathetic", "Reactive"] },
          { name: "Hope-Driven Believers", percentage: 16, count: 6800, match: "16% · 6,800", tags: ["High Hope", "Optimistic", "Future Focused"] },
        ]
      },
      {
        category: "Anxiety & Caution",
        personas: [
          { name: "Cautious Realists", percentage: 24, count: 10100, match: "24% · 10,100", tags: ["High Anxiety", "Medium Optimism", "Stable"] },
          { name: "Worry-Prone Planners", percentage: 18, count: 7600, match: "18% · 7,600", tags: ["High Anxiety", "Risk Averse", "Cautious"] },
          { name: "Frustration-Sensitive Avoiders", percentage: 12, count: 5100, match: "12% · 5,100", tags: ["Low Frustration Tolerance", "Sensitive", "Support Needed"] },
        ]
      },
      {
        category: "Meaning & Nostalgia",
        personas: [
          { name: "Nostalgia-Driven Traditionalists", percentage: 19, count: 8000, match: "19% · 8,000", tags: ["High Nostalgia", "Low Volatility", "Meaning"] },
          { name: "Meaning-Oriented Seekers", percentage: 14, count: 5900, match: "14% · 5,900", tags: ["High Meaning", "Low Materialism", "Purpose Driven"] },
          { name: "Heritage-Connected Buyers", percentage: 11, count: 4700, match: "11% · 4,700", tags: ["High Nostalgia", "Tradition", "Legacy"] },
        ]
      },
    ],
  };
  
  return personaData[lens] || personaData.purchase;
}

// Quick Segment Preview Modal
function QuickSegmentPreviewModal({ segment, onClose, onApply }: { 
  segment: { name: string; description: string; };
  onClose: () => void;
  onApply: () => void;
}) {
  return (
    <div 
      className="fixed inset-0 bg-black/30 flex items-center justify-center z-50"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          onClose();
        }
      }}
    >
      <div className="bg-white rounded-xl shadow-2xl w-[500px] p-6">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <h3 className="text-base font-semibold text-gray-900">{segment.name}</h3>
          <button
            onClick={onClose}
            className="p-1 hover:bg-gray-100 rounded transition-colors flex-shrink-0 ml-2"
          >
            <ChevronRight className="w-5 h-5 text-gray-500" />
          </button>
        </div>
        
        {/* Description */}
        <div className="mb-5">
          <p className="text-sm text-gray-700 leading-relaxed">
            {segment.description}
          </p>
        </div>
        
        {/* Rule preview */}
        <div className="mb-5">
          <div className="text-xs uppercase text-gray-500 mb-2">Rule</div>
          <div className="bg-gray-50 border border-gray-200 rounded-lg px-3 py-2.5 font-mono text-xs text-gray-900">
            EMAIL_ENGAGEMENT_SCORE ≥ 0.8 · VALUE_SEEKER_SCORE ≥ 0.7
          </div>
        </div>
        
        {/* Audience match summary */}
        <div className="mb-6">
          <p className="text-sm text-gray-700">
            Applies to <span className="font-medium">~13,100 people</span> <span className="text-gray-500">(31% of this audience)</span>.\n          </p>
        </div>
        
        {/* Footer actions */}
        <div className="flex items-center gap-3">
          <button
            onClick={onApply}
            className="flex-1 px-4 py-2.5 text-sm font-medium text-white rounded-lg transition-colors"
            style={{ background: 'linear-gradient(to right, #2563EB, #4F46E5)' }}
          >
            Apply segment
          </button>
          <button
            className="flex-1 px-4 py-2.5 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            Use as template
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2.5 text-sm text-gray-600 hover:text-gray-900 transition-colors"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}
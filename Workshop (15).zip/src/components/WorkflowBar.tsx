import { Save, Workflow, PlayCircle, Copy, FolderDown } from "lucide-react";
import { Button } from "./ui/button";

export function WorkflowBar({ 
  onCreateWorkflow,
  appliedSegment,
  viewMode = "audience",
  totalAudienceCount = 42318,
}: { 
  onCreateWorkflow: () => void;
  appliedSegment?: {name: string; count: number; percentage: number} | null;
  viewMode?: "audience" | "selection";
  totalAudienceCount?: number;
}) {
  return (
    <div className="border-t border-gray-200 bg-gradient-to-r from-gray-50 to-indigo-50/30 px-8 py-4">
      <div className="flex items-center justify-between">
        {/* Left - Context Info */}
        <div className="text-xs text-gray-500">
          {appliedSegment ? (
            viewMode === "selection" ? (
              <span>Actions will apply to: <span className="text-gray-700">Selection ("{appliedSegment.name}" – {appliedSegment.count.toLocaleString()} people)</span></span>
            ) : (
              <span>Actions will apply to: <span className="text-gray-700">Entire audience ({totalAudienceCount.toLocaleString()} people)</span></span>
            )
          ) : (
            <span>Actions will apply to: <span className="text-gray-700">Entire audience ({totalAudienceCount.toLocaleString()} people)</span></span>
          )}
        </div>
        
        {/* Center - Quick Actions */}
        <div className="flex items-center gap-3">
          <div className="relative group">
            <Button variant="outline" size="sm" className="gap-2">
              <Save className="w-4 h-4" />
              Save View
            </Button>
            <div className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 px-3 py-1.5 bg-gray-900 text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap">
              Save this column, filter, and lens configuration
            </div>
          </div>
          
          <div className="relative group">
            <Button variant="outline" size="sm" className="gap-2">
              <FolderDown className="w-4 h-4" />
              Export Selected{appliedSegment && viewMode === "selection" ? ` (${appliedSegment.count.toLocaleString()})` : ""}
            </Button>
            <div className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 px-3 py-1.5 bg-gray-900 text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap">
              Sync these people to a destination or download CSV
            </div>
          </div>
          
          <div className="w-px h-6 bg-gray-300 mx-2" />
          
          <div className="relative group">
            <Button 
              onClick={onCreateWorkflow}
              size="sm" 
              className="gap-2 bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700 shadow-md shadow-violet-200"
            >
              <Workflow className="w-4 h-4" />
              Create Workflow
            </Button>
            <div className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 px-3 py-1.5 bg-gray-900 text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap">
              Define behavioral logic and sync to your ESP or CRM
            </div>
          </div>
          
          <div className="relative group">
            <Button 
              size="sm" 
              variant="outline"
              className="gap-2 border-violet-300 text-violet-700 hover:bg-violet-50"
            >
              <PlayCircle className="w-4 h-4" />
              Run Playbook
            </Button>
            <div className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 px-3 py-1.5 bg-gray-900 text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap">
              Generate a playbook and push to connected tools
            </div>
          </div>
        </div>
        
        {/* Right - Status */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-xs text-gray-600">Auto-saved 2m ago</span>
          </div>
        </div>
      </div>
    </div>
  );
}
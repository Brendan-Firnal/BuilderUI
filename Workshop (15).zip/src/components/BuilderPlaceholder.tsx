import { useState } from "react";
import { Button } from "./ui/button";

interface BuilderPlaceholderProps {
  onBackToWorkshop: () => void;
}

export function BuilderPlaceholder({ onBackToWorkshop }: BuilderPlaceholderProps) {
  const [showModal, setShowModal] = useState(false);

  return (
    <div className="flex-1 bg-gray-50 px-8 py-6">
      {/* Page Title and Subtext */}
      <div className="mb-8">
        <h2 className="text-[17px] font-semibold text-gray-900 mb-1">
          Behavioral Builder
        </h2>
        <p className="text-[13px] text-gray-600">
          A dedicated canvas for building, saving, and managing custom behavioral segments.
        </p>
      </div>

      {/* Centered Coming Soon Card */}
      <div className="flex items-center justify-center" style={{ minHeight: "calc(100vh - 300px)" }}>
        <div className="bg-white border border-gray-200 rounded-xl shadow-sm p-8 w-full max-w-[720px]">
          <h3 className="text-xl font-semibold text-gray-900 mb-3">
            Behavioral Builder – Coming soon
          </h3>
          <p className="text-sm text-gray-600 mb-6 leading-relaxed">
            We're working on a visual builder for composing and saving behavioral segments. For now, you can still explore behaviors in Workshop mode.
          </p>

          <Button
            onClick={() => setShowModal(true)}
            className="text-white font-semibold"
            style={{ background: "linear-gradient(to right, #2563EB, #4F46E5)" }}
          >
            Create segment
          </Button>

          <p className="text-xs text-gray-500 mt-3">
            This will open a preview-only placeholder for now.
          </p>
        </div>
      </div>

      {/* Coming Soon Modal */}
      {showModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/30"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              setShowModal(false);
            }
          }}
        >
          <div className="bg-white rounded-xl shadow-2xl w-[500px] p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-3">
              Behavioral Builder – Coming soon
            </h3>
            <p className="text-sm text-gray-600 mb-6 leading-relaxed">
              We're still wiring up the full behavioral builder. In this preview, you can only view the layout – no segments will be saved yet.
            </p>

            <div className="flex items-center gap-3">
              <Button
                onClick={() => {
                  setShowModal(false);
                  onBackToWorkshop();
                }}
                className="text-white font-semibold flex-1"
                style={{ background: "linear-gradient(to right, #2563EB, #4F46E5)" }}
              >
                Back to Workshop
              </Button>
              <button
                onClick={() => setShowModal(false)}
                className="text-sm text-gray-600 hover:text-gray-900 transition-colors px-4"
              >
                Stay in Builder
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
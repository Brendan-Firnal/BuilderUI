import { useState } from "react";
import { Plus, X, Pencil, Filter, Users, Eye, MapPin, Building2, Mail, Zap, Target, TrendingUp, Shield } from "lucide-react";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";

type Tab = "filters" | "segments" | "lenses";

export function LeftRail() {
  const [activeTab, setActiveTab] = useState<Tab>("lenses");
  
  return (
    <div className="w-[280px] border-r border-gray-100 bg-gray-50/30 flex flex-col">
      {/* Tabs */}
      <div className="flex border-b border-gray-100 bg-white">
        <button
          onClick={() => setActiveTab("filters")}
          className={`flex-1 px-4 py-3 text-sm transition-colors relative ${
            activeTab === "filters"
              ? "text-indigo-600"
              : "text-gray-600 hover:text-gray-900"
          }`}
        >
          <div className="flex items-center justify-center gap-2">
            <Filter className="w-4 h-4" />
            Filters
          </div>
          {activeTab === "filters" && (
            <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-indigo-600 to-violet-600" />
          )}
        </button>
        
        <button
          onClick={() => setActiveTab("lenses")}
          className={`flex-1 px-4 py-3 text-sm transition-colors relative ${
            activeTab === "lenses"
              ? "text-indigo-600"
              : "text-gray-600 hover:text-gray-900"
          }`}
        >
          <div className="flex items-center justify-center gap-2">
            <Eye className="w-4 h-4" />
            Lenses
          </div>
          {activeTab === "lenses" && (
            <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-indigo-600 to-violet-600" />
          )}
        </button>
        
        <button
          onClick={() => setActiveTab("segments")}
          className={`flex-1 px-4 py-3 text-sm transition-colors relative ${
            activeTab === "segments"
              ? "text-indigo-600"
              : "text-gray-600 hover:text-gray-900"
          }`}
        >
          <div className="flex items-center justify-center gap-2">
            <Users className="w-4 h-4" />
            Segments
          </div>
          {activeTab === "segments" && (
            <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-indigo-600 to-violet-600" />
          )}
        </button>
      </div>
      
      {/* Tab Content */}
      <div className="flex-1 overflow-y-auto p-4">
        {activeTab === "filters" && <FiltersTab />}
        {activeTab === "lenses" && <LensesTab />}
        {activeTab === "segments" && <SegmentsTab />}
      </div>
    </div>
  );
}

function FiltersTab() {
  const filters = [
    { icon: MapPin, label: "Location: State", value: "CA" },
    { icon: Building2, label: "Title", value: "contains VP OR 'Vice President'" },
    { icon: Building2, label: "Company Size", value: "51–100, 101–250, 251–500, 501–1000" },
    { icon: Mail, label: "EMAIL_ENGAGEMENT_SCORE", value: "≥ 0.95" },
  ];
  
  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-xs text-gray-500 uppercase tracking-wider mb-3">Active Filters</h3>
        <div className="space-y-2">
          {filters.map((filter, idx) => (
            <div
              key={idx}
              className="group bg-white rounded-lg border border-gray-200 p-3 hover:border-indigo-300 transition-colors"
            >
              <div className="flex items-start gap-2">
                <filter.icon className="w-4 h-4 text-gray-400 mt-0.5 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <div className="text-xs text-gray-600">{filter.label}</div>
                  <div className="text-sm text-gray-900 mt-0.5 break-words">{filter.value}</div>
                </div>
                <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button className="p-1 hover:bg-gray-100 rounded">
                    <Pencil className="w-3 h-3 text-gray-500" />
                  </button>
                  <button className="p-1 hover:bg-gray-100 rounded">
                    <X className="w-3 h-3 text-gray-500" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      <Button variant="outline" className="w-full gap-2 border-dashed">
        <Plus className="w-4 h-4" />
        Add filter
      </Button>
      
      <div className="pt-4 space-y-2 border-t border-gray-200">
        <button className="text-xs text-indigo-600 hover:text-indigo-700">
          Save as reusable filter set
        </button>
        <button className="text-xs text-gray-400 cursor-not-allowed">
          Compare with another audience
        </button>
      </div>
    </div>
  );
}

function SegmentsTab() {
  const segments = [
    { name: "Value-Driven Decision Makers", percentage: 31, color: "from-indigo-500 to-violet-500", icon: Shield },
    { name: "Deal-Driven Opportunists", percentage: 22, color: "from-emerald-500 to-teal-500", icon: Target },
    { name: "Brand-Loyal Advocates", percentage: 17, color: "from-blue-500 to-cyan-500", icon: TrendingUp },
    { name: "Impulse-Driven Explorers", percentage: 11, color: "from-fuchsia-500 to-pink-500", icon: Zap },
  ];
  
  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-xs text-gray-500 uppercase tracking-wider mb-3">Behavioral Segments</h3>
        <div className="space-y-3">
          {segments.map((segment, idx) => (
            <div
              key={idx}
              className="bg-white rounded-lg border border-gray-200 p-3 hover:border-indigo-300 transition-colors"
            >
              <div className="flex items-start gap-2 mb-2">
                <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${segment.color} flex items-center justify-center flex-shrink-0`}>
                  <segment.icon className="w-4 h-4 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm text-gray-900">{segment.name}</div>
                  <div className="text-xs text-gray-500 mt-0.5">{segment.percentage}% of audience</div>
                </div>
              </div>
              
              {/* Percentage Bar */}
              <div className="w-full h-1.5 bg-gray-100 rounded-full overflow-hidden mb-2">
                <div
                  className={`h-full bg-gradient-to-r ${segment.color}`}
                  style={{ width: `${segment.percentage}%` }}
                />
              </div>
              
              <div className="flex gap-2">
                <button className="flex-1 text-xs text-indigo-600 hover:text-indigo-700 py-1">
                  Highlight in grid
                </button>
                <button className="flex-1 text-xs text-indigo-600 hover:text-indigo-700 py-1">
                  Filter to segment
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      <Button variant="outline" className="w-full gap-2 border-dashed">
        <Plus className="w-4 h-4" />
        New Segment from Rules
      </Button>
    </div>
  );
}

function LensesTab() {
  const [selectedLens, setSelectedLens] = useState("purchase");
  
  const lenses = [
    { 
      id: "channel", 
      name: "Channel Readiness",
      description: "Email / SMS / Ads / Device engagement patterns",
      tags: ["Email", "SMS", "Ads", "Device mix"],
      icon: Mail 
    },
    { 
      id: "purchase", 
      name: "Purchase Style",
      description: "Impulse vs Deliberate, Discount vs Value, Subscription vs One-off",
      tags: ["Impulse", "Deals", "Subscription", "Value vs Quality"],
      helperText: "Controls purchase-related persona and score columns in the table.",
      icon: Target 
    },
    { 
      id: "psychographic", 
      name: "Psychographic Patterns",
      description: "Risk, Trust, Individualism, Temporal Orientation",
      tags: ["Risk", "Trust", "Temporal Orientation"],
      icon: TrendingUp 
    },
    { 
      id: "civic", 
      name: "Civic & Trust",
      description: "Institutional Trust, Civic Engagement, Environmental Risk",
      tags: ["Institutional Trust", "Civic Engagement", "Risk"],
      icon: Shield 
    },
  ];
  
  return (
    <div className="space-y-3">
      <h3 className="text-xs text-gray-500 uppercase tracking-wider mb-3">Behavioral Lenses</h3>
      {lenses.map((lens) => (
        <button
          key={lens.id}
          onClick={() => setSelectedLens(lens.id)}
          className={`w-full text-left bg-white rounded-lg border-2 p-4 transition-all ${
            selectedLens === lens.id
              ? "border-violet-500 shadow-sm shadow-violet-100"
              : "border-gray-200 hover:border-gray-300"
          }`}
        >
          {/* Currently Applied Chip - Top Left Corner */}
          {selectedLens === lens.id && (
            <div className="mb-2">
              <span 
                className="inline-flex items-center px-2.5 py-1 rounded-full text-white text-xs font-medium"
                style={{ 
                  backgroundColor: lens.id === 'channel' ? '#06B6D4' :
                                   lens.id === 'purchase' ? '#16A34A' :
                                   lens.id === 'messaging' ? '#EC4899' :
                                   lens.id === 'decision' ? '#7C3AED' :
                                   lens.id === 'context' ? '#F97316' :
                                   lens.id === 'emotional' ? '#4F46E5' :
                                   lens.id === 'values' ? '#8B5CF6' :
                                   '#7C3AED'
                }}
              >
                Currently applied
              </span>
            </div>
          )}
          
          <div className="flex items-start gap-3">
            <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${
              selectedLens === lens.id
                ? "bg-gradient-to-br from-violet-500 to-purple-600"
                : "bg-gray-100"
            }`}>
              <lens.icon className={`w-5 h-5 ${selectedLens === lens.id ? "text-white" : "text-gray-500"}`} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="mb-1">
                <span className="text-sm text-gray-900">{lens.name}</span>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed mb-2">{lens.description}</p>
              
              {/* Lens Tags */}
              <div className="flex flex-wrap gap-1 mb-2">
                {lens.tags.map((tag, idx) => (
                  <Badge key={idx} variant="outline" className="text-xs text-gray-500 border-gray-300 bg-gray-50">
                    {tag}
                  </Badge>
                ))}
              </div>
              
              {selectedLens === lens.id && lens.helperText && (
                <p className="text-xs text-violet-600">
                  {lens.helperText}
                </p>
              )}
            </div>
          </div>
        </button>
      ))}
    </div>
  );
}
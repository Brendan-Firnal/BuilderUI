import { useState, useRef, useEffect } from "react";
import { Checkbox } from "./ui/checkbox";
import { GridToolbar } from "./GridToolbar";
import { getDefaultColumnsForLens } from "../lib/enrichment-dictionary";
import { getLensColors } from "../lib/lens-colors";
import { PersonProfileModal } from "./modals/PersonProfileModal";

interface Person {
  name: string;
  title: string;
  company: string;
  companySize: string;
  location: string;
  [key: string]: string | number;
}

// Generate 20 people with realistic behavioral scores
const mockPeople: Person[] = [
  { name: "Alex Chen", title: "VP Finance", company: "Northbridge Analytics", companySize: "101–250", location: "San Francisco, CA" },
  { name: "Maria Rodriguez", title: "Vice President of Finance", company: "TechVision Solutions", companySize: "251–500", location: "Los Angeles, CA" },
  { name: "James Wu", title: "VP of Finance & Operations", company: "Cascade Financial", companySize: "51–100", location: "San Diego, CA" },
  { name: "Sarah Mitchell", title: "Finance VP", company: "Innovate Health Systems", companySize: "501–1000", location: "Sacramento, CA" },
  { name: "David Park", title: "VP Finance", company: "Quantum Retail Group", companySize: "101–250", location: "San Jose, CA" },
  { name: "Jennifer Patel", title: "Vice President, Finance", company: "NextGen Manufacturing", companySize: "251–500", location: "Oakland, CA" },
  { name: "Robert Singh", title: "VP of Finance", company: "Velocity Software", companySize: "101–250", location: "San Francisco, CA" },
  { name: "Emily Johnson", title: "VP Finance & Strategy", company: "Meridian Consulting", companySize: "51–100", location: "Palo Alto, CA" },
  { name: "Michael Torres", title: "Vice President Finance", company: "Apex Technologies", companySize: "251–500", location: "San Diego, CA" },
  { name: "Lisa Anderson", title: "VP, Finance", company: "BlueSky Ventures", companySize: "101–250", location: "Berkeley, CA" },
  { name: "Kevin Lee", title: "Finance VP", company: "Stellar Systems", companySize: "501–1000", location: "San Jose, CA" },
  { name: "Rachel Kim", title: "VP Finance & Accounting", company: "Nova Healthcare", companySize: "251–500", location: "Santa Clara, CA" },
  { name: "Daniel Martinez", title: "Vice President of Finance", company: "Zenith Logistics", companySize: "101–250", location: "Fremont, CA" },
  { name: "Amanda Foster", title: "VP Finance", company: "Prism Solutions", companySize: "51–100", location: "Mountain View, CA" },
  { name: "Brian Cooper", title: "Finance VP & CFO", company: "Fusion Industries", companySize: "251–500", location: "San Francisco, CA" },
  { name: "Christine Nguyen", title: "VP of Finance", company: "Quantum Labs", companySize: "101–250", location: "Sunnyvale, CA" },
  { name: "Thomas Wright", title: "Vice President, Finance", company: "Horizon Networks", companySize: "501–1000", location: "Oakland, CA" },
  { name: "Nicole Brown", title: "VP Finance", company: "Catalyst Group", companySize: "101–250", location: "San Jose, CA" },
  { name: "Steven Clark", title: "VP of Finance & Administration", company: "Summit Enterprises", companySize: "251–500", location: "Santa Cruz, CA" },
  { name: "Jessica Taylor", title: "Finance VP", company: "Vanguard Systems", companySize: "51–100", location: "Redwood City, CA" },
].map((person, idx) => {
  // Generate varied scores for ALL enrichments using actual enrichment keys
  const scores: Record<string, number> = {};
  
  // All enrichment keys from the canonical dictionary
  const enrichmentKeys = [
    // Channel Engagement & Reachability
    "emailEngagement", "smsEngagement", "digitalAdResponsiveness", "influencerResponsiveness",
    "mobileEngagement", "desktopEngagement", "mediaLayerSaturation", "daypartResponsiveness",
    "weekdayVsWeekendActivity", "recencyFrequencyWindow", "realWorldVsDigitalBias",
    "realWorldVersusDigitalWorldBias", "trendSensitivity", "repetitiveReceptivity", "socialResponsiveness",
    // Purchase Drivers & Financial Behavior
    "impulseBuyLikelihood", "subscriptionPurchaseReadiness", "subscriptionPurchase", "subscriptionFatigue",
    "trailWillingness", "dealHuntingTendency", "couponResponsiveness", "valueSeekingBehavior",
    "bargainVsQualityBias", "loyaltyProgramResponsiveness", "brandLoyalty", "brandSwitchingRisk",
    "luxuryPurchaseTendency", "exclusivityAffinity", "timeToPurchaseSensitivity", "urgencyResponsiveness",
    "overExtensionRisk", "financialCautiousness", "financialOptimization", "riskTolerance",
    "riskMitigation", "riskMitigationBehavior", "purchaseRationality", "convenienceOverQuality",
    "localityAffinity", "ethicalConsumptionSensitivity", "noveltySeekingBehavior",
    // Messaging, Content & Influence Pathways
    "expectResponsiveness", "authorityResponse", "authorityDefiance", "relationshipReliance",
    "socialValidationSensitivity", "socialValidationDependence", "trustSignalSensitivity", "skepticism",
    "narrativePersuasion", "narrativeFramingVictimVsHeroIdentity", "identityAnchoring",
    "emotionallyChargedResponse", "informationOverloadTolerance", "intellectualEngagement",
    "experientialLearning", "algorithmTrust", "brandIdealismAlignment", "ethicalGuidelines",
    "deiAlignment", "policyFocusedPersuasion", "politicalMobilizability", "hopeOrientation",
    "nostalgiaAffinity", "opennessToConspiracyNonMainstreamIdeas",
    // Decision Style & Trust Dynamics
    "researchDept", "deliberativeDecisionMaking", "rationalismVsEmotionalIntuition", "temporalOrientation",
    "controlLocusInternalVsExternal", "stabilityVsChangePreference", "individualismVsCollectivism",
    "civicEngagementAndAgency", "institutionalTrustAndSkepticism", "freedomVsSecurityTradeOffTendency",
    "moralAbsolutismVsRelativism", "psychologicalSecurity", "psychologicalSecuritySeeking",
    "polarizationTolerance", "zeroSumVsAbundanceMindset", "technologicalOptimismVsTechSkepticism",
    "tribeConformity", "conformityVsIndividualExpression",
    // Values, Ideology & Worldview Alignment
    "environmentalRiskAversion", "patrioticAlignment", "religiousAlignment", "religiousValueAlignment",
    "authoritarianVsLibertarianTendencies", "materialismVsMeaningOrientation",
    "civicEngagementIntensity", "localIdeologyConsistency",
    // Emotional & Psychographic Orientation
    "emotionalSensitivity", "emotionalReactivity", "emotionalVolatilityIndex", "anxietySensitivity",
    "optimismBias", "empathyResponsiveness", "frustrationTolerance", "shameAversion",
    "anonymityDesire", "privacySensitivity",
    // Social & Cultural Context
    "localOutlier", "neighborhoodHomogeneity", "socialExposure", "culturalAffinityIndex",
    "communityVelocity", "conformityPressureIndex", "geoSocialInfluenceDensity", "behavioralDisparity",
    "civicCohesion", "sprawlIntensityIndex", "geoEconomicPressure",
  ];
  
  // Identity sub-models (0-6 scale)
  const identityKeys = [
    "gender_polarity_scale", "tradition_vs_progress", "localism_vs_globalism",
    "health_vitality_spectrum", "family_orientation_spectrum", "economic_anxiety_index",
    "digital_tribalism_spectrum", "consumption_identity_index", "age_perception_score",
    "civic_identity_spectrum"
  ];
  
  enrichmentKeys.forEach(key => {
    scores[key] = 0.2 + Math.random() * 0.7; // Random score between 0.2 and 0.9
  });
  
  // Generate 0-6 scale scores for identity sub-models
  identityKeys.forEach(key => {
    scores[key] = Math.random() * 6; // Random score between 0 and 6
  });
  
  return { ...person, ...scores };
});

function formatScore(score: number, isZeroToSix: boolean = false): { label: string } {
  if (isZeroToSix) {
    // For 0-6 scale: 0-2 = Low, 3 = Medium/Neutral, 4-6 = High
    if (score >= 4) return { label: "High" };
    if (score >= 3) return { label: "Medium" };
    return { label: "Low" };
  }
  // For 0-1 scale
  if (score >= 0.67) return { label: "High" };
  if (score >= 0.34) return { label: "Medium" };
  return { label: "Low" };
}

function ScoreCell({ score, activeLens, enrichmentKey }: { score: number | undefined; activeLens: string; enrichmentKey?: string }) {
  // Determine if this is a 0-6 scale enrichment (identity lens)
  const identityKeys = [
    "gender_polarity_scale", "tradition_vs_progress", "localism_vs_globalism",
    "health_vitality_spectrum", "family_orientation_spectrum", "economic_anxiety_index",
    "digital_tribalism_spectrum", "consumption_identity_index", "age_perception_score",
    "civic_identity_spectrum"
  ];
  const isZeroToSix = enrichmentKey ? identityKeys.includes(enrichmentKey) : false;
  
  // Handle undefined scores - generate a random score for demo purposes
  const actualScore = score ?? (isZeroToSix ? Math.random() * 6 : Math.random() * 0.4 + 0.3);
  
  const { label } = formatScore(actualScore, isZeroToSix);
  
  // Determine border color and tint based on score level
  const getBorderAndTint = () => {
    if (isZeroToSix) {
      // For 0-6 scale
      if (actualScore >= 4) {
        return { 
          borderColor: '#16A34A', // Green
          backgroundColor: 'rgba(22, 163, 74, 0.05)' 
        };
      }
      if (actualScore >= 3) {
        return { 
          borderColor: '#CA8A04', // Amber
          backgroundColor: 'rgba(202, 138, 4, 0.05)' 
        };
      }
      return { 
        borderColor: '#DC2626', // Red
        backgroundColor: 'rgba(220, 38, 38, 0.05)' 
      };
    } else {
      // For 0-1 scale
      if (actualScore >= 0.67) {
        return { 
          borderColor: '#16A34A', // Green
          backgroundColor: 'rgba(22, 163, 74, 0.05)' 
        };
      }
      if (actualScore >= 0.34) {
        return { 
          borderColor: '#CA8A04', // Amber
          backgroundColor: 'rgba(202, 138, 4, 0.05)' 
        };
      }
      return { 
        borderColor: '#DC2626', // Red
        backgroundColor: 'rgba(220, 38, 38, 0.05)' 
      };
    }
  };
  
  const { borderColor, backgroundColor } = getBorderAndTint();
  
  // Format display value
  const displayValue = isZeroToSix 
    ? `${label} (${actualScore.toFixed(1)} / 6)`
    : `${label} (${actualScore.toFixed(2)})`;
  
  return (
    <span 
      className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium whitespace-nowrap border"
      style={{ 
        borderColor: borderColor,
        backgroundColor: backgroundColor,
        color: '#111827' // Neutral dark text for all states
      }}
    >
      {displayValue}
    </span>
  );
}

export function AudienceGrid({ 
  activeLens, 
  onAudienceAveragesChange,
  appliedSegment,
  onOpenColumnsSheet,
}: { 
  activeLens: string;
  onAudienceAveragesChange?: (averages: Record<string, number>) => void;
  appliedSegment?: {name: string; count: number; percentage: number} | null;
  onOpenColumnsSheet?: () => void;
}) {
  const enrichments = getDefaultColumnsForLens(activeLens);
  const [selectedPerson, setSelectedPerson] = useState<Person | null>(null);
  const [isPersonModalOpen, setIsPersonModalOpen] = useState(false);
  
  // Calculate audience averages
  const audienceAverages: Record<string, number> = {};
  enrichments.forEach((enrichment) => {
    const sum = mockPeople.reduce((acc, person) => acc + (person[enrichment.key] as number || 0), 0);
    audienceAverages[enrichment.key] = sum / mockPeople.length;
  });
  
  // Pass averages up to parent using useEffect to avoid setState during render
  useEffect(() => {
    if (onAudienceAveragesChange) {
      onAudienceAveragesChange(audienceAverages);
    }
  }, [activeLens]); // Only recalculate when lens changes
  
  return (
    <div className="flex-1 flex flex-col bg-white relative">
      <GridToolbar 
        activeLens={activeLens} 
        appliedSegment={appliedSegment}
        onOpenColumnsSheet={onOpenColumnsSheet}
      />
      
      {/* Custom Scrollbar Styles */}
      <style dangerouslySetInnerHTML={{__html: `
        .audience-grid-scroll::-webkit-scrollbar {
          height: 14px;
          width: 14px;
        }
        .audience-grid-scroll::-webkit-scrollbar-track {
          background: #f3f4f6;
        }
        .audience-grid-scroll::-webkit-scrollbar-thumb {
          background: #9333ea;
          border-radius: 4px;
        }
        .audience-grid-scroll::-webkit-scrollbar-thumb:hover {
          background: #7c3aed;
        }
      `}} />
      
      {/* Table Container with Frozen Columns */}
      <div className="flex-1 flex overflow-hidden">
        {/* Frozen Left Columns */}
        <div className="flex-shrink-0 border-r-2 border-r-blue-200 bg-white overflow-y-scroll audience-grid-scroll-y">
          <style dangerouslySetInnerHTML={{__html: `
            .audience-grid-scroll-y::-webkit-scrollbar {
              width: 0px;
            }
          `}} />
          <table className="border-collapse">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="sticky top-0 z-20 bg-gray-50 px-4 py-3 text-left w-12 border-r border-gray-200">
                  <Checkbox />
                </th>
                <th className="sticky top-0 z-20 bg-gray-50 px-4 py-3 text-left text-xs text-gray-600 font-medium w-[180px] border-r-2 border-r-blue-200">
                  <div className="flex items-center gap-2">
                    <span>Name</span>
                  </div>
                </th>
              </tr>
            </thead>
            <tbody>
              {/* Audience Average Row */}
              <tr className="border-b border-gray-200 bg-blue-50">
                <td className="bg-blue-50 px-4 py-3 border-r border-gray-200"></td>
                <td className="bg-blue-50 px-4 py-3 border-r-2 border-r-blue-200">
                  <span className="text-sm text-gray-900">Audience average</span>
                </td>
              </tr>
              
              {/* Data Rows */}
              {mockPeople.map((person, idx) => (
                <tr 
                  key={idx} 
                  className="border-b border-gray-100 hover:bg-gray-50 transition-colors group cursor-pointer"
                  onClick={() => {
                    setSelectedPerson(person);
                    setIsPersonModalOpen(true);
                  }}
                >
                  <td 
                    className="bg-white group-hover:bg-gray-50 px-4 py-3 border-r border-gray-200"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <Checkbox />
                  </td>
                  <td className="bg-white group-hover:bg-gray-50 px-4 py-3 border-r-2 border-r-blue-200">
                    <span className="text-sm text-gray-900">{person.name}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        {/* Scrollable Right Columns - Behavioral Enrichments Only */}
        <div className="flex-1 audience-grid-scroll overflow-auto">
          <table className="border-collapse w-full">
            <thead>
              <tr className="border-b border-gray-200">
                {/* Behavioral Enrichment Columns */}
                {enrichments.map((enrichment) => (
                  <th key={enrichment.key} className="sticky top-0 z-10 bg-gray-50 px-4 py-3 text-left text-xs text-gray-600 font-medium min-w-[240px] border-r border-gray-200">
                    <div className="flex items-center gap-2">
                      <span>{enrichment.name}</span>
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            
            <tbody>
              {/* Audience Average Row */}
              <tr className="border-b border-gray-200 bg-blue-50">
                {enrichments.map((enrichment) => (
                  <td key={enrichment.key} className="bg-blue-50 px-4 py-3 border-r border-gray-200">
                    <ScoreCell score={audienceAverages[enrichment.key]} activeLens={activeLens} enrichmentKey={enrichment.key} />
                  </td>
                ))}
              </tr>
              
              {/* Data Rows */}
              {mockPeople.map((person, idx) => (
                <tr key={idx} className="border-b border-gray-100 hover:bg-gray-50 transition-colors group">
                  {enrichments.map((enrichment) => (
                    <td key={enrichment.key} className="bg-white group-hover:bg-gray-50 px-4 py-3 border-r border-gray-200">
                      <ScoreCell score={person[enrichment.key] as number} activeLens={activeLens} enrichmentKey={enrichment.key} />
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      
      {/* Person Profile Modal */}
      <PersonProfileModal 
        isOpen={isPersonModalOpen}
        onClose={() => setIsPersonModalOpen(false)}
        person={selectedPerson}
      />
    </div>
  );
}
import { useState } from "react";
import { Filter, Eye, Layers, ChevronLeft, ChevronRight, Plus, X, Pencil, MapPin, Building2, Mail, PanelLeftOpen } from "lucide-react";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { getLensColors } from "../lib/lens-colors";

type SidebarMode = "filters" | "lenses" | "segments";

export function LeftSidebar({ 
  isCollapsed, 
  onToggleCollapse,
  activeLens,
  onLensChange,
  onCreateSegment,
  onViewSegments,
}: { 
  isCollapsed: boolean; 
  onToggleCollapse: () => void;
  activeLens: string;
  onLensChange: (lens: string) => void;
  onCreateSegment: () => void;
  onViewSegments: () => void;
}) {
  if (isCollapsed) {
    return (
      <div className="w-16 border-r border-gray-200 flex flex-col items-center py-4 gap-4 bg-white">
        <button
          onClick={onToggleCollapse}
          className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
        >
          <PanelLeftOpen className="w-5 h-5 text-gray-500" />
        </button>
      </div>
    );
  }

  return (
    <div className="w-80 bg-white border-r border-gray-200 p-6 overflow-y-auto">
      {/* White Card Shell matching Right Sidebar */}
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        {/* Behavioral Lenses Banner */}
        <div className="bg-white border-b border-gray-100 px-4 py-4">
          <h3 className="text-sm font-semibold text-gray-900">Behavioral lenses</h3>
        </div>
        
        <div className="p-4">
          {/* Lenses Content */}
          <LensesContent activeLens={activeLens} onLensChange={onLensChange} />
        </div>
      </div>
    </div>
  );
}

function LensesContent({ activeLens, onLensChange }: { activeLens: string; onLensChange: (lens: string) => void }) {
  const lenses = [
    { 
      id: "channel", 
      name: "Channel Engagement & Reachability",
      subtitle: "Where and how this audience responds to outreach.",
    },
    { 
      id: "purchase", 
      name: "Purchase Drivers & Financial Behavior",
      subtitle: "Why they buy, spend level, and price/offer sensitivity.",
    },
    { 
      id: "messaging", 
      name: "Messaging, Content & Influence Pathways",
      subtitle: "What stories, proof, and formats change their mind.",
    },
    { 
      id: "decision", 
      name: "Decision Style & Trust Dynamics",
      subtitle: "How they weigh options, handle risk, and decide who to trust.",
    },
    { 
      id: "context", 
      name: "Social & Cultural Context (ZIP / Community-Level)",
      subtitle: "Community and geographic behavioral context.",
    },
    { 
      id: "values", 
      name: "Values, Ideology & Worldview Alignment",
      subtitle: "Core values, beliefs, and identity markers.",
    },
    { 
      id: "emotional", 
      name: "Emotional & Psychographic Orientation",
      subtitle: "Emotional patterns and psychological tendencies.",
    },
    { 
      id: "identity", 
      name: "Identity, Lifestyle & Life Stage (Sub-Models)",
      subtitle: "Deep psychographic and lifestyle sub-models scored on a 0–6 scale. Captures how people express identity, navigate life stage, and move through the world – blending gender expression, tradition vs progress, health vitality, family vs independence, economic anxiety, civic identity, and related interest and lifestyle signals.",
    },
  ];
  
  return (
    <div className="space-y-3">{lenses.map((lens) => {
        const isActive = activeLens === lens.id;
        const colors = getLensColors(lens.id);
        
        return (
          <button
            key={lens.id}
            onClick={() => onLensChange(lens.id)}
            className="w-full text-left bg-white rounded-lg border-2 p-4 transition-all"
            style={
              isActive
                ? {
                    borderColor: colors.solid,
                    background: colors.lightBg,
                  }
                : {
                    borderColor: '#E5E7EB',
                  }
            }
          >
            {/* Currently Applied Chip - Top row, on its own */}
            {isActive && (
              <div className="mb-2">
                <span 
                  className="inline-flex items-center px-2.5 py-1 rounded-full text-white text-xs font-medium"
                  style={{ backgroundColor: colors.solid }}
                >
                  Currently applied
                </span>
              </div>
            )}
            
            {/* Lens Title */}
            <div className="mb-2">
              <span className="text-sm text-gray-900">{lens.name}</span>
            </div>
            
            {/* Description - Single sentence only */}
            <p className="text-xs text-gray-600 leading-relaxed">{lens.subtitle}</p>
          </button>
        );
      })}
      
      <p className="text-xs text-gray-500 italic pt-2">
        Lenses change which personas, enrichments, and insights are surfaced. Data stays the same.
      </p>
    </div>
  );
}
import { X, Plus } from "lucide-react";
import { Button } from "../ui/button";
import { Checkbox } from "../ui/checkbox";

export function CreateWorkflowDrawer({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  if (!isOpen) return null;
  
  return (
    <>
      {/* Backdrop */}
      <div className="fixed inset-0 bg-black/20 z-40" onClick={onClose} />
      
      {/* Drawer */}
      <div className="fixed right-0 top-0 bottom-0 w-[480px] bg-white shadow-2xl z-50 flex flex-col">
        {/* Header */}
        <div className="px-6 py-5 border-b border-gray-200">
          <div className="flex items-center justify-between mb-2">
            <h2 className="text-gray-900">Create Behavioral Workflow</h2>
            <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
              <X className="w-5 h-5 text-gray-500" />
            </button>
          </div>
          <p className="text-sm text-gray-500">Route this audience to your tools using behavioral rules.</p>
        </div>
        
        {/* Content */}
        <div className="flex-1 overflow-y-auto px-6 py-6 space-y-6">
          {/* Section A - Audience Scope */}
          <div>
            <h3 className="text-xs text-gray-500 uppercase tracking-wider mb-3">Audience Scope</h3>
            <div className="space-y-2">
              <label className="flex items-center gap-3 p-3 border-2 border-violet-500 bg-violet-50 rounded-lg cursor-pointer">
                <input type="radio" name="scope" defaultChecked className="w-4 h-4" />
                <span className="text-sm text-gray-900">Use full audience (42,318 people)</span>
              </label>
              <label className="flex items-center gap-3 p-3 border-2 border-gray-200 rounded-lg cursor-pointer hover:border-gray-300">
                <input type="radio" name="scope" className="w-4 h-4" />
                <span className="text-sm text-gray-900">Use current selection (3 people)</span>
              </label>
              <label className="flex items-center gap-3 p-3 border-2 border-gray-200 rounded-lg cursor-pointer hover:border-gray-300">
                <input type="radio" name="scope" className="w-4 h-4" />
                <div className="flex-1">
                  <div className="text-sm text-gray-900">Use saved segment…</div>
                  <select className="mt-2 w-full px-3 py-1.5 border border-gray-200 rounded text-sm">
                    <option>Q4 High-Intent Finance VPs</option>
                    <option>Enterprise Decision Makers</option>
                  </select>
                </div>
              </label>
            </div>
          </div>
          
          {/* Section B - Conditions */}
          <div>
            <h3 className="text-xs text-gray-500 uppercase tracking-wider mb-3">Conditions</h3>
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <select className="flex-1 px-3 py-2 border border-gray-200 rounded-lg text-sm">
                  <option>EMAIL_ENGAGEMENT_SCORE</option>
                  <option>VALUE_SEEKER_SCORE</option>
                  <option>DEAL_HUNTING_SCORE</option>
                </select>
                <select className="w-20 px-3 py-2 border border-gray-200 rounded-lg text-sm">
                  <option>≥</option>
                  <option>{'<'}</option>
                  <option>=</option>
                </select>
                <input type="text" defaultValue="0.7" className="w-20 px-3 py-2 border border-gray-200 rounded-lg text-sm" />
              </div>
              
              <div className="flex items-center gap-2">
                <select className="flex-1 px-3 py-2 border border-gray-200 rounded-lg text-sm">
                  <option>VALUE_SEEKER_SCORE</option>
                  <option>EMAIL_ENGAGEMENT_SCORE</option>
                  <option>DEAL_HUNTING_SCORE</option>
                </select>
                <select className="w-20 px-3 py-2 border border-gray-200 rounded-lg text-sm">
                  <option>≥</option>
                  <option>{'<'}</option>
                  <option>=</option>
                </select>
                <input type="text" defaultValue="0.6" className="w-20 px-3 py-2 border border-gray-200 rounded-lg text-sm" />
              </div>
              
              <div className="flex items-center gap-2">
                <select className="flex-1 px-3 py-2 border border-gray-200 rounded-lg text-sm">
                  <option>DEAL_HUNTING_SCORE</option>
                  <option>EMAIL_ENGAGEMENT_SCORE</option>
                  <option>VALUE_SEEKER_SCORE</option>
                </select>
                <select className="w-20 px-3 py-2 border border-gray-200 rounded-lg text-sm">
                  <option>≥</option>
                  <option>{'<'}</option>
                  <option>=</option>
                </select>
                <input type="text" defaultValue="0.5" className="w-20 px-3 py-2 border border-gray-200 rounded-lg text-sm" />
              </div>
              
              <button className="text-sm text-violet-600 hover:text-violet-700 flex items-center gap-2">
                <Plus className="w-4 h-4" />
                Add condition
              </button>
            </div>
          </div>
          
          {/* Section C - Destination */}
          <div>
            <h3 className="text-xs text-gray-500 uppercase tracking-wider mb-3">Sync as live workflow to:</h3>
            <div className="space-y-2">
              <label className="flex items-center gap-3 cursor-pointer p-3 rounded-lg hover:bg-gray-50">
                <Checkbox defaultChecked />
                <div className="w-5 h-5 rounded bg-gradient-to-br from-orange-500 to-red-500 flex items-center justify-center text-white text-xs">H</div>
                <span className="text-sm text-gray-900">HubSpot · Enroll in workflow</span>
              </label>
              <label className="flex items-center gap-3 cursor-pointer p-3 rounded-lg hover:bg-gray-50">
                <Checkbox />
                <div className="w-5 h-5 rounded bg-gradient-to-br from-blue-500 to-indigo-500 flex items-center justify-center text-white text-xs">C</div>
                <span className="text-sm text-gray-900">Customer.io · Start journey</span>
              </label>
              <label className="flex items-center gap-3 cursor-pointer p-3 rounded-lg hover:bg-gray-50">
                <Checkbox />
                <div className="w-5 h-5 rounded bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-white text-xs">S</div>
                <span className="text-sm text-gray-900">Snowflake · Mark with MB_WORKFLOW_ID</span>
              </label>
            </div>
          </div>
          
          {/* Section D - Frequency */}
          <div>
            <h3 className="text-xs text-gray-500 uppercase tracking-wider mb-3">Frequency</h3>
            <div className="space-y-2">
              <label className="flex items-center gap-3 p-3 border-2 border-gray-200 rounded-lg cursor-pointer hover:border-gray-300">
                <input type="radio" name="frequency" className="w-4 h-4" />
                <span className="text-sm text-gray-900">One-time sync</span>
              </label>
              <label className="flex items-center gap-3 p-3 border-2 border-violet-500 bg-violet-50 rounded-lg cursor-pointer">
                <input type="radio" name="frequency" defaultChecked className="w-4 h-4" />
                <div className="flex-1">
                  <div className="text-sm text-gray-900">Keep in sync daily</div>
                  <p className="text-xs text-gray-600 mt-1">When 'Keep in sync' is on, new matching people are automatically added.</p>
                </div>
              </label>
            </div>
          </div>
        </div>
        
        {/* Footer */}
        <div className="px-6 py-4 border-t border-gray-200 flex gap-3">
          <Button variant="outline" onClick={onClose} className="flex-1">
            Cancel
          </Button>
          <Button className="flex-1 bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700">
            Create Workflow
          </Button>
        </div>
      </div>
    </>
  );
}

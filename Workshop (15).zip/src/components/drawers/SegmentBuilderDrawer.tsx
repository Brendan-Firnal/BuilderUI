import { X, Plus, ChevronDown, ChevronUp, Minus } from "lucide-react";
import { useState } from "react";
import { Button } from "../ui/button";
import { Checkbox } from "../ui/checkbox";
import { Badge } from "../ui/badge";

export function SegmentBuilderDrawer({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  const [demographicsExpanded, setDemographicsExpanded] = useState({
    personal: true,
    professional: false,
    company: true,
  });
  
  const [selectedEnrichments, setSelectedEnrichments] = useState<string[]>([
    "EMAIL_ENGAGEMENT_SCORE",
    "VALUE_SEEKER_SCORE",
    "MOBILE_DEVICE_ENGAGEMENT_SCORE",
  ]);
  
  const [globalRange, setGlobalRange] = useState<[number, number]>([0.3, 0.7]);
  
  if (!isOpen) return null;
  
  return (
    <>
      {/* Full-screen Backdrop */}
      <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-8" onClick={onClose}>
        {/* Centered Modal - 75% width */}
        <div 
          className="bg-white rounded-2xl shadow-2xl w-[75vw] max-h-[85vh] flex flex-col"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="px-8 py-6 border-b border-gray-200">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <h2 className="text-xl text-gray-900 mb-1">Create segment</h2>
                <p className="text-sm text-gray-500">
                  Combine demographics and behavioral enrichments to define a segment inside this audience.
                </p>
                <p className="text-xs text-gray-400 mt-2 italic">
                  Opened after clicking "Create segment" in the Segments panel.
                </p>
              </div>
              
              <button onClick={onClose} className="ml-8 p-2 hover:bg-gray-100 rounded-lg transition-colors">
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>
          </div>
          
          {/* Segment Basics Row */}
          <div className="px-8 py-5 border-b border-gray-100">
            <div className="grid grid-cols-[60%_40%] gap-4">
              <div>
                <label className="text-sm text-gray-700 mb-1.5 block">Segment name</label>
                <input
                  type="text"
                  placeholder="e.g., High-Intent Value-First Finance VPs"
                  defaultValue="High-Intent Value-First Finance VPs"
                  className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-violet-500 focus:border-transparent"
                />
              </div>
              
              <div>
                <label className="text-sm text-gray-700 mb-1.5 block">Description (optional)</label>
                <input
                  type="text"
                  placeholder="Describe who belongs in this segment and how you plan to use it."
                  defaultValue="Finance VPs with high email engagement and value-seeking behavior"
                  className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-violet-500 focus:border-transparent"
                />
              </div>
            </div>
          </div>
          
          {/* Selected Conditions Strip */}
          <div className="px-8 py-4 bg-gradient-to-r from-violet-50 to-purple-50 border-b border-violet-100">
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-xs text-gray-600 uppercase tracking-wider">Selected Conditions</h4>
              <span className="text-sm text-gray-700">Conditions: 4</span>
            </div>
            
            <div className="flex flex-wrap gap-2">
              <Badge variant="outline" className="bg-white border-violet-300 text-violet-700">Company Size: 101–250, 251–500</Badge>
              <Badge variant="outline" className="bg-white border-violet-300 text-violet-700">EMAIL_ENGAGEMENT_SCORE ≥ 0.80</Badge>
              <Badge variant="outline" className="bg-white border-violet-300 text-violet-700">VALUE_SEEKER_SCORE ≥ 0.70</Badge>
              <Badge variant="outline" className="bg-white border-violet-300 text-violet-700">Is Married = true</Badge>
            </div>
          </div>
          
          {/* Body - Two Column Layout */}
          <div className="flex-1 overflow-y-auto">
            <div className="grid grid-cols-[45%_55%] gap-6 px-8 py-6">
              {/* LEFT COLUMN - Demographics */}
              <div>
                <h3 className="text-sm text-gray-900 mb-4">Demographics & traits</h3>
                
                <div className="space-y-3">
                  {/* Personal */}
                  <DemographicSection
                    title="Personal"
                    isExpanded={demographicsExpanded.personal}
                    onToggle={() => setDemographicsExpanded(prev => ({ ...prev, personal: !prev.personal }))}
                  >
                    <DemographicField name="Is Married?" type="toggle" active={true} />
                    <DemographicField name="Has Children?" type="toggle" />
                    <DemographicField name="Home Owner?" type="toggle" />
                    <DemographicField name="Personal Emails" />
                    <DemographicField name="Additional Personal Emails" />
                    <DemographicField name="LinkedIn URL" />
                    <DemographicField name="Income Range" />
                    <DemographicField name="Net Worth" />
                    <DemographicField name="Age Range" />
                    <DemographicField name="Personal Phone" />
                    <DemographicField name="Personal Address" />
                    <DemographicField name="Personal Address 2" />
                    <DemographicField name="Personal City" />
                    <DemographicField name="Personal Zip" />
                    <DemographicField name="Personal Zip4" />
                    <DemographicField name="Personal State" />
                    <DemographicField name="Gender" />
                  </DemographicSection>
                  
                  {/* Professional */}
                  <DemographicSection
                    title="Professional"
                    isExpanded={demographicsExpanded.professional}
                    onToggle={() => setDemographicsExpanded(prev => ({ ...prev, professional: !prev.professional }))}
                  >
                    <DemographicField name="Job Title" />
                    <DemographicField name="Seniority Level" />
                    <DemographicField name="Department" />
                    <DemographicField name="Business Emails" />
                    <DemographicField name="Professional State" />
                    <DemographicField name="Work History" />
                    <DemographicField name="Education History" />
                    <DemographicField name="Professional City" />
                    <DemographicField name="Professional Zip" />
                    <DemographicField name="Professional Zip4" />
                    <DemographicField name="Professional Address" />
                    <DemographicField name="Professional Address 2" />
                  </DemographicSection>
                  
                  {/* Company */}
                  <DemographicSection
                    title="Company"
                    isExpanded={demographicsExpanded.company}
                    onToggle={() => setDemographicsExpanded(prev => ({ ...prev, company: !prev.company }))}
                    active={true}
                  >
                    <DemographicField name="Primary Industry" />
                    <DemographicField name="Annual Revenue" />
                    <DemographicField name="Employee Count" />
                    <DemographicField name="Company Size" type="active" activeValues="101–250, 251–500" />
                    <DemographicField name="Company State" />
                    <DemographicField name="Company Name" />
                    <DemographicField name="Company Address" />
                    <DemographicField name="Company LinkedIn" />
                    <DemographicField name="Company Website" />
                    <DemographicField name="Company Phone" />
                    <DemographicField name="Related Domains" />
                    <DemographicField name="Company Zip" />
                    <DemographicField name="Description" />
                    <DemographicField name="SIC Code" />
                  </DemographicSection>
                </div>
              </div>
              
              {/* RIGHT COLUMN - Enrichments */}
              <div>
                <h3 className="text-sm text-gray-900 mb-4">Behavioral enrichments</h3>
                
                {/* Global Slider */}
                <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 mb-4">
                  <label className="text-sm text-gray-700 mb-3 block">Enrichment score range</label>
                  <div className="mb-2">
                    <div className="h-2 bg-gray-200 rounded-full relative">
                      <div 
                        className="absolute h-full bg-violet-500 rounded-full"
                        style={{ 
                          left: `${globalRange[0] * 100}%`,
                          right: `${(1 - globalRange[1]) * 100}%`
                        }}
                      />
                    </div>
                    <div className="flex justify-between text-xs mt-1 text-gray-500">
                      {[0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0].map(v => (
                        <span key={v}>{v.toFixed(1)}</span>
                      ))}
                    </div>
                  </div>
                  <p className="text-xs text-gray-600 mb-2">Current selection: {globalRange[0].toFixed(1)} – {globalRange[1].toFixed(1)}</p>
                </div>
                
                {/* Enrichment Categories - Scrollable */}
                <div className="space-y-3 max-h-[450px] overflow-y-auto pr-2">
                  <EnrichmentCategory
                    title="Channel Engagement & Reachability"
                    enrichments={[
                      "Email Engagement Score",
                      "SMS Engagement Score",
                      "Digital Ad Engagement Score",
                      "Mobile Device Engagement Score",
                      "Desktop Device Engagement Score",
                      "Media Layer Saturation Score",
                      "Daypart Responsiveness Score",
                      "Weekday Vs Weekend Activity Score",
                      "Recency Frequency Window Score",
                      "Real World Vs Digital World Bias Score",
                      "Social Responsiveness Score",
                      "Repetition Receptivity Score",
                      "Trend Sensitivity Score",
                    ]}
                    selectedEnrichments={selectedEnrichments}
                    onToggle={(name) => {
                      const key = name.toUpperCase().replace(/ /g, '_').replace(/VS/g, 'VS');
                      if (selectedEnrichments.includes(key)) {
                        setSelectedEnrichments(selectedEnrichments.filter(e => e !== key));
                      } else {
                        setSelectedEnrichments([...selectedEnrichments, key]);
                      }
                    }}
                  />
                  
                  <EnrichmentCategory
                    title="Purchase Drivers & Financial Behavior"
                    enrichments={[
                      "Impulse Buy Score",
                      "Subscription Purchase Score",
                      "Overextension Risk Score",
                      "Financial Cautiousness Score",
                      "Financial Optimization Score",
                      "Coupon Conversion Score",
                      "Deal Hunting Score",
                      "Value Seeker Score",
                      "Bargain Vs Quality Bias Score",
                      "Luxury Purchase Tendency",
                      "Exclusivity Affinity Score",
                      "Risk Tolerance Score",
                      "Risk Mitigation Behavior Score",
                      "Convenience Over Quality Score",
                      "Locality Affinity Score",
                      "Loyalty Program Responsiveness Score",
                      "Subscription Fatigue Score",
                      "Time To Purchase Sensitivity Score",
                      "Trial Willingness Score",
                      "Purchase Rationality Score",
                      "Brand Switching Score",
                      "Brand Loyalty Score",
                    ]}
                    selectedEnrichments={selectedEnrichments}
                    onToggle={(name) => {
                      const key = name.toUpperCase().replace(/ /g, '_').replace(/VS/g, 'VS');
                      if (selectedEnrichments.includes(key)) {
                        setSelectedEnrichments(selectedEnrichments.filter(e => e !== key));
                      } else {
                        setSelectedEnrichments([...selectedEnrichments, key]);
                      }
                    }}
                  />
                  
                  <EnrichmentCategory
                    title="Messaging, Content & Influence Pathways"
                    enrichments={[
                      "Influencer Response Score",
                      "Expert Response Score",
                      "Authority Response Score",
                      "Authority Defiance Score",
                      "Skepticism Score",
                      "Trust Signal Sensitivity Score",
                      "Social Validation Sensitivity Score",
                      "Social Validation Dependence Score",
                      "Relationship Reliance Score",
                      "Tribe Conformity Score",
                      "Identity Anchoring Score",
                      "Institutional Trust & Skepticism",
                      "Policy Focused Persuasion Score",
                      "Polarization Tolerance Score",
                      "Control Locus Score",
                      "Civic Engagement And Agency Score",
                      "Political Mobilizability Score",
                      "Civic Engagement Intensity Score",
                      "Emotional Sensitivity Score",
                      "Emotionally Charged Response Score",
                      "Emotional Reactivity Score",
                      "Emotional Volatility Index",
                      "Hope Orientation Score",
                      "Optimism Bias Score",
                      "Anxiety Sensitivity Score",
                      "Frustration Tolerance Score",
                      "Empathy Responsiveness Score",
                      "Nostalgia Affinity Score",
                      "Shame Aversion Score",
                      "Materialism Vs Meaning Orientation",
                      "Narrative Persuasion Score",
                      "Narrative Framing: Victim Vs Hero Identity Score",
                      "Research Depth Score",
                      "Deliberative Decision Making Score",
                      "Information Overload Tolerance Score",
                      "Intellectual Engagement Score",
                      "Rationalism Vs Emotional Intuition Score",
                      "Experiential Learning Score",
                    ]}
                    selectedEnrichments={selectedEnrichments}
                    onToggle={(name) => {
                      const key = name.toUpperCase().replace(/ /g, '_').replace(/VS/g, 'VS').replace(/:/g, '');
                      if (selectedEnrichments.includes(key)) {
                        setSelectedEnrichments(selectedEnrichments.filter(e => e !== key));
                      } else {
                        setSelectedEnrichments([...selectedEnrichments, key]);
                      }
                    }}
                  />
                  
                  <EnrichmentCategory
                    title="Mindset, Identity & Context"
                    enrichments={[
                      "Temporal Orientation Score",
                      "Stability Vs Change Preference Score",
                      "Individualism Vs Collectivism Score",
                      "Zero Sum Vs Abundance Mindset",
                      "Psychological Security Seeking Score",
                      "Local Outlier Score",
                      "Neighborhood Homogeneity Score",
                      "Social Exposure Score",
                      "Cultural Affinity Index",
                      "Community Velocity Score",
                      "Conformity Pressure Index",
                      "Geo Social Influence Density",
                      "Behavioral Disparity Score",
                      "Civic Cohesion Score",
                      "Sprawl Intensity Index",
                      "Geo Economic Pressure Score",
                      "Local Ideology Consistency Score",
                      "Ethical Guidelines Score",
                      "Religious Value Alignment Score",
                      "DEI Alignment Score",
                      "Brand Idealism Alignment Score",
                      "Patriotic Alignment Score",
                      "Environmental Risk Aversion Score",
                      "Ethical Consumption Sensitivity Score",
                      "Anonymity Desire Score",
                      "Privacy Sensitivity Score",
                      "Freedom Vs Security Trade Off Tendency",
                      "Authoritarian Vs Libertarian Tendencies",
                      "Technological Optimism Vs Tech Skepticism",
                      "Algorithmic Trust Score",
                      "Openness To Conspiracy Or Non Mainstream Ideas Score",
                      "Moral Absolutism Vs Relativism Score",
                    ]}
                    selectedEnrichments={selectedEnrichments}
                    onToggle={(name) => {
                      const key = name.toUpperCase().replace(/ /g, '_').replace(/VS/g, 'VS');
                      if (selectedEnrichments.includes(key)) {
                        setSelectedEnrichments(selectedEnrichments.filter(e => e !== key));
                      } else {
                        setSelectedEnrichments([...selectedEnrichments, key]);
                      }
                    }}
                  />
                </div>
                
                <div className="mt-4 text-xs text-gray-600 text-center">
                  Selected enrichments: {selectedEnrichments.length} · Total available: 80+
                </div>
              </div>
            </div>
          </div>
          
          {/* Footer */}
          <div className="px-8 py-5 border-t border-gray-200 flex items-center justify-between bg-gray-50">
            <p className="text-xs text-gray-500 italic">
              If no records match your criteria, this segment will simply contain 0 people.
            </p>
            
            <div className="flex items-center gap-3">
              <Button variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button variant="outline" className="border-violet-600 text-violet-700 hover:bg-violet-50">
                Save segment
              </Button>
              <Button className="bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700">
                Save & sync segment
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

function DemographicSection({
  title,
  isExpanded,
  onToggle,
  children,
  active = false,
}: {
  title: string;
  isExpanded: boolean;
  onToggle: () => void;
  children: React.ReactNode;
  active?: boolean;
}) {
  return (
    <div className={`border rounded-lg overflow-hidden ${active ? 'border-violet-300 bg-violet-50' : 'border-gray-200 bg-white'}`}>
      <button 
        onClick={onToggle}
        className={`w-full px-4 py-2.5 flex items-center justify-between transition-colors ${
          active ? 'hover:bg-violet-100' : 'hover:bg-gray-50'
        }`}
      >
        <span className="text-sm text-gray-900">{title}</span>
        {isExpanded ? 
          <ChevronUp className="w-4 h-4 text-gray-500" /> : 
          <ChevronDown className="w-4 h-4 text-gray-500" />
        }
      </button>
      {isExpanded && (
        <div className="px-3 py-2 border-t border-gray-100 bg-white space-y-1">
          {children}
        </div>
      )}
    </div>
  );
}

function DemographicField({ 
  name, 
  type,
  active = false,
  activeValues,
}: { 
  name: string; 
  type?: 'toggle' | 'active';
  active?: boolean;
  activeValues?: string;
}) {
  if (type === 'toggle') {
    return (
      <div className={`px-3 py-2 rounded flex items-center justify-between ${active ? 'bg-violet-50 border border-violet-300' : 'hover:bg-gray-50'}`}>
        <span className="text-sm text-gray-700">{name}</span>
        <label className="relative inline-block w-9 h-5">
          <input type="checkbox" className="sr-only peer" defaultChecked={active} />
          <div className="w-full h-full bg-gray-200 peer-checked:bg-violet-600 rounded-full peer-checked:after:translate-x-4 after:content-[''] after:absolute after:top-0.5 after:left-0.5 after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all"></div>
        </label>
      </div>
    );
  }
  
  if (type === 'active') {
    return (
      <div className="px-3 py-2 rounded bg-violet-50 border border-violet-300">
        <div className="flex items-center justify-between mb-1">
          <span className="text-sm text-gray-900">{name}</span>
          <button className="text-xs text-red-600 hover:text-red-700">
            <Minus className="w-3 h-3" />
          </button>
        </div>
        <div className="text-xs text-violet-700">{activeValues}</div>
      </div>
    );
  }
  
  return (
    <button className="w-full text-left px-3 py-2 rounded hover:bg-gray-50 border border-transparent hover:border-gray-200 transition-colors flex items-center gap-2 text-sm text-gray-700">
      <Plus className="w-3 h-3 text-gray-400" />
      {name}
    </button>
  );
}

function EnrichmentCategory({
  title,
  enrichments,
  selectedEnrichments,
  onToggle,
}: {
  title: string;
  enrichments: string[];
  selectedEnrichments: string[];
  onToggle: (name: string) => void;
}) {
  return (
    <div className="border border-gray-200 rounded-lg overflow-hidden bg-white">
      <div className="px-3 py-2 bg-gray-100 border-b border-gray-200">
        <span className="text-xs text-gray-700 uppercase tracking-wider">{title}</span>
      </div>
      <div className="p-2 grid grid-cols-2 gap-x-3 gap-y-1">
        {enrichments.map((enrichment) => {
          const key = enrichment.toUpperCase().replace(/ /g, '_').replace(/VS/g, 'VS').replace(/:/g, '');
          const isSelected = selectedEnrichments.includes(key);
          
          return (
            <label 
              key={enrichment}
              className={`flex items-center gap-2 px-2 py-1.5 rounded cursor-pointer transition-colors ${
                isSelected ? 'bg-violet-50' : 'hover:bg-gray-50'
              }`}
            >
              <Checkbox
                checked={isSelected}
                onCheckedChange={() => onToggle(enrichment)}
              />
              <span className="text-xs text-gray-700 flex-1">{enrichment}</span>
            </label>
          );
        })}
      </div>
    </div>
  );
}
import { X, ChevronDown } from "lucide-react";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { Checkbox } from "../ui/checkbox";

export function GeneratePlaybookDrawer({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  if (!isOpen) return null;
  
  return (
    <>
      {/* Backdrop */}
      <div className="fixed inset-0 bg-black/20 z-40" onClick={onClose} />
      
      {/* Drawer */}
      <div className="fixed right-0 top-0 bottom-0 w-[480px] bg-white shadow-2xl z-50 flex flex-col">
        {/* Header */}
        <div className="px-6 py-5 border-b border-gray-200">
          <div className="flex items-center justify-between mb-2">
            <h2 className="text-gray-900">Generate Playbook for this Audience</h2>
            <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
              <X className="w-5 h-5 text-gray-500" />
            </button>
          </div>
        </div>
        
        {/* Content */}
        <div className="flex-1 overflow-y-auto px-6 py-6 space-y-6">
          {/* Section A - Context Summary */}
          <div>
            <h3 className="text-xs text-gray-500 uppercase tracking-wider mb-3">Audience</h3>
            <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
              <div className="text-sm text-gray-900 mb-3">Q4 – Finance VPs in CA (Email {'>'} 0.95)</div>
              <div className="flex flex-wrap gap-2">
                <Badge variant="outline" className="text-gray-600 border-gray-300">42,318 people</Badge>
                <Badge variant="outline" className="text-gray-600 border-gray-300">Avg EMAIL_ENGAGEMENT: 0.81</Badge>
                <Badge variant="outline" className="text-violet-600 border-violet-300 bg-violet-50">Current Lens: Purchase Style</Badge>
              </div>
            </div>
          </div>
          
          {/* Section B - Strategy Focus */}
          <div>
            <h3 className="text-xs text-gray-500 uppercase tracking-wider mb-3">Strategy Focus</h3>
            <div className="flex flex-wrap gap-2 mb-2">
              <button className="px-3 py-1.5 rounded-full border-2 border-violet-500 bg-violet-50 text-violet-700 text-sm">
                Value-first messaging
              </button>
              <button className="px-3 py-1.5 rounded-full border-2 border-gray-300 text-gray-700 text-sm hover:border-gray-400">
                Risk reduction
              </button>
              <button className="px-3 py-1.5 rounded-full border-2 border-gray-300 text-gray-700 text-sm hover:border-gray-400">
                Time-to-ROI
              </button>
              <button className="px-3 py-1.5 rounded-full border-2 border-gray-300 text-gray-700 text-sm hover:border-gray-400">
                Compliance / risk & compliance
              </button>
            </div>
            <p className="text-xs text-gray-500">
              We suggested these based on top behavioral levers and personas. You can adjust before generating.
            </p>
          </div>
          
          {/* Section C - Channels */}
          <div>
            <h3 className="text-xs text-gray-500 uppercase tracking-wider mb-3">Primary Channels</h3>
            <div className="space-y-2 mb-3">
              <label className="flex items-center gap-3 p-3 bg-emerald-50 border border-emerald-200 rounded-lg cursor-pointer">
                <Checkbox defaultChecked />
                <span className="text-sm text-gray-900">Email (Recommended)</span>
              </label>
              <label className="flex items-center gap-3 p-3 border border-gray-200 rounded-lg cursor-pointer hover:border-gray-300">
                <Checkbox defaultChecked />
                <span className="text-sm text-gray-900">Webinars</span>
              </label>
              <label className="flex items-center gap-3 p-3 border border-gray-200 rounded-lg cursor-pointer hover:border-gray-300">
                <Checkbox />
                <span className="text-sm text-gray-900">SMS (Low readiness)</span>
              </label>
              <label className="flex items-center gap-3 p-3 border border-gray-200 rounded-lg cursor-pointer hover:border-gray-300">
                <Checkbox />
                <span className="text-sm text-gray-900">Paid social</span>
              </label>
            </div>
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 space-y-1 text-xs">
              <div className="text-gray-700">
                <span className="text-blue-700">Email Engagement: 0.81</span> · Very high responsiveness vs typical audience.
              </div>
              <div className="text-gray-700">
                <span className="text-amber-600">SMS Engagement: Low</span> · Currently low — deprioritize SMS-only campaigns.
              </div>
            </div>
          </div>
          
          {/* Section D - Output Options */}
          <div>
            <h3 className="text-xs text-gray-500 uppercase tracking-wider mb-3">Playbook Outputs</h3>
            <div className="space-y-2">
              <label className="flex items-center gap-3 cursor-pointer">
                <Checkbox defaultChecked />
                <span className="text-sm text-gray-900">Campaign brief (angles, hooks, example subject lines)</span>
              </label>
              <label className="flex items-center gap-3 cursor-pointer">
                <Checkbox defaultChecked />
                <span className="text-sm text-gray-900">Channel plan (touchpoints & cadence)</span>
              </label>
              <label className="flex items-center gap-3 cursor-pointer">
                <Checkbox defaultChecked />
                <span className="text-sm text-gray-900">Persona-specific messaging notes</span>
              </label>
            </div>
          </div>
        </div>
        
        {/* Footer */}
        <div className="px-6 py-4 border-t border-gray-200 space-y-2">
          <Button className="w-full bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700">
            Generate Playbook
          </Button>
          <div className="relative">
            <Button variant="outline" className="w-full gap-2">
              Generate & send to…
              <ChevronDown className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    </>
  );
}

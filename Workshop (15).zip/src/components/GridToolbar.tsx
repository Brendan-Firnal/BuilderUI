import { Sliders, ChevronDown } from "lucide-react";
import { getLensColors } from "../lib/lens-colors";

const lensNames: Record<string, string> = {
  channel: "Channel Engagement & Reachability",
  purchase: "Purchase Drivers & Financial Behavior",
  messaging: "Messaging, Content & Influence Pathways",
  decision: "Decision Style & Trust Dynamics",
  context: "Social & Cultural Context (ZIP / Community-Level)",
  values: "Values, Ideology & Worldview Alignment",
  emotional: "Emotional & Psychographic Orientation",
  identity: "Identity, Lifestyle & Life Stage (Sub-Models)",
};

export function GridToolbar({ 
  activeLens,
  appliedSegment,
  onOpenColumnsSheet,
}: { 
  activeLens: string;
  appliedSegment?: {name: string; count: number; percentage: number} | null;
  onOpenColumnsSheet?: () => void;
}) {
  const lensName = lensNames[activeLens] || lensNames.purchase;
  const colors = getLensColors(activeLens);
  
  return (
    <div className="border-b border-gray-200 bg-white relative z-10">
      {/* Unified Header Row */}
      <div className="px-6 py-3 flex items-center justify-between bg-white">
        {/* Left Side: Lens Pill only */}
        <div className="flex items-center gap-3">
          <span 
            className="text-sm font-semibold px-4 py-2 rounded-full text-white whitespace-nowrap"
            style={{ background: colors.gradient }}
          >
            Current lens: {lensName}
          </span>
        </div>
        
        {/* Right Side: Columns Button + Showing Count */}
        <div className="flex items-center gap-3">
          <button 
            onClick={onOpenColumnsSheet}
            className="px-3 py-2 text-sm border border-gray-200 rounded-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 flex items-center gap-2"
          >
            <Sliders className="w-4 h-4" />
            Columns
            <ChevronDown className="w-4 h-4" />
          </button>
          
          <div className="text-sm text-gray-600 whitespace-nowrap">
            Showing 20 of 42,318 people
          </div>
        </div>
      </div>
    </div>
  );
}
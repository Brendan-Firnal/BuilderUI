import { useState } from "react";
import { Calendar, Filter, Target, Building2 } from "lucide-react";
import { EnrichmentsView } from "./EnrichmentsView";
import { PlaybooksView } from "./PlaybooksView";
import { AudiencesPersonasView } from "./AudiencesPersonasView";
import { Button } from "../ui/button";

type Tab = "enrichments" | "playbooks" | "audiences";

export function AnalysisShell() {
  const [activeTab, setActiveTab] = useState<Tab>("enrichments");
  
  return (
    <div className="min-h-screen">
      {/* Global Header */}
      <div className="bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-[1800px] mx-auto px-8 py-6">
          <div className="flex items-start justify-between mb-6">
            {/* Left - Title */}
            <div>
              <h1 className="text-gray-900 mb-1">Analysis</h1>
              <p className="text-sm text-gray-600">
                Understand which behavioral levers and playbooks actually drive outcomes.
              </p>
            </div>
            
            {/* Right - Global Filters */}
            <div className="flex items-center gap-3">
              <button className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-200 rounded-lg hover:border-gray-300 transition-colors text-sm">
                <Calendar className="w-4 h-4 text-gray-500" />
                <span className="text-gray-700">Last 30 days</span>
              </button>
              
              <button className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-200 rounded-lg hover:border-gray-300 transition-colors text-sm">
                <Filter className="w-4 h-4 text-gray-500" />
                <span className="text-gray-700">All channels</span>
              </button>
              
              <button className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-200 rounded-lg hover:border-gray-300 transition-colors text-sm">
                <Target className="w-4 h-4 text-gray-500" />
                <span className="text-gray-700">Objective: Conversions</span>
              </button>
              
              <button className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-200 rounded-lg hover:border-gray-300 transition-colors text-sm">
                <Building2 className="w-4 h-4 text-gray-500" />
                <span className="text-gray-700">Org: Acme Corp</span>
              </button>
            </div>
          </div>
          
          {/* Tab Bar */}
          <div className="flex items-center gap-6 border-b border-gray-200 -mb-px">
            <button
              onClick={() => setActiveTab("enrichments")}
              className={`pb-4 text-sm transition-colors relative ${
                activeTab === "enrichments"
                  ? "text-violet-700"
                  : "text-gray-600 hover:text-gray-900"
              }`}
            >
              Enrichments
              {activeTab === "enrichments" && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-violet-600" />
              )}
            </button>
            
            <button
              onClick={() => setActiveTab("playbooks")}
              className={`pb-4 text-sm transition-colors relative ${
                activeTab === "playbooks"
                  ? "text-violet-700"
                  : "text-gray-600 hover:text-gray-900"
              }`}
            >
              Playbooks
              {activeTab === "playbooks" && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-violet-600" />
              )}
            </button>
            
            <button
              onClick={() => setActiveTab("audiences")}
              className={`pb-4 text-sm transition-colors relative ${
                activeTab === "audiences"
                  ? "text-violet-700"
                  : "text-gray-600 hover:text-gray-900"
              }`}
            >
              Audiences & Personas
              {activeTab === "audiences" && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-violet-600" />
              )}
            </button>
          </div>
        </div>
      </div>
      
      {/* Tab Content */}
      <div className="max-w-[1800px] mx-auto">
        {activeTab === "enrichments" && <EnrichmentsView />}
        {activeTab === "playbooks" && <PlaybooksView />}
        {activeTab === "audiences" && <AudiencesPersonasView />}
      </div>
    </div>
  );
}

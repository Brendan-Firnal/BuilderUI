import { useState } from "react";
import { AudienceHeader } from "./components/AudienceHeader";
import { LeftSidebar } from "./components/LeftSidebar";
import { AudienceGrid } from "./components/AudienceGrid";
import { RightPanel } from "./components/RightPanel";
import { GeneratePlaybookDrawer } from "./components/drawers/GeneratePlaybookDrawer";
import { ExportAudienceModal } from "./components/modals/ExportAudienceModal";
import { CampaignDrillInDrawer } from "./components/drawers/CampaignDrillInDrawer";
import { CreateWorkflowDrawer } from "./components/drawers/CreateWorkflowDrawer";
import { SegmentBuilderDrawer } from "./components/drawers/SegmentBuilderDrawer";
import { MySegmentsModal } from "./components/modals/MySegmentsModal";
import { CustomizeColumnsSheet } from "./components/modals/CustomizeColumnsSheet";
import { AudienceFiltersModal } from "./components/modals/AudienceFiltersModal";
import { BuilderPlaceholder } from "./components/BuilderPlaceholder";
import { Toaster } from "./components/ui/sonner";
import { toast } from "sonner@2.0.3";

export default function App() {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [rightPanelCollapsed, setRightPanelCollapsed] = useState(false);
  const [playbookDrawerOpen, setPlaybookDrawerOpen] = useState(false);
  const [exportModalOpen, setExportModalOpen] = useState(false);
  const [campaignDrawerOpen, setCampaignDrawerOpen] = useState(false);
  const [workflowDrawerOpen, setWorkflowDrawerOpen] = useState(false);
  const [segmentBuilderOpen, setSegmentBuilderOpen] = useState(false);
  const [mySegmentsOpen, setMySegmentsOpen] = useState(false);
  const [columnsSheetOpen, setColumnsSheetOpen] = useState(false);
  const [filtersModalOpen, setFiltersModalOpen] = useState(false);
  const [activeLens, setActiveLens] = useState("purchase");
  const [audienceAverages, setAudienceAverages] = useState<Record<string, number>>({});
  const [appliedSegment, setAppliedSegment] = useState<{name: string; count: number; percentage: number} | null>(null);
  const [viewMode, setViewMode] = useState<"audience" | "selection">("audience");
  const [workspaceMode, setWorkspaceMode] = useState<"builder" | "workshop">("workshop");
  const [showSegmentAppliedBanner, setShowSegmentAppliedBanner] = useState(false);
  
  const handleApplySegment = (segmentName: string, matchCount: number, matchPercentage: number) => {
    setAppliedSegment({ name: segmentName, count: matchCount, percentage: matchPercentage });
    setViewMode("selection"); // Automatically switch to selection view
    setShowSegmentAppliedBanner(true); // Show the banner
    
    // Only show toast if not a multi-segment apply
    if (!segmentName.includes("segment(s) applied")) {
      toast.success(`Segment "${segmentName}" applied · ${matchCount.toLocaleString()} people selected (${matchPercentage}% of audience)`);
    }
  };
  
  const handleClearSelection = () => {
    setAppliedSegment(null);
    setViewMode("audience");
    setShowSegmentAppliedBanner(false);
    toast.success("Selection cleared");
  };
  
  const handleClearFilters = () => {
    setShowSegmentAppliedBanner(false);
    toast.success("Filters cleared");
  };
  
  const handleCreateAudienceFromSelection = () => {
    toast.success("Creating new audience from selection...");
    // TODO: Implement create audience logic
  };
  
  const handleCreateSegment = () => {
    setWorkspaceMode("builder");
  };
  
  return (
    <div className="min-h-screen bg-[#F5F5F7] p-8">
      <div className="mx-auto max-w-[1800px]">
        {/* Main White Card */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden flex flex-col h-[calc(100vh-4rem)]">
          {/* Top Header */}
          <AudienceHeader 
            onExportAudience={() => setExportModalOpen(true)}
            appliedSegment={appliedSegment}
            onClearSelection={handleClearSelection}
            viewMode={viewMode}
            onViewModeChange={setViewMode}
            onOpenFilters={() => setFiltersModalOpen(true)}
            workspaceMode={workspaceMode}
            onWorkspaceModeChange={setWorkspaceMode}
          />
          
          {/* Main Content Area */}
          {workspaceMode === "workshop" ? (
            <div className="flex flex-1 overflow-hidden">
              {/* Left Sidebar */}
              <LeftSidebar 
                isCollapsed={sidebarCollapsed}
                onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
                activeLens={activeLens}
                onLensChange={setActiveLens}
                onCreateSegment={() => setSegmentBuilderOpen(true)}
                onViewSegments={() => setMySegmentsOpen(true)}
              />
              
              {/* Center Grid */}
              <div className="flex-1 overflow-hidden flex flex-col">
                {/* Post-Apply Banner */}
                {showSegmentAppliedBanner && (
                  <div className="mx-6 mt-4 mb-0 px-4 py-3 bg-[#ECFDF3] rounded-lg flex items-center justify-between">
                    <span className="text-sm text-gray-700">Selected segments applied to this view.</span>
                    <div className="flex items-center gap-3">
                      <button
                        onClick={handleCreateAudienceFromSelection}
                        className="text-sm font-medium px-4 py-1.5 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                      >
                        Create new audience from selection
                      </button>
                      <button
                        onClick={handleClearFilters}
                        className="text-sm text-gray-600 hover:text-gray-900 hover:underline transition-colors"
                      >
                        Clear filters
                      </button>
                    </div>
                  </div>
                )
                }                
                <AudienceGrid 
                  activeLens={activeLens} 
                  onAudienceAveragesChange={setAudienceAverages}
                  appliedSegment={appliedSegment}
                  onOpenColumnsSheet={() => setColumnsSheetOpen(true)}
                />
              </div>
              
              {/* Right Panel */}
              <RightPanel 
                onOpenCampaignDrillIn={() => setCampaignDrawerOpen(true)}
                activeLens={activeLens}
                onCreateSegment={handleCreateSegment}
                onViewSegments={() => setMySegmentsOpen(true)}
                audienceAverages={audienceAverages}
                onApplySegment={handleApplySegment}
                isCollapsed={rightPanelCollapsed}
                onToggleCollapse={() => setRightPanelCollapsed(!rightPanelCollapsed)}
              />
            </div>
          ) : (
            <BuilderPlaceholder onBackToWorkshop={() => setWorkspaceMode("workshop")} />
          )}
        </div>
      </div>
      
      {/* Drawers & Modals */}
      <GeneratePlaybookDrawer 
        isOpen={playbookDrawerOpen}
        onClose={() => setPlaybookDrawerOpen(false)}
      />
      
      <ExportAudienceModal
        isOpen={exportModalOpen}
        onClose={() => setExportModalOpen(false)}
      />
      
      <CampaignDrillInDrawer
        isOpen={campaignDrawerOpen}
        onClose={() => setCampaignDrawerOpen(false)}
      />
      
      <CreateWorkflowDrawer
        isOpen={workflowDrawerOpen}
        onClose={() => setWorkflowDrawerOpen(false)}
      />
      
      <SegmentBuilderDrawer
        isOpen={segmentBuilderOpen}
        onClose={() => setSegmentBuilderOpen(false)}
      />
      
      <MySegmentsModal
        isOpen={mySegmentsOpen}
        onClose={() => setMySegmentsOpen(false)}
      />
      
      <CustomizeColumnsSheet
        isOpen={columnsSheetOpen}
        onClose={() => setColumnsSheetOpen(false)}
        activeLens={activeLens}
        onApply={(config) => {
          // TODO: Apply column configuration
          toast.success("Column configuration updated");
        }}
      />
      
      <AudienceFiltersModal
        isOpen={filtersModalOpen}
        onClose={() => setFiltersModalOpen(false)}
      />
      
      <Toaster />
    </div>
  );
}
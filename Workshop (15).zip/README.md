
  # Workshop

  This is a code bundle for Workshop. The original project is available at https://www.figma.com/design/Nofkb5kEDgAJeGtRzMhuHd/Workshop.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  